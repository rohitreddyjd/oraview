package sqlGraph;

import oracle.jdbc.OracleDriver;

import org.apache.tomcat.dbcp.dbcp.DriverManagerConnectionFactory;
import org.apache.tomcat.dbcp.dbcp.PoolableConnectionFactory;
import org.apache.tomcat.dbcp.dbcp.PoolingDriver;
import org.apache.tomcat.dbcp.pool.impl.GenericObjectPool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

public final class ConnectGlobal {
	private ConnectGlobal(){
		throw new Error();
	}
	
	public static synchronized Connection getConnection(String conName)
			throws Exception {
		Connection conn = null;
		try {
			DriverManager.registerDriver(new OracleDriver());
			DriverManager.setLoginTimeout(30);
			conn = DriverManager.getConnection("jdbc:apache:commons:dbcp:"
					.concat(conName));
			System.out.println("Got previously created connection pool for " + conName);
			// } catch (SQLException e) {
		} catch (Exception e) {
			// e.printStackTrace();
			try {
				System.out.println("Creating connection pool");
				DriverManager.registerDriver(new OracleDriver());
				DriverManager.setLoginTimeout(30);
				init(conName);
				//Thread.sleep(1000);
				conn = DriverManager.getConnection("jdbc:apache:commons:dbcp:"
						.concat(conName));
				System.out.println("Got created connection pool on 1st pass for " + conName);
			} catch (ConnectExcept er) {
				throw er;
			} catch (SQLException er) {
				System.out.println("Connection pool errored for " + conName);
				er.printStackTrace();
				if(er.getMessage().indexOf("1017") > 0){
					ConfigDbSQL.expireDb(conName);
					throw new ConnectExcept("Wrong Password Error: Expired connection pool password for " + conName + " due to error " + er.getMessage());
				}	else if(er.getMessage().indexOf("28000") > 0){
					ConfigDbSQL.expireDb(conName);
					throw new ConnectExcept("Password Locked: Expired connection pool password for " + conName + " due to error " + er.getMessage());
				}	else if(er.getMessage().indexOf("28001") > 0){
					ConfigDbSQL.expireDb(conName);
					throw new ConnectExcept("Password Expired: Expired connection pool password for " + conName + " due to error " + er.getMessage());
				} else {
					throw er;
				}
			}
		}
		try {
			System.err.println("Valid connection " + !conn.isClosed());
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		try {
			GenericObjectPool pl = (GenericObjectPool) new PoolingDriver()
					.getConnectionPool(conName);
			System.out.println("Idle Connections: " + pl.getNumIdle()
					+ ", out of " + pl.getNumActive());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	private static void init(String conName) throws ConnectExcept {
		List<String> inf = ConfigDbSQL.getDbInfo(conName);
		if(inf == null || inf.size() < 4){
			throw new ConnectExcept("Could not find connection entry for " + conName);
		}
		if(inf.get(3).equalsIgnoreCase("Expired")){
			throw new ConnectExcept("Connection entry password set to expired for " + conName);
		}
		
		GenericObjectPool pool = new GenericObjectPool(null);
		pool.setMinIdle(0);
		pool.setMaxIdle(5);
		pool.setMaxActive(15);
		pool.setMinEvictableIdleTimeMillis(60 * 1000);
		pool.setTimeBetweenEvictionRunsMillis(60 * 1000);
		System.err.println(inf.get(0));
		System.err.println(conName);
		// System.err.println(conBn.getPassword());
		Properties properties = new java.util.Properties();
		properties.put("user", inf.get(1));
		properties.put("password", inf.get(2));
		properties.put("oracle.jdbc.J2EE13Compliant", "true");
		DriverManagerConnectionFactory cf = new DriverManagerConnectionFactory(
				inf.get(0), properties);
		PoolableConnectionFactory pcf = new PoolableConnectionFactory(cf, pool,
				null, "SELECT * FROM DUAL", false, true);
		new PoolingDriver().registerPool(conName, pool);
		try{
			pcf.setDefaultAutoCommit(true);
			pcf.setDefaultReadOnly(true);
			//pcf.setValidationQueryTimeout(30);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

}
