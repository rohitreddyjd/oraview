package sqlGraph;

import java.awt.Color;
import java.awt.Paint;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.regex.Matcher;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.jfree.chart.ChartColor;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.encoders.SunPNGEncoderAdapter;
import org.jfree.chart.plot.DefaultDrawingSupplier;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.data.jdbc.JDBCXYDataset;
import org.jfree.data.time.Hour;
import org.jfree.data.time.Minute;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.TimeSeriesDataItem;
import org.jfree.data.xy.XYDataset;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class DbSQL {
	
	private DbSQL(){
		throw new Error();
	}

	private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle
			.getBundle("messages");


	private static final String emptyString = new String("");
	
	public static String getSql(String sqlID, Connection con) {

		String txtstr = new String("Could not find, getSql!");
		try {
			PreparedStatement pStat = con.prepareStatement(getString("sqltxt")
					.replaceAll("XXXX", Matcher.quoteReplacement(sqlID)));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			if (rset.next()) {
				txtstr = rset.getString(1);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = e.getMessage();
		}
		return txtstr;
	}

	public static String getJSONSqlText(Connection con, String sqlID) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;

		try {
			PreparedStatement pStat = con.prepareStatement(getString("sqltxt")
					.replaceAll("XXXX", Matcher.quoteReplacement(sqlID)));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			if (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if(outArray.length() == 0){
			inArray =  new JSONArray();
			inArray.put("Text not found for SQL Id: " + sqlID);
			outArray.put(inArray);
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String testConnectStr( String con){
	  String retVal = "OK";
	  try {
		Connect.getNonPooledConnection(con);
	} catch (SQLException e) {
		retVal = "Error: " + e.getMessage() + " " + e.getLocalizedMessage();
		e.printStackTrace();
	}
	  return retVal;
	  
	  
	}
	public static String testConnection( Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		if(con != null){
			try {
				PreparedStatement pStat = con.prepareStatement(getString("connect_test"));
				pStat.setQueryTimeout(120);
				ResultSet rset = pStat.executeQuery();
				rset.setFetchSize(100);
				boolean connected = false;
				if (rset.next()) {
					connected = true;
				}
				rset.close();
				pStat.close();
				if(connected){
					pStat = con.prepareStatement(getString("connect_test_other"));
					pStat.setQueryTimeout(120);
					rset = pStat.executeQuery();
					rset.setFetchSize(100);
					if (rset.next()) {
						inArray =  new JSONArray();
						inArray.put(rset.getString(1));
						inArray.put(rset.getString(2));
						inArray.put(rset.getString(3));
						outArray.put(inArray);
					} else {
						inArray =  new JSONArray();
						inArray.put("Unreachable");
						inArray.put("Unreachable");
						inArray.put("Unreachable");
						outArray.put(inArray);
					}
					rset.close();
					pStat.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(outArray.length() == 0){
			inArray =  new JSONArray();
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			outArray.put(inArray);
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String connectionListGroup( Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		if(con != null){
			try {
				PreparedStatement pStat = con.prepareStatement(getString("connect_list_group"));
				pStat.setQueryTimeout(120);
				ResultSet rset = pStat.executeQuery();
				rset.setFetchSize(100);
				while (rset.next()) {
					inArray =  new JSONArray();
					inArray.put(spaceStr(rset.getString(1)));
					inArray.put(spaceStr(rset.getString(2)));
					inArray.put(spaceStr(rset.getString(3)));
					inArray.put(spaceStr(rset.getString(4)));
					inArray.put(spaceStr(rset.getString(5)));
					outArray.put(inArray);
				} 
				if(outArray.length() == 0){
					inArray =  new JSONArray();
					inArray.put("No Connections");
					inArray.put("No Connections");
					inArray.put("No Connections");
					inArray.put("No Connections");
					inArray.put("No Connections");
					outArray.put(inArray);
				}
				rset.close();
				pStat.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(outArray.length() == 0){
			inArray =  new JSONArray();
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			outArray.put(inArray);
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static String connectionJSONLongList( Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		if(con != null){
			try {
				PreparedStatement pStat = con.prepareStatement(getString("connect_long_list"));
				pStat.setQueryTimeout(120);
				ResultSet rset = pStat.executeQuery();
				rset.setFetchSize(100);
				while (rset.next()) {
					inArray =  new JSONArray();
					inArray.put(spaceStr(rset.getString(1)));
					inArray.put(spaceStr(rset.getString(2)));
					inArray.put(spaceStr(rset.getString(3)));
					inArray.put(spaceStr(rset.getString(4)));
					inArray.put(spaceStr(rset.getString(5)));
					inArray.put(spaceStr(rset.getString(6)));
					outArray.put(inArray);
				} 
				if(outArray.length() == 0){
					inArray =  new JSONArray();
					inArray.put("No Long Queries");
					inArray.put("");
					inArray.put("");
					inArray.put("");
					inArray.put("");
					inArray.put("");
					outArray.put(inArray);
				}
				
				rset.close();
				pStat.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(outArray.length() == 0){
			inArray =  new JSONArray();
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			inArray.put("Unreachable");
			outArray.put(inArray);
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static long getDbID(Connection con) {
		long retval = 0;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("getdbid"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			if (rset.next()) {
				retval = rset.getLong(1);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			retval = 0;
		}
		return retval;
	}

	public static String getJSONSnap(Connection con) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		String txtstr = new String("Could not generate snap.");
		try {
			PreparedStatement pStat = con.prepareStatement(getString("snapit"));
			pStat.setQueryTimeout(120);
			txtstr =  "Succeeded in Generating Snap";
			con.commit();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = e.getMessage();
		}
		inArray =  new JSONArray();
		inArray.put(txtstr);
		outArray.put(inArray);
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static List<String> getCurrentADDM(Connection con) {
		ArrayList<String> aset = new ArrayList<String>();
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("addmlst"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				aset.add(rset.getString(1));
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return aset;
	}

	public static String getJSONADDMList(Connection con, String dt){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("addmsnaplst").replaceAll("XXXX", 
							dt));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getString(2));
				inArray.put(rset.getString(3));
				inArray.put(rset.getString(4));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	public static String runTune(Connection con, String sqlid, int seconds, String username, String password){
		String Result = "";
		try {
			PreparedStatement pStat = con.prepareStatement(getString("runetune"));
			pStat.setString(1, sqlid);
			pStat.setInt(2, seconds);
			Result =  (pStat.execute())?"Successfully ran":"Failed to run" + 
							    " tuning advisor for " + sqlid;
			pStat.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
			Result = "Error: " + e.getMessage();
		}
		return Result;
	}
	
	public static String getJSONTuneList(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con.prepareStatement(getString("tunelst"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				for(int y = 1; y <= 5; y++){
					inArray.put(rset.getString(y));	
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static String getJSONAWRDtList(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("awrsnapdates"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static String getJSONAWRList(Connection con, String dt){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("awrsnaplst").replaceAll("XXXX", 
							dt));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getString(2));
				inArray.put(rset.getString(3));
				inArray.put(rset.getString(4));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONADDM(String addm_name, Connection con1) {
		if(addm_name.equalsIgnoreCase("LATEST")){
			return getLst4Addm(con1);
		}
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		String txtstr = new String("Could not find ADDM.");
		try {
			PreparedStatement pStat = con1
					.prepareStatement(getString("addmtxt"));
			pStat.setString(1, addm_name);
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			if (rset.next()) {
				txtstr = rset.getString(1);
				if(txtstr == null){
					txtstr = "";
				}
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = e.getMessage();
		}
		inArray =  new JSONArray();
		inArray.put(txtstr);
		outArray.put(inArray);
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONTune(String owner, String tune_name, Connection con1) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		String txtstr = new String("Could not find Tuning Advisor Report.");
		try {
			PreparedStatement pStat = con1
					.prepareStatement(getString("tunetxt"));
			pStat.setString(1, tune_name);
			pStat.setString(2, owner);
			pStat.setQueryTimeout(300);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			if (rset.next()) {
				Clob rpt = rset.getClob(1);
				txtstr = rpt.getSubString(1, (int) rpt.length());
				if(txtstr == null){
					txtstr = "";
				}
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = e.getMessage();
		}
		inArray =  new JSONArray();
		inArray.put(txtstr);
		outArray.put(inArray);
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getLst4Addm(Connection con) {

		String txtstr = new String();
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("lst4addmtxt"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				txtstr = txtstr.concat(rset.getString(1).concat("\n\n"));
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = e.getMessage();
		}
		if (txtstr.length() == 0) {
			txtstr = "Coud not get ADDM";
		}
		return txtstr;
	}
/*
	public static List<AWRBean> getCurrentAWR(Connection con) {
		ArrayList<AWRBean> aset = new ArrayList<AWRBean>();
		try {
			PreparedStatement pStat = con.prepareStatement(getString("awrlst"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				aset.add(new AWRBean(rset.getLong(1), rset.getLong(2), rset
						.getLong(3), rset.getLong(4), rset.getString(5)));
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return aset;
	}
*/
	public static String getHTMLAWR(long dbid, long inst, 
			  long fsnap, long lsnap, Connection con) {

		String txtstr = new String("Could not retrieve AWR.");
		try {
			PreparedStatement pStat = null;
			if(inst > 0){
				pStat =con.prepareStatement(getString("awrhtml"));
				pStat.setLong(1, dbid);
				pStat.setLong(2, inst);
				pStat.setLong(3, fsnap);
				pStat.setLong(4, lsnap);
			} else{
				pStat =con.prepareStatement(getString("awrglobalhtml"));
				pStat.setLong(1, dbid);
				pStat.setLong(2, fsnap);
				pStat.setLong(3, lsnap);
			}
			pStat.setQueryTimeout(300);  // 5 minute timeout
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			boolean gotIn = false;
			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
					txtstr = new String();
				}
				txtstr = txtstr.concat(rset.getString(1) == null ? "" : rset
						.getString(1)/* .concat("\n") */);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = e.getMessage();
		}
		return txtstr;
	}

	public static String getHTMLDiffAWR(long dbid1, long inst1, 
			  long fsnap1, long lsnap1, long dbid2, long inst2, 
			  long fsnap2, long lsnap2, Connection con1) {
		String txtstr = new String("Could not retrieve AWR.");
		try {
			PreparedStatement pStat = null;
			if(inst1 > 0 && inst2 > 0){
				pStat = con1.prepareStatement(getString("awrdiffhtml"));
				pStat.setQueryTimeout(120);
				pStat.setLong(1, dbid1);
				pStat.setLong(2, inst1);
				pStat.setLong(3, fsnap1);
				pStat.setLong(4, lsnap1);
				pStat.setLong(5, dbid2);
				pStat.setLong(6, inst2);
				pStat.setLong(7, fsnap2);
				pStat.setLong(8, lsnap2);
			} else {
				pStat = con1.prepareStatement(getString("awrglobaldiffhtml"));
				pStat.setQueryTimeout(120);
				pStat.setLong(1, dbid1);
				pStat.setLong(2, fsnap1);
				pStat.setLong(3, lsnap1);
				pStat.setLong(4, dbid2);
				pStat.setLong(5, fsnap2);
				pStat.setLong(6, lsnap2);			}
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			boolean gotIn = false;
			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
					txtstr = new String();
				}
				txtstr = txtstr.concat(rset.getString(1) == null ? ""
						: rset.getString(1)/* .concat("\n") */);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = e.getMessage();
		}
		return txtstr;
	}

	public static String getJSONASHList(Connection con, String begDt, String endDt,
			int inst, String program, String userName, String sqlID, int sessionID){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			String mySQL = getString("getBegAshList") + 
			" and sample_time between " + begDt + " and " + endDt + " ";
			if ( inst > 0 ) {
				mySQL += "and INSTANCE_NUMBER = " + Integer.toString(inst) + " ";
			}
			if (program != null && program.length() > 0){
				mySQL += "and upper(program) like '" + Matcher.quoteReplacement(program.toUpperCase()) + "' ";
			}
			if (userName != null && userName.length() > 0){
				mySQL += "and upper(userName) = '" + userName.toUpperCase() + "' ";
			}
			if (sqlID != null && sqlID.length() > 0){
				mySQL += "and sqlID = '" + sqlID + "' ";
			}
			if (sqlID != null && sqlID.length() > 0){
				mySQL += "and sqlID = '" + sqlID + "' ";
			}
			if ( sessionID > 0 ) {
				mySQL += "and session_id = " + Integer.toString(sessionID) + " ";
			}
			mySQL += getString("getEndAshList");
			PreparedStatement pStat = con
					.prepareStatement(mySQL);
			pStat.setQueryTimeout(300); // trying 5 minutes was 2...
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(200);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getInt(1));
				inArray.put(spaceStr(rset.getString(2)));
				inArray.put(spaceStr(rset.getString(3)));
				inArray.put(rset.getInt(4));
				inArray.put(spaceStr(rset.getString(5)));
				inArray.put(spaceStr(rset.getString(6)));
				inArray.put(spaceStr(rset.getString(7)));
				inArray.put(rset.getLong(8));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static String getHTMLSQLMonitorList(long seconds, Connection con1) {
		String txtstr = new String("Could not retrieve SQL Monitor List.");
		try {
			PreparedStatement pStat = con1.prepareStatement(getString("sQLMonitorList"));
			pStat.setLong(1, seconds);
			pStat.setQueryTimeout(600); //10 minutes
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			boolean gotIn = false;
			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
					txtstr = new String();
				}
				txtstr = txtstr.concat(rset.getString(1) == null ? "" : rset
						.getString(1)/* .concat("\n") */);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = getString("sQLMonitorList") + "\n" + e.getMessage();
		}
		return txtstr;
	}

	public static String getHTMLSQLMonitorSQL(String sqlID, String execID, boolean HTMLOnly, Connection con1) {
		String txtstr = new String("Could not retrieve SQL Monitor List.");
		try {
			PreparedStatement pStat = con1.prepareStatement(getString("sQLMonitorSQL"));
			pStat.setString(1, sqlID);
			pStat.setString(2, execID);
			pStat.setString(3, HTMLOnly?"HTML":"ACTIVE");
			pStat.setQueryTimeout(600); //10 minutes
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			boolean gotIn = false;
			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
					txtstr = new String();
				}
				txtstr = txtstr.concat(rset.getString(1) == null ? "" : rset
						.getString(1)/* .concat("\n") */);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = getString("sQLMonitorSQL") + "\n" + e.getMessage();
		}
		return txtstr;
	}
	
	public static String getHTMLASH(long dbid, 
			long instanceNum, String firstTime, String lastTime,
			long sid, String sql_id, String wait_class,	String client_id,
			Connection con1) {
		String txtstr = new String("Could not retrieve ASH.");
		if(firstTime == null || lastTime == null){
			txtstr = new String("Could not retrieve ASH as passed Time was null.");
		}
		try {
			
			
			PreparedStatement pStat = null;
			if(instanceNum > 0){
				pStat = con1.prepareStatement(getString("ashHtml"));
				pStat.setLong(1, dbid);
				pStat.setLong(2, instanceNum);
				pStat.setString(3, firstTime);
				pStat.setString(4, lastTime);
				if (sid > 0){
					pStat.setLong(5, sid);	
				}else{
					pStat.setNull(5, java.sql.Types.NUMERIC);
				}
				if (sql_id != null && sql_id.length() > 0){
					pStat.setString(6, sql_id);	
				}else{
					pStat.setNull(6, java.sql.Types.VARCHAR);
				}
				if (wait_class != null && wait_class.length() > 0){
					pStat.setString(7, wait_class);	
				}else{
					pStat.setNull(7, java.sql.Types.VARCHAR);
				}
				if (client_id != null && client_id.length() > 0){
					pStat.setString(8, client_id);	
				}else{
					pStat.setNull(8, java.sql.Types.VARCHAR);
				}
			} else {
				pStat = con1.prepareStatement(getString("ashGlobalHtml"));
				pStat.setLong(1, dbid);
				pStat.setString(2, firstTime);
				pStat.setString(3, lastTime);
				if (sid > 0){
					pStat.setLong(4, sid);	
				}else{
					pStat.setNull(4, java.sql.Types.NUMERIC);
				}
				if (sql_id != null && sql_id.length() > 0){
					pStat.setString(5, sql_id);	
				}else{
					pStat.setNull(5, java.sql.Types.VARCHAR);
				}
				if (wait_class != null && wait_class.length() > 0){
					pStat.setString(6, wait_class);	
				}else{
					pStat.setNull(6, java.sql.Types.VARCHAR);
				}
				if (client_id != null && client_id.length() > 0){
					pStat.setString(7, client_id);	
				}else{
					pStat.setNull(7, java.sql.Types.VARCHAR);
				}
			}
			
			
			
			pStat.setQueryTimeout(1200); //20 minutes
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			boolean gotIn = false;
			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
					txtstr = new String();
				}
				txtstr = txtstr.concat(rset.getString(1) == null ? "" : rset
						.getString(1)/* .concat("\n") */);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = getString("ashHtml") + "\n" + e.getMessage();
		}
		return txtstr;
	}
	
	public static String getHTMLAWRSQL(long dbid, long inst, 
			  long fsnap, long lsnap, String sqlid, Connection con1) {
		String txtstr = new String("Could not AWR SQL Report.");
		try {
			PreparedStatement pStat = con1
					.prepareStatement(getString("awrsqlhtml"));
			pStat.setLong(1, dbid);
			pStat.setLong(2, inst);
			pStat.setLong(3, fsnap);
			pStat.setLong(4, lsnap);
			pStat.setString(5, sqlid);
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			boolean gotIn = false;
			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
					txtstr = new String();
				}
				txtstr = txtstr.concat(rset.getString(1) == null ? "" : rset
						.getString(1)/* .concat("\n") */);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = e.getMessage();
		}
		return txtstr;
	}

	public static String getSqlPlan(String sqlID, Connection con1) {

		String txtstr = new String("Could not find SqlPlan.");
		try {
			PreparedStatement pStat = con1.prepareStatement(getString("sqlrep")
					.replaceAll("XXXX", Matcher.quoteReplacement(sqlID)));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			boolean gotIn = false;
			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
					txtstr = new String();
				}
				txtstr = txtstr.concat(rset.getString(1).concat("\n"));
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
			txtstr = e.getMessage();
		}
		return txtstr;
	}


	public static String getJSONSqlPlan( Connection con, String SQLIDString){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray =  new JSONArray();

		String outStr = DbSQL.getSqlPlan(SQLIDString, con);
		if (outStr.equalsIgnoreCase("Could not find SqlPlan.")) {
			outStr = DbSQL.getSql(SQLIDString, con);
		} else if(outStr.contains("ORA-06502")){
			outStr = ("SQL\n").concat(DbSQL.getSql(SQLIDString, con)).concat("\n\n").concat(outStr); 
		}
		inArray.put(outStr);
		outArray.put(inArray);
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	
	public static String getJSONSqlId( Connection con, String SQLIDString){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con.prepareStatement(getString(SQLIDString));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getString(2));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONSqlIdPlans(String sqlID, Connection con1) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con1.prepareStatement(getString(
					"getSQLPlans").replaceAll("XXXX", Matcher.quoteReplacement(sqlID)));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			boolean gotIn = false;

			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
				}
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getSqlDDL(String sqlID, Connection con1) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con1.prepareStatement(getString(
					"getSQLDDL").replaceAll("XXXX", Matcher.quoteReplacement(sqlID)));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			boolean gotIn = false;
			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
				}
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getString(2));
				inArray.put(rset.getString(3));
				inArray.put(rset.getString(4));
				inArray.put(rset.getString(5));
				inArray.put(rset.getString(6));
				Clob ddl = rset.getClob(7);
				inArray.put(ddl.getSubString(1, (int) ddl.length()));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONSqlObjects( Connection con, String sqlID){
		if(sqlID == null){ return null; }
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con.prepareStatement(getString(
			"getSQLObjects").replaceAll("XXXX", Matcher.quoteReplacement(sqlID)));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getString(2));
				inArray.put(rset.getString(3));
				inArray.put(rset.getString(4));
				inArray.put(rset.getString(5));
				inArray.put(rset.getString(6));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONSqlIdBindValues( Connection con, String sqlID){
		if(sqlID == null){ return null; }
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con.prepareStatement(getString(
			"bindValues").replaceAll("XXXX", Matcher.quoteReplacement(sqlID)));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(spaceStr(rset.getString(1)));
				inArray.put(spaceStr(rset.getString(2)));
				inArray.put(spaceStr(rset.getString(3)));
				inArray.put(spaceStr(rset.getString(4)));
				inArray.put(spaceStr(rset.getString(5)));
				inArray.put(spaceStr(rset.getString(6)));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONSqlIdBindTypes( Connection con, String sqlID){
		if(sqlID == null){ return null; }
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con.prepareStatement(getString(
			"bindTypes").replaceAll("XXXX", Matcher.quoteReplacement(sqlID)));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getString(2));
				inArray.put(rset.getString(3));
				inArray.put(rset.getString(4));
				inArray.put(rset.getString(5));
				inArray.put(rset.getString(6));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}


	
	public static String getJSONTableInfo(Connection con1, String owner, String table) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con1.prepareStatement((getString(
					"getTableInfo").replaceAll("XXXX", Matcher.quoteReplacement(owner))).replaceAll("ZZZZ", Matcher.quoteReplacement(table)));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			if (rset.next()) {
				int x = 1;

				inArray =  new JSONArray();
				inArray.put("Schema");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Name");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Status");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Partitioned");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Degree");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Instance");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Cache");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Buffer Pool");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Clust Owner");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Clust Name");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("IOT Name");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("IOT Type");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Temporary");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Tmp Duration");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Nested");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Dependency");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Skip Corrupt");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Monitoring");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Backed Up");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Dropped");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Tablespace");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Compression");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Ini Trans");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Max Trans");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Initial Extent");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Next Extent");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Pct Free");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Pct Used");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Pct Increase");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("FreeLists");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("FreeList Grs");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Logging");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Last Analyzed");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Sample Size");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Global Stats");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("User Stats");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Rows");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Blocks");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Empty Blocks");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Avg Space");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Chain Count");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Avg Length");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Avg Spc Freelst Blks");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Num Freelst Blks");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}


	public static String getJSONTableColumnInfo(Connection con1, String owner, String table) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con1.prepareStatement(getString(
					"getTableColumnInfo").replaceAll("XXXX", Matcher.quoteReplacement(owner)).replaceAll("ZZZZ", Matcher.quoteReplacement(table)));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			boolean gotIn = false;
			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
				}
				inArray =  new JSONArray();
				for(int x = 1; x <= 24; x++ ){
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static String getJSONTableIndexInfo(Connection con1, String owner, String table) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		boolean retry = false;
		try {
			PreparedStatement pStat = null;
			ResultSet rset = null;
			try{
				pStat = con1.prepareStatement(getString(
						"getTableIndexInfo").replaceAll("XXXX", Matcher.quoteReplacement(owner)).replaceAll("ZZZZ", Matcher.quoteReplacement(table)));
				pStat.setQueryTimeout(120);
				rset = pStat.executeQuery();
				rset.setFetchSize(100);
			} catch (SQLException e) {
				if(e.getLocalizedMessage().contains("1780")){
					if(pStat != null){
						try{
							pStat.close();
						} catch(Exception e2){
						}
					}
					retry = true; 
				}
			} 
			if(retry){
				pStat = con1.prepareStatement(getString("setCursorShare"));
				pStat.setQueryTimeout(120);
				pStat.execute();
				pStat = con1.prepareStatement(getString(
					"getTableIndexInfo").replaceAll("XXXX", Matcher.quoteReplacement(owner)).replaceAll("ZZZZ", Matcher.quoteReplacement(table)));
				pStat.setQueryTimeout(120);
				rset = pStat.executeQuery();
				rset.setFetchSize(100);
			}
			
			boolean gotIn = false;
			while (rset.next()) {
				if (!gotIn) {
					gotIn = true;
				}
				inArray =  new JSONArray();
				for(int x = 1; x <= 38; x++ ){
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return result.toString();
	}

	public /* synchronized JOHN */ static void makeChartPNG(JFreeChart chart, int width, int height,
			OutputStream fl) {
		SunPNGEncoderAdapter x = new SunPNGEncoderAdapter();
		try {
			x.encode(chart.createBufferedImage(width, height), fl);
		} catch (IOException e) {
			System.err.println("PNG Error in makeChartPNG");
			e.printStackTrace();
		}
	}

	public static XYDataset getSQLxyDataset(Connection con, String sqlID,
			String sqlStatement) {
		JDBCXYDataset xyDataset = null;
		try {
			xyDataset = new JDBCXYDataset(con);
			xyDataset.executeQuery(getString(sqlStatement).replaceAll("XXXX",
					Matcher.quoteReplacement(sqlID)));
		} catch (SQLException y) {
			y.printStackTrace();
		}
		return xyDataset;
	}

	public static String getSysEvtList(Connection con1) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;

		try {
			PreparedStatement pStat = con1.prepareStatement(getString(
					"getSysEventList"));
			pStat.setQueryTimeout(210);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getString(2));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result.toString();
	}

	
	public static String getJSONSysEvt(Connection con, String[] EventName, int days) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		if (EventName == null || EventName.length < 1) {
			System.err.println("getSysEvt received invalid EventName.");
			return null;
		}
		try {
			String sql = getString("getSysEvent").replaceAll("AAAA",
					Matcher.quoteReplacement(EventName[0])).
					replaceAll("ZZZZ",
							Matcher.quoteReplacement(Integer.toString(days)));
			if (EventName.length > 1) {
				sql = sql.replaceAll("BBBB",
						Matcher.quoteReplacement(EventName[1]));
			}
			if (EventName.length > 2) {
				sql = sql.replaceAll("CCCC",
						Matcher.quoteReplacement(EventName[2]));
			}
			if (EventName.length > 3) {
				sql = sql.replaceAll("DDDD",
						Matcher.quoteReplacement(EventName[3]));
			}
			if (EventName.length > 4) {
				sql = sql.replaceAll("EEEE",
						Matcher.quoteReplacement(EventName[4]));
			}
			PreparedStatement pStat = con.prepareStatement(sql);
			pStat.setQueryTimeout(600);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));					//name
				inArray.put(rset.getTimestamp(2).toString());	//dt
				inArray.put(rset.getLong(3));					//total waits
				inArray.put(rset.getLong(4));					//avg MS
				inArray.put(rset.getLong(5));					//total MS
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static XYDataset getSysEvtxyDataset(String JSONSysEvt) {
		DateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<TimeSeries> tsList = new ArrayList<TimeSeries>();
		Calendar cal = Calendar.getInstance();
		int y = 0;
		boolean found = false;
		try{
		JSONObject result = new JSONObject(JSONSysEvt);    
		JSONArray outArray = (JSONArray) result.getJSONArray("aaData");
		JSONArray inArray = null;
		for(int x = 0; x < outArray.length(); x++){
			inArray = outArray.getJSONArray(x);
				found = false;
				cal.setTime(dfm.parse(inArray.getString(1)));
				for (y = (tsList.size() > 6) ? tsList.size() - 6 : 0; y < tsList
						.size(); y++) {
					if (tsList.get(y).getDescription()
							.equalsIgnoreCase(inArray.getString(0).concat(" Qty"))) {
						found = true;
						tsList.get(y).addOrUpdate(
								new Hour(cal.getTime()), inArray.getLong(2));
						tsList.get(y+1).addOrUpdate(
								new Hour(cal.getTime()), inArray.getLong(3));
						tsList.get(y+2).addOrUpdate(
								new Hour(cal.getTime()), inArray.getLong(4));
					}
				}
				if (!found) {
					TimeSeries q;
					q = new TimeSeries(inArray.getString(0).concat(" Qty"));
					q.setDescription(inArray.getString(0).concat(" Qty"));
					q.add(new TimeSeriesDataItem(
							new Hour(cal.getTime()), inArray.getLong(2)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Avg Ms"));
					q.setDescription(inArray.getString(0).concat(" Avg Ms"));
					q.add(new TimeSeriesDataItem(
							new Hour(cal.getTime()), inArray.getLong(3)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Tot Ms"));
					q.setDescription(inArray.getString(0).concat(" Tot Ms"));
					q.add(new TimeSeriesDataItem(
							new Hour(cal.getTime()), inArray.getLong(4)));
					tsList.add(q);
				}
			}
		} catch(Exception e){
			e.printStackTrace();
		}
		if(tsList.size() > 0){
		TimeSeriesCollection ts = new TimeSeriesCollection();
		for (y = 0; y < tsList.size(); y++) {
			ts.addSeries(tsList.get(y));
		}
		return ts;
		}
		System.err.println("Got no rows in getSysEvtxyDataset");
		return null;
	}

	public static String getSysSumList(Connection con1) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con1.prepareStatement(getString(
					"getSysSumList"));
			pStat.setQueryTimeout(210);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getString(2));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result.toString();
	}
	
	
	public static String getJSONSysSum(Connection con, String[] EventName, int days) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		if (EventName == null || EventName.length < 1) {
			System.err.println("getSysSum received invalid EventName.");
			return null;
		}
		try {
			String sql = getString("getSysSum").replaceAll("AAAA",
					Matcher.quoteReplacement(EventName[0])).
					replaceAll("ZZZZ",
							Matcher.quoteReplacement(Integer.toString(days)));
			if (EventName.length > 1) {
				sql = sql.replaceAll("BBBB",
						Matcher.quoteReplacement(EventName[1]));
			}
			if (EventName.length > 2) {
				sql = sql.replaceAll("CCCC",
						Matcher.quoteReplacement(EventName[2]));
			}
			if (EventName.length > 3) {
				sql = sql.replaceAll("DDDD",
						Matcher.quoteReplacement(EventName[3]));
			}
			if (EventName.length > 4) {
				sql = sql.replaceAll("EEEE",
						Matcher.quoteReplacement(EventName[4]));
			}
			PreparedStatement pStat = con.prepareStatement(sql);
			pStat.setQueryTimeout(600);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));					//name
				inArray.put(rset.getTimestamp(2).toString());	//dt
				inArray.put(rset.getLong(3));					//min
				inArray.put(rset.getLong(4));					//avg
				inArray.put(rset.getLong(5));					//max
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static XYDataset getSysSumxyDataset(String JSONSysEvt) {
		DateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<TimeSeries> tsList = new ArrayList<TimeSeries>();
		Calendar cal = Calendar.getInstance();
		int y = 0;
		boolean found = false;
		try{
		JSONObject result = new JSONObject(JSONSysEvt);    
		JSONArray outArray = (JSONArray) result.getJSONArray("aaData");
		JSONArray inArray = null;
		for(int x = 0; x < outArray.length(); x++){
			inArray = outArray.getJSONArray(x);
				found = false;
				cal.setTime(dfm.parse(inArray.getString(1)));
				for (y = (tsList.size() > 6) ? tsList.size() - 6 : 0; y < tsList
						.size(); y++) {
					if (tsList.get(y).getDescription()
							.equalsIgnoreCase(inArray.getString(0).concat(" Min"))) {
						found = true;
						tsList.get(y).addOrUpdate(
								new Hour(cal.getTime()), inArray.getLong(2));
						tsList.get(y+1).addOrUpdate(
								new Hour(cal.getTime()), inArray.getLong(3));
						tsList.get(y+2).addOrUpdate(
								new Hour(cal.getTime()), inArray.getLong(4));
					}
				}
				if (!found) {
					TimeSeries q;
					q = new TimeSeries(inArray.getString(0).concat(" Min"));
					q.setDescription(inArray.getString(0).concat(" Min"));
					q.add(new TimeSeriesDataItem(
							new Hour(cal.getTime()), inArray.getLong(2)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Avg"));
					q.setDescription(inArray.getString(0).concat(" Avg"));
					q.add(new TimeSeriesDataItem(
							new Hour(cal.getTime()), inArray.getLong(3)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Max"));
					q.setDescription(inArray.getString(0).concat(" Max"));
					q.add(new TimeSeriesDataItem(
							new Hour(cal.getTime()), inArray.getLong(4)));
					tsList.add(q);
				}
			}
		} catch(Exception e){
			e.printStackTrace();
		}
		if(tsList.size() > 0){
		TimeSeriesCollection ts = new TimeSeriesCollection();
		for (y = 0; y < tsList.size(); y++) {
			ts.addSeries(tsList.get(y));
		}
		return ts;
		}
		System.err.println("Got no rows in getSysSumxyDataset");
		return null;
	}

	
	public static String getJSONMemory(Connection con, int days) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		String sql = "";
		try {
			sql = getString("getMemoryOverTime").
					replaceAll("XXXX",
							Matcher.quoteReplacement(Integer.toString(days)));
			PreparedStatement pStat = con.prepareStatement(sql);
			pStat.setQueryTimeout(600);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));					//Instance
				inArray.put(rset.getString(2));					//dt
				inArray.put(rset.getLong(3));					//fixed SGA
				inArray.put(rset.getLong(4));					//log buffer
				inArray.put(rset.getLong(5));					//java pool
				inArray.put(rset.getLong(6));					//large pool
				inArray.put(rset.getLong(7));					//streams pool
				inArray.put(rset.getLong(8));					//buffer cache
				inArray.put(rset.getLong(9));					//shared pool
				inArray.put(rset.getLong(10));					//SGA
				inArray.put(rset.getLong(11));					//PGA
				inArray.put(rset.getLong(12));					//Total
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			System.err.println(sql);
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static XYDataset getMemoryDataset(String JSONMemory) {
		DateFormat dfm = new SimpleDateFormat("MM/dd/yyyy HH:mm");
		List<TimeSeries> tsList = new ArrayList<TimeSeries>();
		Calendar cal = Calendar.getInstance();
		int y = 0;
		boolean found = false;
		try{
		JSONObject result = new JSONObject(JSONMemory);    
		JSONArray outArray = (JSONArray) result.getJSONArray("aaData");
		JSONArray inArray = null;
		for(int x = 0; x < outArray.length(); x++){
			inArray = outArray.getJSONArray(x);
				found = false;
				cal.setTime(dfm.parse(inArray.getString(1)));
				for (y = /*(tsList.size() > 20) ? tsList.size() - 20 :*/ 0; y < tsList
						.size(); y++) {
					if (tsList.get(y).getDescription()
							.equalsIgnoreCase(inArray.getString(0).concat(" Fixed SGA"))) {
						found = true;
						for(int z = 0; z < 10; z++ ){
							tsList.get(y + z).addOrUpdate(new Minute(cal.getTime()), inArray.getLong(z + 2));
						}
					}
				}
				if (!found) {
					TimeSeries q;
					q = new TimeSeries(inArray.getString(0).concat(" Fixed SGA"));
					q.setDescription(inArray.getString(0).concat(" Fixed SGA"));
					q.add(new TimeSeriesDataItem(
							new Minute(cal.getTime()), inArray.getLong(2)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Log Buffer"));
					q.setDescription(inArray.getString(0).concat(" Log Buffer"));
					q.add(new TimeSeriesDataItem(
							new Minute(cal.getTime()), inArray.getLong(3)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Java Pool"));
					q.setDescription(inArray.getString(0).concat(" Java Pool"));
					q.add(new TimeSeriesDataItem(
							new Minute(cal.getTime()), inArray.getLong(4)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Large Pool"));
					q.setDescription(inArray.getString(0).concat(" Large Pool"));
					q.add(new TimeSeriesDataItem(
							new Minute(cal.getTime()), inArray.getLong(5)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Streams Pool"));
					q.setDescription(inArray.getString(0).concat(" Streams Pool"));
					q.add(new TimeSeriesDataItem(
							new Minute(cal.getTime()), inArray.getLong(6)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Buffer Pool"));
					q.setDescription(inArray.getString(0).concat(" Buffer Pool"));
					q.add(new TimeSeriesDataItem(
							new Minute(cal.getTime()), inArray.getLong(7)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Shared Pool"));
					q.setDescription(inArray.getString(0).concat(" Shared Pool"));
					q.add(new TimeSeriesDataItem(
							new Minute(cal.getTime()), inArray.getLong(8)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" SGA Total"));
					q.setDescription(inArray.getString(0).concat(" SGA Total"));
					q.add(new TimeSeriesDataItem(
							new Minute(cal.getTime()), inArray.getLong(9)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" PGA Total"));
					q.setDescription(inArray.getString(0).concat(" PGA Total"));
					q.add(new TimeSeriesDataItem(
							new Minute(cal.getTime()), inArray.getLong(10)));
					tsList.add(q);
					q = new TimeSeries(inArray.getString(0).concat(" Total"));
					q.setDescription(inArray.getString(0).concat(" Total"));
					q.add(new TimeSeriesDataItem(
							new Minute(cal.getTime()), inArray.getLong(11)));
					tsList.add(q);
				}
			}
		} catch(Exception e){
			e.printStackTrace();
		}
		if(tsList.size() > 0){
			TimeSeriesCollection ts = new TimeSeriesCollection();
			for (y = 0; y < tsList.size(); y++) {
				ts.addSeries(tsList.get(y));
			}
			return ts;
		}
		System.err.println("Got no rows in getMemoryDataset");
		return null;
	}
	
	
	public static XYDataset getDBSizeDataset(String JSONDBSize) {
		DateFormat dfm = new SimpleDateFormat("MM/dd/yyyy");
		List<TimeSeries> tsList = new ArrayList<TimeSeries>();
		Calendar cal = Calendar.getInstance();
		int y = 0;
		boolean firstone = true;
		try {
			JSONObject result = new JSONObject(JSONDBSize);
			JSONArray outArray = (JSONArray) result.getJSONArray("aaData");
			JSONArray inArray = null;
			for (int x = 0; x < outArray.length(); x++) {
				inArray = outArray.getJSONArray(x);
				cal.setTime(dfm.parse(inArray.getString(0)));
				if (firstone) {
					TimeSeries q;
					q = new TimeSeries("Size GB");
					q.setDescription("Size GB");
					q.add(new TimeSeriesDataItem(new Minute(cal.getTime()),
							inArray.getLong(1)));
					tsList.add(q);
					q = new TimeSeries("Used GB");
					q.setDescription("Used GB");
					q.add(new TimeSeriesDataItem(new Minute(cal.getTime()),
							inArray.getLong(2)));
					tsList.add(q);
					q = new TimeSeries("Max GB");
					q.setDescription("Max GB");
					q.add(new TimeSeriesDataItem(new Minute(cal.getTime()),
							inArray.getLong(3)));
					tsList.add(q);
					firstone = false;
				} else {
					for (int z = 0; z < 3; z++) {
						tsList.get(z).addOrUpdate(new Minute(cal.getTime()), inArray
												.getLong(z + 1));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (tsList.size() > 0) {
			TimeSeriesCollection ts = new TimeSeriesCollection();
			for (y = 0; y < tsList.size(); y++) {
				ts.addSeries(tsList.get(y));
			}
			return ts;
		}
		System.err.println("Got no rows in getDBSizeDataset");
		return null;
	}
	
	public static String getJSONLogSwitch(Connection con, int days) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			String sql = getString("getLogSwitch").replaceAll("ZZZZ",
					Matcher.quoteReplacement(Integer.toString(days)))
					.replaceAll("YYYY",
					Matcher.quoteReplacement(Integer.toString((days > 7)?4:1)));
			PreparedStatement pStat = con.prepareStatement(sql);
			pStat.setQueryTimeout(600);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));					//thread
				inArray.put(rset.getTimestamp(2).toString());	//dt
				inArray.put(rset.getLong(3));					//count
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static XYDataset getLogSwitchxyDataset(String JSONSysEvt) {
		DateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<TimeSeries> tsList = new ArrayList<TimeSeries>();
		Calendar cal = Calendar.getInstance();
		int y = 0;
		boolean found = false;
		try{
		JSONObject result = new JSONObject(JSONSysEvt);    
		JSONArray outArray = (JSONArray) result.getJSONArray("aaData");
		JSONArray inArray = null;
		for(int x = 0; x < outArray.length(); x++){
			inArray = outArray.getJSONArray(x);
				found = false;
				cal.setTime(dfm.parse(inArray.getString(1)));
				for (y = (tsList.size() > 6) ? tsList.size() - 6 : 0; y < tsList
						.size(); y++) {
					if (tsList.get(y).getDescription()
							.equalsIgnoreCase(inArray.getString(0))) {
						found = true;
						tsList.get(y).addOrUpdate(new Hour(cal.getTime()), inArray.getLong(2));
					}
				}
				if (!found) {
					TimeSeries q;
					q = new TimeSeries(inArray.getString(0));
					q.setDescription(inArray.getString(0));
					q.add(new TimeSeriesDataItem(
							new Hour(cal.getTime()), inArray.getLong(2)));
					tsList.add(q);
				}
			}
		} catch(Exception e){
			e.printStackTrace();
		}
		if(tsList.size() > 0){
		TimeSeriesCollection ts = new TimeSeriesCollection();
		for (y = 0; y < tsList.size(); y++) {
			ts.addSeries(tsList.get(y));
		}
		return ts;
		}
		System.err.println("Got no rows in getLogSwitchxyDataset");
		return null;
	}

	public static String getJSONRedoStandbyLogs(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("getRedoStandbyLogs"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				for(int x = 1; x <= 11; x++) {
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	
	public static List <String> getSQLCsvFromJSON(String JSONSqlPerfList) {
		//import java.text.DateFormat;
		//import java.text.SimpleDateFormat;
		//DateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//.concat(dfm.format(sqlPerf.get(itm).getBeginTm()))
		ArrayList<String> csv = new ArrayList<String>();
		csv.add("\"Begin\",\"End\",\"SQL ID\",\"Plan\",\"Profile\",\"Executions\",\"Rows Exec\",\"Fetches Exec\","
				+ "\"MS Exec\",\"MS CPU Exec\",\"MS IO Exec\",\"Disk Reads Exec\",\"MS Read\",\"Buffer Gets Exec\"," 
				+"\"MS Clstr Exec\",\"MS Concr Exec\"\n");
		try{
			JSONObject inJson = new JSONObject(JSONSqlPerfList);    
			JSONArray outArray = (JSONArray) inJson.getJSONArray("aaData");
			JSONArray inArray = null;
			for(int x = 0; x < outArray.length(); x++){
				inArray = outArray.getJSONArray(x);
				String outStr = new String();
				outStr = "\"" + inArray.getString(0);
				outStr = outStr.concat("\",\"").concat(inArray.getString(1));
				outStr = outStr.concat("\",\"").concat(inArray.getString(2));
				outStr = outStr.concat("\",\"").concat(Long.toString(inArray.getLong(3)));
				outStr = outStr.concat("\",\"").concat(inArray.getString(4));
				for(int y = 5; y < 16; y++){
					outStr = outStr.concat("\",\"").concat(Long.toString(inArray.getLong(y)));

				}
				outStr = outStr.concat("\"\n");
				csv.add(outStr);
			}
		} catch (Exception ex){
			ex.printStackTrace();
		}
		return csv;
	}


	public static XYDataset getSQLxyDataset(String JSONSqlPerfList) {
		DateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<TimeSeries> tsList = new ArrayList<TimeSeries>();
		TimeSeriesCollection ts = new TimeSeriesCollection();
		// this section by hour into for hourly averages
		try{
			JSONObject inJson = new JSONObject(JSONSqlPerfList);    
			JSONArray outArray = (JSONArray) inJson.getJSONArray("aaData");
			JSONArray inArray = null;
			JSONArray outArray2 = new JSONArray();
			JSONArray inArray2 = null;
			Calendar cal = Calendar.getInstance();
			for(int x = 0; x < outArray.length(); x++){
				inArray = outArray.getJSONArray(x);
				cal.setTime(dfm.parse(inArray.getString(0)));
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
				String truncDt = dfm.format(cal.getTime());
				
				if(inArray2 != null && 
				    ( (!inArray2.getString(0).equalsIgnoreCase(truncDt))  // Same time
				      //|| (!inArray2.getString(2).equalsIgnoreCase(inArray.getString(2)))  // Same SQL ID 		
				      || (inArray2.getLong(1) != inArray.getLong(3))   // Same SQL Plan		
				    )){
				    outArray2.put(inArray2);
				    inArray2 = null;
				}
				
				if(inArray2 == null){
					//create new inArray2
					inArray2 = new JSONArray();
					inArray2.put(0, dfm.format(cal.getTime()));         //set the 0th element to the truncated date
					inArray2.put(1, inArray.getLong(3));      //SQL Plan
					inArray2.put(2, inArray.getLong(5) + 0);  //See below for description 2-10
					inArray2.put(3, inArray.getLong(6) + 0);  
					inArray2.put(4, inArray.getLong(7) + 0);  
					inArray2.put(5, inArray.getLong(8) + 0);  
					inArray2.put(6, inArray.getLong(9) + 0);  
					inArray2.put(7, inArray.getLong(10) + 0);  
					inArray2.put(8, inArray.getLong(11) + 0);  
					inArray2.put(9, inArray.getLong(12) + 0);   
					inArray2.put(10, inArray.getLong(13) + 0);  
				} else{
					long lstExec = inArray2.getLong(2) + 0;
					long curExec = inArray.getLong(5) + 0;
					long totExec = lstExec + curExec;
					inArray2.put(2, totExec);																	// tot exec
					//Below fix to allow 0 calls and not have divide by 0 error
					if(totExec == 0){  // this is to allow graphs despite 0 executions during snapshot window
						totExec = 1;
					}
					if(curExec == 0){  // fix math for 0 execs...  this makes a 0 exec count as 1 exec
						curExec = 1;
					}
					if(lstExec == 0){  // fix math for 0 execs...  this makes a 0 exec count as 1 exec
						lstExec = 1;
					}
					//Above fix to allow 0 calls and not have divide by 0 error					
					inArray2.put(3, ((inArray.getLong(6) * curExec)+(inArray2.getLong(3) * lstExec))/totExec);  // rowpe
					inArray2.put(4, ((inArray.getLong(7) * curExec)+(inArray2.getLong(4) * lstExec))/totExec);  // fetchepe
					inArray2.put(5, ((inArray.getLong(8) * curExec)+(inArray2.getLong(5) * lstExec))/totExec);  // mspe 
					inArray2.put(6, ((inArray.getLong(9) * curExec)+(inArray2.getLong(6) * lstExec))/totExec);  // cpupe
					inArray2.put(7, ((inArray.getLong(10) * curExec)+(inArray2.getLong(7) * lstExec))/totExec); // iope 
					inArray2.put(8, ((inArray.getLong(11) * curExec)+(inArray2.getLong(8) * lstExec))/totExec); // readspe 
					inArray2.put(9, (inArray2.getLong(8) == 0)?0:inArray2.getLong(7)/inArray2.getLong(8));      // msrd  
					inArray2.put(10, ((inArray.getLong(13) * curExec)+(inArray2.getLong(9) * lstExec))/totExec); // bufferpe
				}
			}
			if(inArray2 != null){
			    outArray2.put(inArray2);
			}

			boolean found;
			int x, y;
			// this section converts the hourly average list into timeseries data
			for (x = 0; x < outArray2.length(); x++) {
				found = false;
				inArray2 = outArray2.getJSONArray(x);
				cal.setTime(dfm.parse(inArray2.getString(0))); 
				for (y = 0; y < tsList.size(); y += 8) {
					if (tsList.get(y).getDescription().equalsIgnoreCase(Long.toString(inArray2.getLong(1)).concat(" EXECUTIONS"))) {
						found = true;
						tsList.get(y).addOrUpdate(
								new Hour(cal.getTime()),
										inArray2.getLong(2));
						tsList.get(y + 1).addOrUpdate(
								new Hour(cal.getTime()),
										inArray2.getLong(3));
						tsList.get(y + 2).addOrUpdate(
								new Hour(cal.getTime()),
										inArray2.getLong(4));
						tsList.get(y + 3).addOrUpdate(
								new Hour(cal.getTime()),
										inArray2.getLong(5));
						tsList.get(y + 4).addOrUpdate(
								new Hour(cal.getTime()),
										inArray2.getLong(6));
						tsList.get(y + 5).addOrUpdate(
								new Hour(cal.getTime()),
										inArray2.getLong(7));
						tsList.get(y + 6).addOrUpdate(
								new Hour(cal.getTime()),
										inArray2.getLong(8));
						tsList.get(y + 7).addOrUpdate(
								new Hour(cal.getTime()),
										inArray2.getLong(10));
					}
				}
				if (!found) {
					TimeSeries q;
					q = new TimeSeries(Long.toString(inArray2.getLong(1)).concat(
							" EXECUTIONS"));
					q.setDescription(Long.toString(inArray2.getLong(1)).concat(
							" EXECUTIONS"));
					q.add(new TimeSeriesDataItem(new Hour(cal.getTime()), inArray2.getLong(2)));
					tsList.add(q);
					q = new TimeSeries(Long.toString(inArray2.getLong(1)).concat(
							" ROWS PE"));
					q.setDescription(Long.toString(inArray2.getLong(1)).concat(
							" ROWS PE"));
					q.add(new TimeSeriesDataItem(new Hour(cal.getTime()), inArray2.getLong(3)));
					tsList.add(q);
					q = new TimeSeries(Long.toString(inArray2.getLong(1)).concat(
							" FETCHES PE"));
					q.setDescription(Long.toString(inArray2.getLong(1)).concat(
							" FETCHES PE"));
					q.add(new TimeSeriesDataItem(new Hour(cal.getTime()), inArray2.getLong(4)));
					tsList.add(q);
					q = new TimeSeries(Long.toString(inArray2.getLong(1)).concat(
							" TIME MS PE"));
					q.setDescription(Long.toString(inArray2.getLong(1)).concat(
							" TIME MS PE"));
					q.add(new TimeSeriesDataItem(new Hour(cal.getTime()), inArray2.getLong(5)));
					tsList.add(q);
					q = new TimeSeries(Long.toString(inArray2.getLong(1)).concat(
							" CPU MS PE"));
					q.setDescription(Long.toString(inArray2.getLong(1)).concat(
							" CPU MS PE"));
					q.add(new TimeSeriesDataItem(new Hour(cal.getTime()), inArray2.getLong(6)));
					tsList.add(q);
					q = new TimeSeries(Long.toString(inArray2.getLong(1)).concat(
							" IO MS PE"));
					q.setDescription(Long.toString(inArray2.getLong(1)).concat(
							" IO MS PE"));
					q.add(new TimeSeriesDataItem(new Hour(cal.getTime()), inArray2.getLong(7)));
					tsList.add(q);
					q = new TimeSeries(Long.toString(inArray2.getLong(1)).concat(
							" IO READS PE"));
					q.setDescription(Long.toString(inArray2.getLong(1)).concat(
							" IO READS PE"));
					q.add(new TimeSeriesDataItem(new Hour(cal.getTime()), inArray2.getLong(8)));
					tsList.add(q);
					//q = new TimeSeries(Long.toString(inArray2.getLong(1)).concat(
					//		" MS PER READ"));
					//q.setDescription(Long.toString(inArray2.getLong(1)).concat(
					//		" MS PER READ"));
					//q.add(new TimeSeriesDataItem(new Hour(cal.getTime()), inArray2.getLong(9)));
					//tsList.add(q);
					q = new TimeSeries(Long.toString(inArray2.getLong(1)).concat(
							" BUF GETS PE"));
					q.setDescription(Long.toString(inArray2.getLong(1)).concat(
							" BUF GETS PE"));
					q.add(new TimeSeriesDataItem(new Hour(cal.getTime()), inArray2.getLong(10)));
					tsList.add(q);
				}
			}
		} catch (Exception ex){
			ex.printStackTrace();
		}

		for (int y = 0; y < tsList.size(); y++) {
			ts.addSeries(tsList.get(y));
		}
		return ts;
	}

	public static String getJSONSQLBySQLID(Connection con, String sqlID, int hours){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = null;
			if(hours < 1 ){
			  pStat = con.prepareStatement(getString( "getSQLPlan")
					    .replaceAll("XXXX", Matcher.quoteReplacement(sqlID)));
			  System.out.println(getString( "getSQLPlan")
					    .replaceAll("XXXX", Matcher.quoteReplacement(sqlID)));
			} else {
				if(hours > 24) {
					hours = 24;
				}
				pStat = con.prepareStatement(getString(	"getSQLPlanHrly")
						.replaceAll("XXXX", Matcher.quoteReplacement(sqlID))
						.replaceAll("YYYY", Matcher.quoteReplacement(Integer.toString(hours))));
				System.out.println(getString(	"getSQLPlanHrly")
						.replaceAll("XXXX", Matcher.quoteReplacement(sqlID))
						.replaceAll("YYYY", Matcher.quoteReplacement(Integer.toString(hours))));
			}
			
			pStat.setQueryTimeout(600);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getTimestamp(1).toString());
				inArray.put(rset.getTimestamp(2).toString());
				inArray.put(spaceStr(rset.getString(3)));
				inArray.put(rset.getLong(4));
				inArray.put(spaceStr(rset.getString(5)));
				inArray.put(rset.getLong(6));
				inArray.put(rset.getLong(7));
				inArray.put(rset.getLong(8));
				inArray.put(rset.getLong(9));
				inArray.put(rset.getLong(10));
				inArray.put(rset.getLong(11));
				inArray.put(rset.getLong(12));
				inArray.put(rset.getLong(13));
				inArray.put(rset.getLong(14));
				inArray.put(rset.getLong(15)); //added cluster wait
				inArray.put(rset.getLong(16)); // added concur wait
				outArray.put(inArray);

			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result.toString();
	}

	
	public static String getJSONSQLByText(Connection con, String sqlText){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			sqlText = sqlText.replaceAll(" ", "%").replaceAll("\n", "%").replaceAll("	", "%");
			PreparedStatement pStat = con.prepareStatement(getString(
					"getSQLPlanBySQL").replaceAll("XXXX", Matcher.quoteReplacement(sqlText)));
System.err.println(getString(
		"getSQLPlanBySQL").replaceAll("XXXX", Matcher.quoteReplacement(sqlText)));
			pStat.setQueryTimeout(600);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getTimestamp(1).toString());
				inArray.put(rset.getTimestamp(2).toString());
				inArray.put(rset.getString(3));
				inArray.put(rset.getLong(4));
				inArray.put(spaceStr(rset.getString(5)));
				inArray.put(rset.getLong(6));
				inArray.put(rset.getLong(7));
				inArray.put(rset.getLong(8));
				inArray.put(rset.getLong(9));
				inArray.put(rset.getLong(10));
				inArray.put(rset.getLong(11));
				inArray.put(rset.getLong(12));
				inArray.put(rset.getLong(13));
				inArray.put(rset.getLong(14));
				inArray.put(rset.getLong(15)); 
				inArray.put(rset.getLong(16));
				outArray.put(inArray);

			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result.toString();
	}

	public static PieDataset getSessWaitxyDataset(
			String JSONSessionWait) {
		DefaultPieDataset dataset = new DefaultPieDataset();
		try{
			JSONObject result = new JSONObject(JSONSessionWait);    
			JSONArray outArray = (JSONArray) result.getJSONArray("aaData");
			JSONArray inArray = null;
			String waitClass;
			String event;
			//long totalWaits;
			//long totalTimeouts;
			double timeWaited;
			//long averageWait;
			//long maxWait;
			int rowcnt = 0;
			double other = 0;
			for(int x = 0; x < outArray.length(); x++){
				inArray = outArray.getJSONArray(x);
				waitClass = inArray.getString(0);
				if(!waitClass.equalsIgnoreCase("Idle")){
					event = inArray.getString(1);
					//totalWaits = inArray.getLong(2);
					//totalTimeouts = inArray.getLong(3);
					timeWaited = inArray.getDouble(4);
					//averageWait = inArray.getLong(5);
					//maxWait = inArray.getLong(6);
					rowcnt++;
					if (rowcnt <= 5) {
						dataset.setValue(event,	timeWaited);
					} else {
						other += timeWaited;
						
					}
				}
			}
		
			if (other > 0) {
				dataset.setValue("Other", other);
			}
		} catch (Exception ex){
			ex.printStackTrace();
		}
		return dataset;
	}

	public static String getJSONDBStat(Connection con, int days){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con.prepareStatement(getString("dbmetric_sql").replaceAll(
					"XXXX", Matcher.quoteReplacement(Integer.toString(days))));
			pStat.setQueryTimeout(600);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getTimestamp(1).toString());  //time
				inArray.put(rset.getLong(2));  //inst
				inArray.put(rset.getLong(3));  //logged on mx
				inArray.put(rset.getLong(4));  //logged on avg
				inArray.put(rset.getLong(5));  //logons mx
				inArray.put(rset.getLong(6));  //logons avg
				inArray.put(rset.getLong(7));  //bufhit mx
				inArray.put(rset.getLong(8));  //bufhit avg
				inArray.put(rset.getLong(9));  //lread mx
				inArray.put(rset.getLong(10)); //lread avg
				inArray.put(rset.getLong(11)); //pread mx
				inArray.put(rset.getLong(12)); //pread avg
				inArray.put(rset.getLong(13)); //blk sec mx
				inArray.put(rset.getLong(14)); //blk sec avg
				inArray.put(rset.getLong(15)); //db tm mx
				inArray.put(rset.getLong(16)); //db tm avg
				inArray.put(rset.getLong(17)); //exec sec mx
				inArray.put(rset.getLong(18)); //exec sec avg
				inArray.put(rset.getLong(19)); //load mx
				inArray.put(rset.getLong(20)); //load avg
				inArray.put(rset.getLong(21)); //commit mx
				inArray.put(rset.getLong(22)); //commit avg
				inArray.put(rset.getLong(23)); //rollbk mx
				inArray.put(rset.getLong(24)); //rollbk avg
				outArray.put(inArray);

			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result.toString();
	}

	
	public static XYDataset getDBStatDataset(String JSONDBStat) {
		DateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<TimeSeries> tsList = new ArrayList<TimeSeries>();
		TimeSeriesCollection ts = new TimeSeriesCollection();
		try{
			JSONObject inJson = new JSONObject(JSONDBStat);    
			JSONArray outArray2 = (JSONArray) inJson.getJSONArray("aaData");
			JSONArray inArray2;
			Calendar cal = Calendar.getInstance();
			boolean found;
			int x, y;
			String inst = "";
			Hour hr;
			// this section converts the hourly average list into timeseries data
			for (x = 0; x < outArray2.length(); x++) {
				found = false;
				inArray2 = outArray2.getJSONArray(x);
				cal.setTime(dfm.parse(inArray2.getString(0)));
				inst = Long.toString(inArray2.getLong(1));
				hr = new Hour(cal.getTime());
				for (y = 0; y < tsList.size(); y += 22) {
					if (tsList.get(y).getDescription().equalsIgnoreCase(inst.concat(" LOGGED ON MAX"))) {
						for(int z = 0; z < 22; z++){
							tsList.get(y + z).addOrUpdate( hr, inArray2.getLong(2 + z));
						}
						found = true;
					}
				}
				if (!found) {
					TimeSeries q;
					String lbl;
					int col = 2;
					lbl = inst.concat(" LOGGED ON MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" LOGGED ON AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" LOGONS ON MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" LOGONS ON AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" CACHE HT MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" CACHE HT AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" LREADS MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" LREADS AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" PREADS MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" PREADS AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" BLOCKS MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" BLOCKS AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" DB TM MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" DB TM AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" EXEC SEC MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" EXEC SEC AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" LOAD MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" LOAD AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" COMMIT MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" COMMIT AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" ROLLBACK MAX");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
					lbl = inst.concat(" ROLLBACK AVG");
					q = new TimeSeries(lbl);
					q.setDescription(lbl);
					q.add(new TimeSeriesDataItem(hr, inArray2.getLong(col++)));
					tsList.add(q);
				}
			}
		} catch (Exception ex){
			ex.printStackTrace();
		}

		for (int y = 0; y < tsList.size(); y++) {
			ts.addSeries(tsList.get(y));
		}
		return ts;
	}

	
	
	
	
	public /* synchronized JOHN */ static JFreeChart getSQLPlnChart(String xyDatasetStr,
			List<String> options) {
		if (xyDatasetStr == null) {
			System.out
					.println("xyDataset was passed as null to getSQLPlnChart.");
			return null;
		}
		if (options == null) {
			options = new ArrayList<String>();
			options.add("exec");
			options.add("rpe");
			options.add("fpe");
			options.add("mpe");
			options.add("cpe");
			options.add("ipe");
			options.add("dpe");
			options.add("bpe");
		}
		
		
		
		
		XYDataset xyDataset = null; 
		if (options.contains("memory")) {
			xyDataset = DbSQL.getMemoryDataset(xyDatasetStr);
		} else if (options.contains("sysevt")) {
			xyDataset = DbSQL.getSysEvtxyDataset(xyDatasetStr);
		} else if (options.contains("syssum")) {
			xyDataset = DbSQL.getSysSumxyDataset(xyDatasetStr);
		} else if (options.contains("redolog")) {
			xyDataset = DbSQL.getLogSwitchxyDataset(xyDatasetStr);
			options.add("showall");
		} else if (options.contains("dbstats")) {
			xyDataset = DbSQL.getDBStatDataset(xyDatasetStr);
		} else if (options.contains("dbsize")) {
			xyDataset = DbSQL.getDBSizeDataset(xyDatasetStr);
			} else{
			xyDataset = DbSQL.getSQLxyDataset(xyDatasetStr);
		}
		
		
		JFreeChart chart = ChartFactory.createXYLineChart(null , null, null,
				xyDataset, PlotOrientation.VERTICAL, true, true, true);
		final XYPlot plot = chart.getXYPlot();
		plot.setDrawingSupplier(	
			new DefaultDrawingSupplier( new Paint[] {
		                new Color(0xFF, 0x55, 0x55),
		                new Color(0x55, 0x55, 0xFF),
		                new Color(0x55, 0xFF, 0x55),
		                //new Color(0xFF, 0xFF, 0x55),
		                new Color(0xFF, 0x55, 0xFF),
		                new Color(0x55, 0xFF, 0xFF),
		                Color.pink,
		                Color.gray,
		                ChartColor.DARK_RED,
		                ChartColor.DARK_BLUE,
		                //ChartColor.DARK_GREEN,
		                //ChartColor.DARK_YELLOW,
		                ChartColor.DARK_MAGENTA,
		                ChartColor.DARK_CYAN,
		                Color.darkGray,
		                ChartColor.LIGHT_RED,
		                ChartColor.LIGHT_BLUE,
		                ChartColor.LIGHT_GREEN,
		                //ChartColor.LIGHT_YELLOW,
		                ChartColor.LIGHT_MAGENTA,
		                ChartColor.LIGHT_CYAN,
		                Color.lightGray,
		                ChartColor.VERY_DARK_RED,
		                ChartColor.VERY_DARK_BLUE,
		                ChartColor.VERY_DARK_GREEN,
		                //ChartColor.VERY_DARK_YELLOW,
		                ChartColor.VERY_DARK_MAGENTA,
		                ChartColor.VERY_DARK_CYAN,
		                ChartColor.VERY_LIGHT_RED,
		                ChartColor.VERY_LIGHT_BLUE,
		                ChartColor.VERY_LIGHT_GREEN,
		                //ChartColor.VERY_LIGHT_YELLOW,
		                ChartColor.VERY_LIGHT_MAGENTA,
		                ChartColor.VERY_LIGHT_CYAN
		            },
		            DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE,
		            DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE,
		            DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE,
		            DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE,
		            DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE
		));
		

		
		//plot.setRenderer(new XYSplineRenderer());
		Color clear = new Color(255,255,255,0);
		Color blue = 	new Color(0x33,0x66,0x99,255);
		Color yellow = new Color(0xFF,0xFF,0xCC,255);

	    chart.setBackgroundPaint( clear );
		//chart.setBackgroundPaint( new Color(0xFF,0xFF,0xCC,0) );
        //plot.setBackgroundPaint( new Color(0xFF,0xFF,0xCC,128) );
	    plot.setBackgroundPaint( yellow );
	    //plot.setBackgroundPaint( clear );  //this will make it clear again
        plot.setBackgroundImageAlpha(0.0f);
        //TextTitle title = new TextTitle("xxx  my big long test of a title to see what happens if it goes long for a while....");
        /*
        TextTitle title = new TextTitle("xxx");
        title.setPaint(new Color(0x33,0x66,0x99,255));
        title.setExpandToFitSpace(true);
        chart.setTitle(title);
        */

		

		final DateAxis domainAxis = new DateAxis();
		plot.setDomainAxis(domainAxis);
		
		plot.setRangeGridlinesVisible(true);
		plot.setDomainGridlinesVisible(true);
		plot.setRangeGridlinePaint(blue);
		plot.setDomainGridlinePaint(blue);
		
		XYLineAndShapeRenderer xylineandshaperenderer = (XYLineAndShapeRenderer) plot
				.getRenderer();
		xylineandshaperenderer.setUseOutlinePaint(false); 
		xylineandshaperenderer.setUseFillPaint(false); 
		//((XYSplineRenderer)xylineandshaperenderer).setPrecision(3);
		for (int z = 0; z < xyDataset.getSeriesCount(); z++) {
			/*
			xylineandshaperenderer.setSeriesLinesVisible(z, false);
			xylineandshaperenderer.setSeriesShapesVisible(z,true);
			if((xyDataset.getItemCount(0) >= 100)){
				xylineandshaperenderer.setSeriesShape(z, new Rectangle(0,0,1,1));	
			}
			*/
			xylineandshaperenderer.setSeriesShapesVisible(z,(xyDataset.getItemCount(0) < 20));
			//xylineandshaperenderer.setSeriesLinesVisible(z, true); 
		}

		if (options.contains("showall")) {

		} else if (options.contains("memory")) {
			for (int lp = 0; lp < xyDataset.getSeriesCount(); lp += 10) {
				if (!options.contains("fixed")) {
					xylineandshaperenderer.setSeriesVisible(lp + 0, false);
				}
				if (!options.contains("log")) {
					xylineandshaperenderer.setSeriesVisible(lp + 1, false);
				}
				if (!options.contains("java")) {
					xylineandshaperenderer.setSeriesVisible(lp + 2, false);
				}
				if (!options.contains("large")) {
					xylineandshaperenderer.setSeriesVisible(lp + 3, false);
				}
				if (!options.contains("streams")) {
					xylineandshaperenderer.setSeriesVisible(lp + 4, false);
				}
				if (!options.contains("buffer")) {
					xylineandshaperenderer.setSeriesVisible(lp + 5, false);
				}
				if (!options.contains("shared")) {
					xylineandshaperenderer.setSeriesVisible(lp + 6, false);
				}
				if (!options.contains("sga")) {
					xylineandshaperenderer.setSeriesVisible(lp + 7, false);
				}
				if (!options.contains("pga")) {
					xylineandshaperenderer.setSeriesVisible(lp + 8, false);
				}
				if (!options.contains("total")) {
					xylineandshaperenderer.setSeriesVisible(lp + 9, false);
				}
		
			}
		} else if (options.contains("dbsize")) {
			for (int lp = 0; lp < xyDataset.getSeriesCount(); lp += 3) {
				if (!options.contains("size")) {
					xylineandshaperenderer.setSeriesVisible(lp + 0, false);
				}
				if (!options.contains("used")) {
					xylineandshaperenderer.setSeriesVisible(lp + 1, false);
				}
				if (!options.contains("max")) {
					xylineandshaperenderer.setSeriesVisible(lp + 2, false);
				}
				
			}
			

		} else if (options.contains("sysevt")) {
			for (int lp = 0; lp < xyDataset.getSeriesCount(); lp += 3) {
				if (!options.contains("qty")) {
					xylineandshaperenderer.setSeriesVisible(lp + 0, false);
				}
				if (!options.contains("avgms")) {
					xylineandshaperenderer.setSeriesVisible(lp + 1, false);
				}
				if (!options.contains("totms")) {
					xylineandshaperenderer.setSeriesVisible(lp + 2, false);
				}
				
			}

		}
		else if (options.contains("syssum")) {
			for (int lp = 0; lp < xyDataset.getSeriesCount(); lp += 3) {
				if (!options.contains("min")) {
					xylineandshaperenderer.setSeriesVisible(lp + 0, false);
				}
				if (!options.contains("avg")) {
					xylineandshaperenderer.setSeriesVisible(lp + 1, false);
				}
				if (!options.contains("max")) {
					xylineandshaperenderer.setSeriesVisible(lp + 2, false);
				}
				
			}

		}
		else if (options.contains("dbstats")) {
			for (int lp = 0; lp < xyDataset.getSeriesCount(); lp += 22) {
				if (!options.contains("lgcnt")) {
					xylineandshaperenderer.setSeriesVisible(lp + 0, false);
					xylineandshaperenderer.setSeriesVisible(lp + 1, false);
				}
				if (!options.contains("lgsec")) {
					xylineandshaperenderer.setSeriesVisible(lp + 2, false);
					xylineandshaperenderer.setSeriesVisible(lp + 3, false);
				}
				if (!options.contains("cache")) {
					xylineandshaperenderer.setSeriesVisible(lp + 4, false);
					xylineandshaperenderer.setSeriesVisible(lp + 5, false);
				}
				if (!options.contains("lread")) {
					xylineandshaperenderer.setSeriesVisible(lp + 6, false);
					xylineandshaperenderer.setSeriesVisible(lp + 7, false);
				}
				if (!options.contains("pread")) {
					xylineandshaperenderer.setSeriesVisible(lp + 8, false);
					xylineandshaperenderer.setSeriesVisible(lp + 9, false);
				}
				if (!options.contains("blocks")) {
					xylineandshaperenderer.setSeriesVisible(lp + 10, false);
					xylineandshaperenderer.setSeriesVisible(lp + 11, false);
				}
				if (!options.contains("dbtime")) {
					xylineandshaperenderer.setSeriesVisible(lp + 12, false);
					xylineandshaperenderer.setSeriesVisible(lp + 13, false);
				}
				if (!options.contains("exec")) {
					xylineandshaperenderer.setSeriesVisible(lp + 14, false);
					xylineandshaperenderer.setSeriesVisible(lp + 15, false);
				}
				if (!options.contains("load")) {
					xylineandshaperenderer.setSeriesVisible(lp + 16, false);
					xylineandshaperenderer.setSeriesVisible(lp + 17, false);
				}
				if (!options.contains("commit")) {
					xylineandshaperenderer.setSeriesVisible(lp + 18, false);
					xylineandshaperenderer.setSeriesVisible(lp + 19, false);
				}
				if (!options.contains("rollback")) {
					xylineandshaperenderer.setSeriesVisible(lp + 20, false);
					xylineandshaperenderer.setSeriesVisible(lp + 21, false);
				}
			}
		} else {
			for (int list_ptr = 0; list_ptr < xyDataset.getSeriesCount() / 8; list_ptr++) { 
				if (!options.contains("exec")) {
					xylineandshaperenderer.setSeriesVisible((list_ptr * 8) + 0,
							false);
				}
				if (!options.contains("rpe")) {
					xylineandshaperenderer.setSeriesVisible((list_ptr * 8) + 1,
							false);
				}
				if (!options.contains("fpe")) {
					xylineandshaperenderer.setSeriesVisible((list_ptr * 8) + 2,
							false);
				}
				if (!options.contains("mpe")) {
					xylineandshaperenderer.setSeriesVisible((list_ptr * 8) + 3,
							false);
				}
				if (!options.contains("cpe")) {
					xylineandshaperenderer.setSeriesVisible((list_ptr * 8) + 4,
							false);
				}
				if (!options.contains("ipe")) {
					xylineandshaperenderer.setSeriesVisible((list_ptr * 8) + 5,
							false);
				}
				if (!options.contains("dpe")) {
					xylineandshaperenderer.setSeriesVisible((list_ptr * 8) + 6,
							false);
				}
				if (!options.contains("bpe")) {
					xylineandshaperenderer.setSeriesVisible((list_ptr * 8) + 7,
							false);
				}
			}
		}
		return chart;
	}

	public static List<String> getMatchingString(String key) {

		ArrayList<String> value = new ArrayList<String>();
		for (Enumeration<String> e = RESOURCE_BUNDLE.getKeys(); e
				.hasMoreElements();) {
			String ky = (String) e.nextElement();
			if (ky.startsWith(key)) {
				value.add(ky);
				// RESOURCE_BUNDLE.getObject(ky);
			}
		}
		Collections.sort(value);
		return value;
	}

	public static String getString(String key) {
		try {
			return RESOURCE_BUNDLE.getString(key);
		} catch (MissingResourceException e) {
			return '!' + key + '!';
		}
	}

	public static String getJSONBlockingLocks(Connection con1) {
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		try {
			PreparedStatement pStat = con1
			.prepareStatement(getString("getLockLst")); 
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				for(int x = 1; x <= 13; x++ ){
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONLocks(Connection con1, String instid, String sid ) {
		//send 0 for all sessions
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		int insid = 0;
		int sd = 0;
		try{
			insid = Integer.parseInt(instid);
		} catch (Exception e){
		}
		try{
			sd = Integer.parseInt(sid);
		} catch (Exception e){
		}
		try {
			PreparedStatement pStat = con1
			.prepareStatement(getString("getAllLockInfo")); 
			pStat.setLong(1, insid);
			pStat.setLong(2, sd);
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				for(int x = 1; x <= 15; x++ ){
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONPGAAlloc(Connection con1) {
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		try {
			PreparedStatement pStat = con1
			.prepareStatement(getString("getPGAAllocLst")); 
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				for(int x = 1; x <= 9; x++ ){
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONSessions(Connection con1) {
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		try {
			PreparedStatement pStat = con1
			.prepareStatement(getString("getSessionList")); 
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				for(int x = 1; x <= 28; x++ ){
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONSessionsShort(Connection con1) {
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		try {
			PreparedStatement pStat = con1
			.prepareStatement(getString("getSesShortList")); 
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(spaceStr(rset.getString(1)));
				inArray.put(spaceStr(rset.getString(2)));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	
	public static String getJSONSessionDetail(Connection con1, String instance, String sid ) {
		int inst = 0;
		int sd = 0;
		try{
			inst = Integer.parseInt(instance);
			sd = Integer.parseInt(sid);
		} catch (Exception e){
			
		}
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		try {
			PreparedStatement pStat = con1
			.prepareStatement(getString("getSessionInfo")); 
			pStat.setInt(1, inst);
			pStat.setInt(2, sd);
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			if (rset.next()) {
				int x = 1;
				inArray =  new JSONArray();
				inArray.put("Instance");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("User");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("SID");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Serial");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Service");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("OS PID");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Machine");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("OS User");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Client ID");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Client PID");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Program");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Status");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Command");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Loggon");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("SQL ID");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Prev SQL ID");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Blk Instance");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Blk Session");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Wait Time (sec)");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Scnds in Wait");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Scds Last Call");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Schema Name");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Wait Class");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Wait Event");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("PGA Used");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("PGA Alloc");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("PGA Mac");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Trns Start");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Undo Records");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Undo Blocks");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	

	public static String getJSONSessionLongOps(Connection con1,
			String instance, String sid) {
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		try {
			PreparedStatement pStat = con1
					.prepareStatement(getString("getSessLongOps"));
			pStat.setInt(1, Integer.valueOf(instance).intValue());
			pStat.setInt(2, Integer.valueOf(sid).intValue());
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				for(int x = 1; x <= 12; x++ ){
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static String getJSONLongOps(Connection con1) {
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		try {
			PreparedStatement pStat = con1
			.prepareStatement(getString("getLongOps")); 
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				for(int x = 1; x <= 15; x++ ){
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static String getJSONPGAStat(Connection con1) {
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		try {
			PreparedStatement pStat = con1
			.prepareStatement(getString("getPGAStatLst")); 
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			long val;
			String unit;
			String valUnit;
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(spaceStr(rset.getString(1)));
				inArray.put(spaceStr(rset.getString(2)));
				val = rset.getLong(3);
				unit = rset.getString(4);
				if (unit == null) {
					valUnit = Long.toString(val);
				} else if (unit.equalsIgnoreCase("percent")) {
					valUnit = Long.toString(val)
							.concat("%");
				} else if (unit.equalsIgnoreCase("bytes")) {
					valUnit = DbSQL.formatBytes(val);
				} else {
					valUnit = Long
							.toString(val)
							.concat(" ")
							.concat(unit);
				}
				inArray.put(valUnit);
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONSQLPlanChange(Connection con1) {
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		try {
			PreparedStatement pStat = con1
			.prepareStatement(getString("changePlanSQL")); 
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				for(int x = 1; x <= 7; x++ ){
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}


	public static String getJSONDBParam(Connection con1) {
		JSONObject result = new JSONObject();    
		JSONArray outArray = new JSONArray();
		JSONArray inArray = null;
		try {
			PreparedStatement pStat0 = con1
			.prepareStatement(getString("DBVersion10"));
			pStat0.setQueryTimeout(120);
			ResultSet rset0 = pStat0.executeQuery();
			rset0.setFetchSize(100);
			boolean is10g = false;
			if (rset0.next()) {
				is10g = (rset0.getInt(1) == 1);
			}

			PreparedStatement pStat = con1
			.prepareStatement(getString((is10g) ? "listParameters10"
					: "listParameters"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				for(int x = 1; x <= 13; x++ ){
					inArray.put(spaceStr(rset.getString(x)));
				}
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	
	public static String getJSONProfile(Connection con1) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat0 = con1
					.prepareStatement(getString("DBVersion10"));
			pStat0.setQueryTimeout(120);
			ResultSet rset0 = pStat0.executeQuery();
			rset0.setFetchSize(100);
			boolean is10g = false;
			if (rset0.next()) {
				is10g = (rset0.getInt(1) == 1);
			}
			PreparedStatement pStat1 = con1
					.prepareStatement(getString("ProfileList"));
			pStat1.setQueryTimeout(120);
			ResultSet rset1 = pStat1.executeQuery();
			rset1.setFetchSize(100);
			while (rset1.next()) {
				String profName = rset1.getString(1);
				String profDt = rset1.getString(2);
				//ArrayList<String> plan = new ArrayList<String>();
				String plan = new String();
				PreparedStatement pStat2 = null;
				if (is10g) {
					pStat2 = con1.prepareStatement(getString("ProfileDDL10g")
							.replaceAll("XXXX", Matcher.quoteReplacement(profName)));
				} else {
					pStat2 = con1.prepareStatement(getString("ProfileDDL")
							.replaceAll("XXXX", Matcher.quoteReplacement(profName)));
				}
				pStat2.setQueryTimeout(120);
				ResultSet rset2 = pStat2.executeQuery();
				rset2.setFetchSize(100);
				while (rset2.next()) {
					//plan.add(rset2.getString(1));
					plan = plan.concat(rset2.getString(1)).concat("\n");
				}
				rset2.close();
				pStat2.close();
				inArray =  new JSONArray();
				inArray.put(profName);
				inArray.put(profDt);
				inArray.put(plan);
				outArray.put(inArray);
			}
			rset0.close();
			pStat0.close();
			rset1.close();
			pStat1.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static String getJSONSessionEvent(Connection con1,
			String instance, String sid) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;

		try {
			PreparedStatement pStat = con1
					.prepareStatement(getString("getSessEvent"));
			pStat.setInt(1, Integer.valueOf(instance).intValue());
			pStat.setInt(2, Integer.valueOf(sid).intValue());
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray = new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getString(2));
				inArray.put(rset.getString(3));
				inArray.put(rset.getString(4));
				inArray.put(rset.getString(5));
				inArray.put(rset.getString(6));
				inArray.put(rset.getString(7));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result.toString();
	}

	
	

	public static String xYDatasetToJSON(XYDataset dat){
		if (dat == null) {
			return null;
		}
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		int x, y;
		for(x = 0; x < dat.getSeriesCount(); x++){
			for(y = 0; y < dat.getItemCount(x); y++){
				inArray =  new JSONArray();
				inArray.put(dat.getSeriesKey(x).toString());
				inArray.put(dat.getX(x, y));
				inArray.put(dat.getY(x, y));
				outArray.put(inArray);
			}
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONRMANStatus(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("rmanstatus"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(spaceStr(rset.getString(1)));
				inArray.put(spaceStr(rset.getString(2)));
				inArray.put(spaceStr(rset.getString(3)));
				inArray.put(spaceStr(rset.getString(4)));
				inArray.put(spaceStr(rset.getString(5)));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONTopDBWait(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("topdbwait"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(spaceStr(rset.getString(1)));
				inArray.put(spaceStr(rset.getString(2)));
				inArray.put(spaceStr(rset.getString(3)));
				inArray.put(spaceStr(rset.getString(4)));
				inArray.put(spaceStr(rset.getString(5)));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	
	
	public static String getJSONDatabase(Connection con1) {
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con1.prepareStatement(getString(
					"getDatabase"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			if (rset.next()) {
				int x = 1;
				inArray =  new JSONArray();
				inArray.put("DBID");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Name");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("DB Unique Name");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Platform");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Created");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Open Mode");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Log Mode");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Flashback On");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Force Logging");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Supp Log ALL");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Supp Log FK");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Supp Log PK");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Supp Log UI");
				inArray.put(spaceStr(rset.getString(x++)));
				inArray.put("Supp Log Min");
				inArray.put(spaceStr(rset.getString(x++)));
				outArray.put(inArray);
				inArray =  new JSONArray();
				inArray.put("Current SCN");
				inArray.put(rset.getLong(x++));
				inArray.put("Archive Chg#");
				inArray.put(rset.getLong(x++));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONInstance(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("getInstance"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getLong(1));
				inArray.put(spaceStr(rset.getString(2)));
				inArray.put(spaceStr(rset.getString(3)));
				inArray.put(spaceStr(rset.getString(4)));
				inArray.put(spaceStr(rset.getString(5)));
				inArray.put(spaceStr(rset.getString(6)));
				inArray.put(spaceStr(rset.getString(7)));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static String getJSONDBSize(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("getDbSize"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getLong(2));
				inArray.put(rset.getLong(3));
				inArray.put(rset.getLong(4));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONDBCurSize(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("getDbCurSize"));
			pStat.setQueryTimeout(300);  //takes a while to run through v#datafile on larger databases.
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getLong(2));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONTablespaceInfo(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("getTablespaceInfo"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getString(1));
				inArray.put(rset.getString(2));
				inArray.put(rset.getLong(3));
				inArray.put(rset.getLong(4));
				inArray.put(rset.getLong(5));
				inArray.put(rset.getLong(6));
				inArray.put(rset.getLong(7));
				inArray.put(rset.getLong(8));
				inArray.put(rset.getString(9));
				inArray.put(rset.getString(10));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONASMSize(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("getASMSize"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(rset.getLong(1));
				inArray.put(rset.getString(2));
				inArray.put(rset.getLong(3));
				inArray.put(rset.getLong(4));
				inArray.put(rset.getLong(5));
				inArray.put(rset.getLong(6));
				inArray.put(rset.getLong(7));
				inArray.put(rset.getLong(8));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONLastSegmentReport(Connection con){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		try {
			PreparedStatement pStat = con
					.prepareStatement(getString("getLastSegmentReport"));
			pStat.setQueryTimeout(120);
			ResultSet rset = pStat.executeQuery();
			rset.setFetchSize(100);
			while (rset.next()) {
				inArray =  new JSONArray();
				inArray.put(spaceStr(rset.getString(1)));
				inArray.put(spaceStr(rset.getString(2)));
				inArray.put(spaceStr(rset.getString(3)));
				inArray.put(spaceStr(rset.getString(4)));
				inArray.put(spaceStr(rset.getString(5)));
				inArray.put(rset.getLong(6));
				inArray.put(rset.getLong(7));
				inArray.put(rset.getLong(8));
				inArray.put(rset.getLong(9));
				inArray.put(rset.getLong(10));
				inArray.put(spaceStr(rset.getString(11)));
				inArray.put(spaceStr(rset.getString(12)));
				inArray.put(spaceStr(rset.getString(13)));
				inArray.put(spaceStr(rset.getString(14)));
				outArray.put(inArray);
			}
			rset.close();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String JSONString(String input){
		JSONObject result = new JSONObject();     
		JSONArray outArray = new JSONArray();
		JSONArray inArray =  new JSONArray();
		inArray.put(spaceStr(input));
		outArray.put(inArray);
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	
	}
	
	public static boolean mailIt(String subject, String body, String from, String to){
		System.setProperty("mail.smtp.host", "mailhost.jpmchase.net");
		Session session = Session.getDefaultInstance(System.getProperties());
		MimeMessage message = new MimeMessage(session);

		try {
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			message.setFrom(new InternetAddress(from));
			message.setSubject(subject);
			//message.setText(body);
			message.setContent(body,"text/html");
			Transport.send(message);
			
		} catch (AddressException e) {
			e.printStackTrace();
			return false;
		} catch (MessagingException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static String formatBytes(long byteCount) {
		if (byteCount < 8192l) {
			return Long.toString(byteCount).concat(" B");
		}
		if (byteCount < (8192l * 1024l)) {
			return Long.toString(byteCount / 1024l).concat(" K");
		}
		if (byteCount < (8192l * 1024l * 1024l)) {
			return Long.toString(byteCount / (1024l * 1024l)).concat(" M");
		}
		return Long.toString(byteCount / (1024l * 1024l * 1024l)).concat(" G");
	}
	public static String spaceStr(String instr) {
		return (instr == null)?emptyString:instr;
	}

}


