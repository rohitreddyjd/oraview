package sqlGraph;

import oracle.jdbc.OracleDriver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

import org.apache.tomcat.dbcp.dbcp.PoolingDriver;

public final class Connect {

	private Connect() {
		throw new Error();
	}

	public static/* synchronized */Connection getConnection(String conName)
			throws Exception {
		return ConnectGlobal.getConnection(conName);
	}

	public static/* synchronized */Connection getNonPooledConnection(
			String conName) throws SQLException {
		Connection conn = null;
		//try {
			DriverManager.registerDriver(new OracleDriver());
			try {
				new PoolingDriver().closePool(conName);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			List<String> inf = ConfigDbSQL.getDbInfo(conName);
			if(inf == null || inf.size() < 4 || inf.get(3).equalsIgnoreCase("Expired")){
				return null;
			}
			Properties properties = new java.util.Properties();
			properties.put("user", inf.get(1));
			properties.put("password", inf.get(2));
			properties.put("oracle.jdbc.J2EE13Compliant", "true");
			conn = DriverManager.getConnection(inf.get(0), properties);
			conn.setAutoCommit(true);
			conn.setReadOnly(true);
			return conn;
		//} catch (Exception e) {
			//e.printStackTrace();
			//throw (Exception) e;
		//}
	}

	public static/* synchronized */Connection getNonPooledConnection(
			String conString, String usr, String pass) throws SQLException {
		Connection conn = null;
		//try {
			DriverManager.registerDriver(new OracleDriver());
			Properties properties = new java.util.Properties();
			properties.put("user", usr);
			properties.put("password", pass);
			properties.put("oracle.jdbc.J2EE13Compliant", "true");
			conn = DriverManager.getConnection(conString, properties);
			conn.setAutoCommit(true);
			conn.setReadOnly(true);
			return conn;
		//} catch (Exception e) {
			//e.printStackTrace();
			//throw (Exception) e;
		//}
	}

}
