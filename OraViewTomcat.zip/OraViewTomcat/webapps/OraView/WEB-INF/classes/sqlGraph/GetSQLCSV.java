package sqlGraph;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetSQLCSV extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public GetSQLCSV() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		if (!sqlGraph.Usr.validate(
				(request.getHeader("STANDARDID") == null) ? request
						.getRemoteUser() : request.getHeader("STANDARDID"),
				"DBA")) {
			response.sendRedirect("NoAccess.html");
		}
		long tm = System.currentTimeMillis();
		String sqlID = request.getParameter("sqlid");
		String sqlText = request.getParameter("sqltext");
		String conNm = request.getParameter("connm");
		int hourly = 0;
		try{
			hourly = Integer.parseInt(request.getParameter("hours"));
		} catch (Exception e){
			hourly = 0;
		}
		Connection con = null;
		String errStr = null;
		if ((sqlID == null && sqlText == null) || conNm == null) {
			errStr = "You must pass sqlid or sqltext and connm parameters";
		}
		if (errStr == null) {
			try {
				con = Connect.getConnection(conNm);
			} catch (Exception e1) {
				errStr = e1.getLocalizedMessage();
			}
		}
		if (errStr != null) {
			PrintWriter out = response.getWriter();
			out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 "
					+ "Transitional//EN\">\n" + "<HTML>\n" + "<HEAD><TITLE>"
					+ "Error" + "</TITLE></HEAD>\n" + "<BODY>\n" + "<H1>"
					+ errStr + "</H1>\n" + "</BODY></HTML>");
			return;
		}
		List<String> csvOut = null;
		if (sqlID != null) {
			csvOut = DbSQL.getSQLCsvFromJSON(DbSQL
					.getJSONSQLBySQLID(con, sqlID, hourly));
		} else {
			csvOut = DbSQL.getSQLCsvFromJSON(DbSQL.getJSONSQLByText(con,
					sqlText));
		}
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		long tm2 = System.currentTimeMillis();
		System.out.println("SQL: Time".concat(new Long(tm2 - tm).toString()));
		response.setHeader("Expires", "0");
		response.setHeader("Cache-Control",
				"must-revalidate, post-check=0, pre-check=0");
		response.setHeader("Pragma", "public");
		response.setHeader(
				"Content-Disposition",
				"attachment; filename=".concat(
						(sqlID == null) ? "sql_".concat((new Long(tm2))
								.toString()) : sqlID).concat(".csv"));
		response.setContentType("application/octet-stream");
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		for (int row = 0; row < csvOut.size(); row++) {
			baos.write(csvOut.get(row).getBytes());
		}

		response.setContentLength(baos.size());
		OutputStream os = response.getOutputStream();
		baos.writeTo(os);
		os.flush();
		os.close();
		System.out.println("CSV Display Time Excluding SQL:".concat(new Long(
				System.currentTimeMillis() - tm2).toString()));
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
