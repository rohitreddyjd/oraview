package sqlGraph;

public abstract class Usr {
	private Usr(){
		throw new Error();
	}

	public static boolean validate(String user, String group) {
		//if no security enabled, allow everyone.
		if(user == null){ 
			return true;
		}
		if(user.length() == 0) {
			return true;
		}
		return ConfigDbSQL.validateUserInGroup(user, group);
	}
}
