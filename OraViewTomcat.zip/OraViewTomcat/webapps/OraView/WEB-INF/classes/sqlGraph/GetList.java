package sqlGraph;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String login = (request.getHeader("STANDARDID") == null) ? 
	    		request.getRemoteUser(): 
			    	request.getHeader("STANDARDID");
		String conNm = request.getParameter("connm");
		String tp = request.getParameter("tp");
		String addm_name = request.getParameter("addm_name");
		if (addm_name == null) {
			addm_name = "";
		}
		String tune_name = request.getParameter("tune_name");
		if (tune_name == null) {
			tune_name = "";
		}
		String dt = request.getParameter("dt");
		if (dt == null) {
			dt = "";
		}

		int days = 30;
		try {
			days = Integer.parseInt(request.getParameter("days"));
		} catch (Exception e) {
			days = 30;
		}
		if (days < 1) {
			days = 30;
		}

		String sqltp = request.getParameter("sqltp");
		String sqlid = request.getParameter("sqlid");
		String sqltext = request.getParameter("sqltext");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String group = request.getParameter("group");
		String instid = request.getParameter("instid");
		String sid = request.getParameter("sid");
		String dSetName = request.getParameter("dSet");
		String owner = request.getParameter("owner");
		String table = request.getParameter("table");
		String user = request.getParameter("user");
		String graph[] = request.getParameterValues("graph");
		String email = request.getParameter("email");
		int hourly = 0;
		try{
			hourly = Integer.parseInt(request.getParameter("hours"));
		} catch (Exception e){
			hourly = 0;
		}
		int seconds = 3600;
		try{
			seconds = Integer.parseInt(request.getParameter("seconds"));
		} catch (Exception e){
			seconds = 3600;
		}
		if(seconds < 60){ 
			seconds = 60;
		}
		
		String outStr = "";
		if (conNm == null || conNm.length() < 1) {
			outStr = "Error please pass connm parameter to GetList";
			System.err.print(outStr);
		}
		Options opt = null;
		if (tp == null || tp.length() < 1) {
			outStr = "Error please pass tp parameter to GetList";
			System.err.print(outStr);
		} else {
			try {
				opt = Options.valueOf(tp.toUpperCase());
			} catch (Exception e) {
				outStr = "Error tp parameter not in enumeration for GetList";
				System.err.print(outStr);
			}
		}
		if (outStr.length() < 1) {
			Connection con = null;
			if (!(opt == Options.CONGROUPSFORCONNECTION)) {
				try {
					con = Connect.getConnection(conNm);
				} catch (SQLException e1) {
					if (opt == Options.CONNECTIONTEST) {
						outStr = DbSQL.testConnection(con);
					} else {
						e1.printStackTrace();
						outStr = "Error";
					}
				} catch (Exception e2) {
					if (opt == Options.CONNECTIONTEST) {
						outStr = DbSQL.testConnection(con);
					} else {
						e2.printStackTrace();
						outStr = "Error";
					}
				}
			}

			if (outStr.length() < 1) {
				switch (opt) {
				case SNAP:
					outStr = DbSQL.getJSONSnap(con);
					break;
				case ADDMRPT:
					if(email == null || email.length() < 7){
					outStr = DbSQL.getJSONADDM(addm_name, con);
					} else {
					new ADDMThread(conNm, addm_name, login, email);
					outStr = DbSQL.JSONString("Sending ADDM Report to " + email);
					}
					break;
				case RUNTUNE:
					System.out.println("Got to Runtune.");
					List<String> dbinfo = ConfigDbSQL.getDbInfo(conNm);
					if(dbinfo == null || dbinfo.isEmpty()){
						outStr = DbSQL.JSONString("Running Tuning Advisor.");
					}
					else {
						try {
							Connection con2 = Connect.getNonPooledConnection(dbinfo.get(0), username, password);
							new TuneThread(con2, sqlid, seconds, username, password);
							System.out.println("Ran Thread.");
							outStr = DbSQL.JSONString("Running Tuning Advisor.");
						} catch (SQLException e) {
							outStr = DbSQL.JSONString("Failed to Run Advisor:" + e.getMessage());
							e.printStackTrace();
						}
					}
					break;
				case TUNINGRPT:	
					outStr = DbSQL.getJSONTune(owner, tune_name, con);
					break;
				case TABLEINFO:
					outStr = DbSQL.getJSONTableInfo(con, owner, table);
					break;
				case TABLECOLUMNS:
					outStr = DbSQL.getJSONTableColumnInfo(con, owner, table);
					break;
				case TABLEINDEXINFO:
					outStr = DbSQL.getJSONTableIndexInfo(con, owner, table);
					break;
				case SYSEVT:
					outStr = DbSQL.getSysEvtList(con);
					break;
				case SYSSUM:
					outStr = DbSQL.getSysSumList(con);
					break;
				case SESSIONS:
					outStr = DbSQL.getJSONSessions(con);
					break;
				case SESSIONSSHORT:
					outStr = DbSQL.getJSONSessionsShort(con);
					break;
				case SESSIONSINFO:
					outStr = DbSQL.getJSONSessionDetail(con, instid, sid);
					break;
				case AWRDATES:
					outStr = DbSQL.getJSONAWRDtList(con);
					break;
				case AWR:
					outStr = DbSQL.getJSONAWRList(con, dt);
					break;
				case ADDM:
					outStr = DbSQL.getJSONADDMList(con, dt);
					break;
				case TUNING:
					outStr = DbSQL.getJSONTuneList(con);
					break;
				case TOPSQL:
					outStr = DbSQL.getJSONSqlId(con, sqltp);
					break;
				case SQLTEXT:
					outStr = DbSQL.getJSONSqlText(con, sqlid);
					break;
				case REDOSTBYLOG:
					outStr = DbSQL.getJSONRedoStandbyLogs(con);
					break;
				case BLOCKLOCKS:
					outStr = DbSQL.getJSONBlockingLocks(con);
					break;
				case ALLLOCKS:
					outStr = DbSQL.getJSONLocks(con, instid, sid);
					break;
				case LONGOPS:
					outStr = DbSQL.getJSONLongOps(con);
					break;
				case SESSIONLONGOPS:
					outStr = DbSQL.getJSONSessionLongOps(con, instid, sid);
					break;
				case PROFILE:
					outStr = DbSQL.getJSONProfile(con);
					break;
				case DBPARAM:
					outStr = DbSQL.getJSONDBParam(con);
					break;
				case PGASTAT:
					outStr = DbSQL.getJSONPGAStat(con);
					break;
				case PGAALLOC:
					outStr = DbSQL.getJSONPGAAlloc(con);
					break;
				case DBSTAT:
					outStr = DbSQL.getJSONDBStat(con, days);
					break;
				case PLANCHANGE:
					outStr = DbSQL.getJSONSQLPlanChange(con);
					break;
				case SQLBNDVAL:
					outStr = DbSQL.getJSONSqlIdBindValues(con, sqlid);
					break;
				case SQLBNDTP:
					outStr = DbSQL.getJSONSqlIdBindTypes(con, sqlid);
					break;
				case SQLPLAN:
					outStr = DbSQL.getJSONSqlPlan(con, sqlid);
					break;
				case SQLCHARTBYTEXT:
					outStr = DbSQL.getJSONSQLByText(con, sqltext);
					break;
				case SQLCHART:
					outStr = DbSQL.getJSONSQLBySQLID(con, sqlid, hourly);
					break;
				case SESSWAITCHART:
					outStr = DbSQL.getJSONSessionEvent(con, instid, sid);
					break;
				case MEMORYCHART:
					outStr = DbSQL.getJSONMemory(con, days);
					break;
				case SYSEVTCHART:
					outStr = DbSQL.getJSONSysEvt(con, graph, days);
					break;
				case SYSSUMCHART:
					outStr = DbSQL.getJSONSysSum(con, graph, days);
					break;
				case LOGSWITCHCHART:
					outStr = DbSQL.getJSONLogSwitch(con, days);
					break;
				case SQLOBJ:
					outStr = DbSQL.getJSONSqlObjects(con, sqlid);
					break;
				case CONNECTIONTEST:
					outStr = DbSQL.testConnection(con);
					break;
				case CONNECTIONLISTGROUP:
					outStr = DbSQL.connectionListGroup(con);
					break;
				case CONNECTIONLONGLIST:
					outStr = DbSQL.connectionJSONLongList(con);
					break;
				case TOPDBWAIT:
					outStr = DbSQL.getJSONTopDBWait(con);
					break;
				case RMANSTATUS:
					outStr = DbSQL.getJSONRMANStatus(con);
					break;
				case CONGROUPSFORCONNECTION:
					outStr = ConfigDbSQL.getJSONConGroupsStatusForDb(conNm);
					break;
				case CONNAMES:
					outStr = ConfigDbSQL.getJSONDbs();
					break;
				case CONGROUPS:
					outStr = ConfigDbSQL.getJSONConGroups();
					break;
				case CONCONNECTIONSFORGROUP:
					outStr = ConfigDbSQL.getJSONDbsStatusForConGroup(group);
					break;
				case CONCONNECTIONSFORGROUPWITHPAD:
					outStr = ConfigDbSQL.getJSONDbsForConGroupPad(group);
					break;
				case USERLIST:
					outStr = ConfigDbSQL.getJSONUserList();
					break;
				case USERROLE:
					outStr = ConfigDbSQL.getJSONRoleStatusForUser(user);
					break;
				case DATABASE:
					outStr = DbSQL.getJSONDatabase(con);
					break;
				case INSTANCE:
					outStr = DbSQL.getJSONInstance(con);
					break;
				case DBSIZE:
					outStr = DbSQL.getJSONDBSize(con);
					break;
				case DBCURSIZE:
					outStr = DbSQL.getJSONDBCurSize(con);
					break;
				case TABLESPACEINFO:
					outStr = DbSQL.getJSONTablespaceInfo(con);
					break;
				case ASMSIZE:
					outStr = DbSQL.getJSONASMSize(con);
					break;
				case LASTSEGRPT:
					outStr = DbSQL.getJSONLastSegmentReport(con);
					break;
				}
				if (dSetName != null && (!dSetName.isEmpty())) {
					request.getSession().setAttribute(dSetName, outStr); 
				}
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		response.setContentType("application/json");
		response.setHeader("Cache-Control", "no-store,no-cache,must-revalidate");
		response.setContentLength(outStr.length());
		PrintWriter prtWriter = response.getWriter();
		prtWriter.print(outStr);
		prtWriter.flush();
		prtWriter.close();
	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private enum Options {
		SNAP, ADDMRPT, TUNINGRPT, TABLEINFO, TABLECOLUMNS, TABLEINDEXINFO, SYSEVT, SYSSUM, 
		SESSIONS, SESSIONSSHORT, SESSIONSINFO, AWRDATES, AWR, ADDM, TUNING, TOPSQL, SQLTEXT, 
		REDOSTBYLOG, BLOCKLOCKS, ALLLOCKS, LONGOPS, SESSIONLONGOPS, PROFILE, DBPARAM, 
		PGASTAT, PGAALLOC, DBSTAT, PLANCHANGE, SQLBNDVAL, SQLBNDTP, SQLPLAN, SQLCHART, 
		SQLCHARTBYTEXT, SESSWAITCHART, MEMORYCHART, SQLOBJ, CONNECTIONTEST, 
		CONNECTIONLISTGROUP, CONNECTIONLONGLIST, TOPDBWAIT, RMANSTATUS, 
		CONGROUPSFORCONNECTION, CONNAMES, CONGROUPS, CONCONNECTIONSFORGROUP, 
		CONCONNECTIONSFORGROUPWITHPAD, USERLIST, USERROLE, SYSEVTCHART, SYSSUMCHART, 
		LOGSWITCHCHART, DATABASE, INSTANCE, DBSIZE, DBCURSIZE, TABLESPACEINFO, ASMSIZE,
		LASTSEGRPT, RUNTUNE
	}
}


class TuneThread extends Thread {
	private Connection con;
	private int seconds;
	private String sqlid;
	private String username;
	private String password;

	TuneThread(Connection con, String sqlid, int seconds, String username, String password) {
		super();
		this.con = con;
		this.sqlid = sqlid;
		this.seconds = seconds;
		this.username = username;
		this.password = password;
		start();
	}
	public void run() {
		//Display info about this particular thread
		try {
			DbSQL.runTune(con, sqlid, seconds, username, password);
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}


class ADDMThread extends Thread {
	private String conNm;
	private String addm_name;
	private String login;
	private String email;

	ADDMThread(String conNm, String addm_name, String login, String email) {
		super();
		this.conNm = conNm;
		this.addm_name = addm_name;
		this.login = login;
		this.email = email;
		start();
	}
	public void run() {
		//Display info about this particular thread
		try {
			DbSQL.mailIt("ADDM Report for " + 
					conNm, DbSQL.getJSONADDM(addm_name, Connect.getConnection(conNm)), 
					login, email);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
