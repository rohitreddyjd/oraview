package sqlGraph;

public class ConnectExcept extends Exception {
	private static final long serialVersionUID = 1L;

	public ConnectExcept(String message) {
		super(message);
	}

}
