package sqlGraph;

import javax.crypto.*;
import javax.crypto.spec.*;
import org.apache.commons.codec.binary.*;

public class Encrypt {
	private Encrypt(){
		throw new Error();
	}
	
	private static Cipher encryptCipher;
	private static Cipher decryptCipher;
	private static Base64 encoder = new Base64();
	private static Base64 decoder = new Base64();
	private static final char[] pass = "This IS a TxT StrING to ConvERT AGAinst!"
			.toCharArray();
	private static final byte[] salt = { (byte) 0xa3, (byte) 0x21, (byte) 0x24,
			(byte) 0x2c, (byte) 0xf2, (byte) 0xd2, (byte) 0x3e, (byte) 0x19 };
	private static boolean setup = false;

	private static synchronized boolean setEncrypt() {
		try {
			PBEParameterSpec ps = new javax.crypto.spec.PBEParameterSpec(salt,
					20);
			SecretKey k = SecretKeyFactory.getInstance("PBEWithMD5AndDES")
					.generateSecret(new javax.crypto.spec.PBEKeySpec(pass));
			encryptCipher = Cipher
					.getInstance("PBEWithMD5AndDES/CBC/PKCS5Padding");
			encryptCipher.init(Cipher.ENCRYPT_MODE, k, ps);
			decryptCipher = Cipher
					.getInstance("PBEWithMD5AndDES/CBC/PKCS5Padding");
			decryptCipher.init(Cipher.DECRYPT_MODE, k, ps);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public static synchronized String encrypt(String str)
			throws SecurityException {
		if (!setup) {
			setup = setEncrypt();
		}
		try {
			return new String(encoder.encode(encryptCipher.doFinal(str
					.getBytes("UTF8"))));
		} catch (Exception e) {
			throw (SecurityException) e;
			//e.printStackTrace();
			//throw new SecurityException("Could not encrypt: " + e.getMessage());
		}
	}

	public static synchronized String decrypt(String str)
			throws SecurityException {
		if (!setup) {
			setup = setEncrypt();
		}
		try {
			return new String(decryptCipher.doFinal(decoder.decode(str
					.getBytes("UTF8"))));
		} catch (Exception e) {
			try{
				System.out.println("decrypt replacing space");
				return new String(decryptCipher.doFinal(decoder.decode(str.replaceAll(" ", "+")
					.getBytes("UTF8"))));
		    } catch (Exception e3) {
		    	System.out.println("decrypt received bad data:**"+ str + "**");
		    	throw (SecurityException) e3;
		    }
		}
	}

}
