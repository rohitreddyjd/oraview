package sqlGraph;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;

public class GetGraph extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public GetGraph() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		if(!sqlGraph.Usr.validate(
			    (request.getHeader("STANDARDID") == null) ? 
		    		request.getRemoteUser(): 
			    	request.getHeader("STANDARDID"),
			"DBA")){
			response.sendRedirect("NoAccess.html");
		}
		long tm = System.currentTimeMillis();
		HttpSession session = request.getSession(false);
		String dSetName = request.getParameter("dSetName");
		if ((dSetName == null || dSetName.isEmpty())) {
			dSetName = "dSet";
		}
		String sessWaitstr = request.getParameter("sessWait");
		boolean sessWaitchart = false;
		if (!(sessWaitstr == null || sessWaitstr.isEmpty())) {
			sessWaitchart = true;
		}
		String ht = request.getParameter("ht");
		int height = 200;
		if (!(ht == null || ht.isEmpty())) {
			try{
				height = Integer.parseInt(ht);
			} catch(Exception e){
				e.printStackTrace();
				height=(sessWaitchart)?250:200;
			}
		}
		if (height < 20 || height > 5000){
			height=(sessWaitchart)?250:200;
		}
		String sv = request.getParameter("save");
		boolean saveIt = false;
		if (!(sv == null || sv.isEmpty())) {
 		  saveIt = true;
		}
		if(saveIt){
			response.setContentType("image/png");
			response.setHeader("Content-Disposition", 
					"attachment; filename=\"" + 
					sv + "\"");
		} else{
			response.setContentType("image/png");
		}
		if(sessWaitchart){
			String dSet = (String)session.getAttribute(dSetName);
			if (dSet == null) {
				dSet = (String)session.getAttribute(dSetName);
				if (dSet == null) {
					session = request.getSession(false);
					dSet = (String)session.getAttribute(dSetName);
					if (dSet == null) {

						System.err.println("GetGraph received Null for dSet "+dSetName);

						PrintWriter out = response.getWriter();
						// TODO: should return error pic
						out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 "
								+ "Transitional//EN\">\n" + "<HTML>\n"
								+ "<HEAD><TITLE>" + "Error" + "</TITLE></HEAD>\n"
								+ "<BODY>\n" + "<H1>" + "Null Data Set Attribute"
								+ "</H1>\n" + "</BODY></HTML>");
						return;
					}
				}
			}
			JFreeChart pieChart = ChartFactory.createPieChart3D(null, 
					DbSQL.getSessWaitxyDataset(dSet), 
					true, false, false);
			pieChart.setBorderVisible(false);
			final PiePlot plot = (PiePlot) pieChart.getPlot();
			plot.setLabelGenerator(null);
			plot.setBackgroundPaint(null);
			plot.setOutlinePaint(null);
			plot.setLabelOutlinePaint(null);
			DbSQL.makeChartPNG(pieChart, 300, height, response.getOutputStream());
		} else{
			//XYDataset dSet = (XYDataset) session.getAttribute(dSetName);
			String dSet = (String) session.getAttribute(dSetName);
			ArrayList<String> options = new ArrayList<String>();
			if (dSet == null) {
				dSet = (String) session.getAttribute(dSetName);
				if (dSet == null) {
					session = request.getSession(false);
					dSet = (String) session.getAttribute(dSetName);
					if (dSet == null) {
						System.err.println("GetGraph received Null for dSet "+dSetName);
						PrintWriter out = response.getWriter();
						// TODO: should return error pic
						out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 "
								+ "Transitional//EN\">\n" + "<HTML>\n"
								+ "<HEAD><TITLE>" + "Error" + "</TITLE></HEAD>\n"
								+ "<BODY>\n" + "<H1>" + "Null Data Set Attribute"
								+ "</H1>\n" + "</BODY></HTML>");
						return;
					}
				}
			}
			for(@SuppressWarnings("unchecked") Enumeration <String>e=request.getParameterNames();e.hasMoreElements();){
				String x = (String)e.nextElement();
				if (!x.equalsIgnoreCase("ht") && !x.equalsIgnoreCase("dSetName")){
					options.add(x);
				}
			}
			DbSQL.makeChartPNG(DbSQL.getSQLPlnChart(dSet, options), 750, height,
					response.getOutputStream());
		}
		System.out.println("Chart Display Time:".concat(new Long(System
				.currentTimeMillis() - tm).toString()));
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
