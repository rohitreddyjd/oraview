package sqlGraph;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp.PoolingDriver;
//import org.apache.tomcat.dbcp.pool.impl.GenericObjectPool;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

//@SuppressWarnings("unused")
public abstract class ConfigDbSQL {
	
	private static final String JAVA_COMP_ENV = "java:/comp/env";
	private static final String CONFIG_DB = "jdbc/oraData";

	private ConfigDbSQL(){
		throw new Error();
	}

	private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle
			.getBundle("messages");

	public static boolean deleteConGroup(String group) {
		if (group == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL
					.getString("deleteConGroupAccessForGroup"));
			stmt.setString(1, group);
			stmt.executeUpdate();
			stmt.close();
			stmt = conn.prepareStatement(DbSQL.getString("deleteConGroup"));
			stmt.setString(1, group);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean deleteAccess(String user, String role) {
		if (user == null || role == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("deleteAccess"));
			stmt.setString(1, user);
			stmt.setString(2, role);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean deleteAllAccessForUser(String userName) {
		if (userName == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn
					.prepareStatement(DbSQL.getString("deleteAllUserAccess"));
			stmt.setString(1, userName);
			stmt.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean deleteAllAccessToRole(String roleName) {
		if (roleName == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn
					.prepareStatement(DbSQL.getString("deleteAllRoleAccess"));
			stmt.setString(1, roleName);
			stmt.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean deleteConGroupAccess(String group, String db) {
		if (group == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();

			stmt = conn.prepareStatement(DbSQL
					.getString("deleteConGroupAccess"));
			stmt.setString(1, group);
			stmt.setString(2, db);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean deleteDb(String db_name) {
		if (db_name == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL
					.getString("deleteConGroupAccessForDb"));
			stmt.setString(1, db_name);
			stmt.executeUpdate();
			stmt.close();
			stmt = conn.prepareStatement(DbSQL.getString("deleteDb"));
			stmt.setString(1, db_name);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
			try {
				new PoolingDriver().closePool(db_name);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static List<String> getConGroups() {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<String> aset = new ArrayList<String>();
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getConGroups"));
			rs = stmt.executeQuery();
			while (rs.next()) {
				aset.add(rs.getString(1));
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return aset;
	}

	public static String getJSONConGroups() {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		List<String> grps = getConGroups();
		for (int i = 0; i < grps.size(); i++) {
			inArray = new JSONArray();
			inArray.put(grps.get(i));
			outArray.put(inArray);
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static List<String> getConGroupsForDb(String dbName) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<String> aset = new ArrayList<String>();
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getConGroupsForDb"));
			stmt.setString(1, dbName);
			rs = stmt.executeQuery();
			while (rs.next()) {
				aset.add(rs.getString(1));
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return aset;
	}

	public static String getJSONConGroupsForDb(String dbName) {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		List<String> grps = getConGroupsForDb(dbName);
		for (int i = 0; i < grps.size(); i++) {
			inArray = new JSONArray();
			inArray.put(grps.get(i));
			outArray.put(inArray);
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static List<String> getConGroupsStatusForDb(String dbName) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<String> aset = new ArrayList<String>();
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getConGroupsStatusForDb"));
			stmt.setString(1, dbName);
			rs = stmt.executeQuery();
			while (rs.next()) {
				aset.add(rs.getString(1));
				aset.add(rs.getString(2));
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return aset;
	}

	public static String getJSONConGroupsStatusForDb(String dbName) {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		List<String> grps = getConGroupsStatusForDb(dbName);
		for (int i = 0; i < grps.size(); i+=2) {
			inArray = new JSONArray();
			inArray.put(grps.get(i));
			inArray.put(grps.get(i + 1));
			outArray.put(inArray);
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static List<String> getDbsStatusForConGroup(String groupName) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<String> aset = new ArrayList<String>();
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getDbsStatusForConGroup"));
			stmt.setString(1, groupName);
			rs = stmt.executeQuery();
			while (rs.next()) {
				aset.add(rs.getString(1));
				aset.add(rs.getString(2));
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return aset;
	}

	public static String getJSONDbsStatusForConGroup(String groupName) {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		List<String> grps = getDbsStatusForConGroup(groupName);
		for (int i = 0; i < grps.size(); i+=2) {
			inArray = new JSONArray();
			inArray.put(grps.get(i));
			inArray.put(grps.get(i + 1));
			outArray.put(inArray);
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static List<String> getDbInfo(String dbName) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<String> aset = new ArrayList<String>();
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getDbInfo"));
			stmt.setString(1, dbName);
			rs = stmt.executeQuery();
			while (rs.next()) {
				aset.add(rs.getString(1)); //connection string
				aset.add(rs.getString(2));  //user name
				String pass = rs.getString(3); //password
				aset.add(pass.startsWith("ENC:")?Encrypt.decrypt(pass.substring(4)):pass);
				aset.add(rs.getString(4)); //password ok ('Expired', 'OK')
				aset.add(rs.getString(5)); //pasword expire 'yyyymmdd'
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return aset;
	}

	public static String getJSONDbInfo(String dbName) {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		List<String> inf = getDbInfo(dbName);
		inArray = new JSONArray();
		inArray.put(inf.get(0));
		inArray.put(inf.get(1));
		inArray.put(inf.get(2));
		outArray.put(inArray);
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static List<String> getDbs() {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<String> aset = new ArrayList<String>();
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getDbs"));
			rs = stmt.executeQuery();
			while (rs.next()) {
				aset.add(rs.getString(1));
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return aset;
	}

	public static String getJSONDbs() {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		List<String> dbs = getDbs();
		for (int i = 0; i < dbs.size(); i++) {
			inArray = new JSONArray();
			inArray.put(dbs.get(i));
			outArray.put(inArray);
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static List<String> getDbsForConGroup(String grpName) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<String> aset = new ArrayList<String>();
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV))
					.lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getDbsForConGroup"));
			stmt.setString(1, grpName);
			rs = stmt.executeQuery();
			while (rs.next()) {
				aset.add(rs.getString(1));
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return aset;
	}

	public static String getJSONDbsForConGroup(String grpName) {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		List<String> dbs = getDbsForConGroup(grpName);
		for (int i = 0; i < dbs.size(); i++) {
			inArray = new JSONArray();
			inArray.put(dbs.get(i));
			outArray.put(inArray);
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static String getJSONDbsForConGroupPad(String grpName) {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		String [] grpLst = grpName.split(",");
		String grps = new String("");
		for(int x = 0; x < grpLst.length; x++){
			if(grpLst[x].length() > 0){
				if(grps.length() > 1){ 
					grps = grps + ","; 
				}
				grps = grps + "'" + grpLst[x] + "'";
			}
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getDbsForConGroups")
					.replaceAll("XXXX", grps));
			rs = stmt.executeQuery();
			while (rs.next()) {
				inArray =  new JSONArray();
				inArray.put(rs.getString(1));
				inArray.put("");
				inArray.put("");
				inArray.put("");
				outArray.put(inArray);
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	public static String getDefault(String defaultName) {
		if (defaultName == null) {
			return "";
		}
		String defaultValue = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getDefaultValue"));
			stmt.setString(1, defaultName);
			rs = stmt.executeQuery();
			if (rs.next()) {
				defaultValue = rs.getString(1);
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		if (defaultValue == null) {
			defaultValue = "";
		}
		return defaultValue;
	}

	public static String getJSONDefault(String defaultName) {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		String defVal = getDefault(defaultName);
		inArray = new JSONArray();
		inArray.put(defVal);
		outArray.put(inArray);
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static List<String> getMatchingString(String key) {
		ArrayList<String> value = new ArrayList<String>();
		for (Enumeration<String> e = RESOURCE_BUNDLE.getKeys(); e
				.hasMoreElements();) {
			String ky = (String) e.nextElement();
			if (ky.startsWith(key)) {
				value.add(ky);
				// RESOURCE_BUNDLE.getObject(ky);
			}
		}
		Collections.sort(value);
		return value;
	}

	public static String getString(String key) {
		try {
			return RESOURCE_BUNDLE.getString(key);
		} catch (MissingResourceException e) {
			return '!' + key + '!';
		}
	}

	public static boolean insertAccessList(String user, String role) {
		if (user == null || role == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("insertAccess"));
			stmt.setString(1, user);
			stmt.setString(2, role);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;

	}

	public static boolean insertConGroup(String group) {
		if (group == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("insertConGroup"));
			stmt.setString(1, group);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean insertConGroupAccess(String group, String db) {
		if (group == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL
					.getString("insertConGroupAccess"));
			stmt.setString(1, group);
			stmt.setString(2, db);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean insertDb(String db_name, String con_str,
			String user_name, String user_pass, String pass_expiry) {
		if (db_name == null || con_str == null || user_name == null
				|| user_pass == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			try {
				new PoolingDriver().closePool(db_name);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("insertDb"));
			stmt.setString(1, db_name);
			stmt.setString(2, con_str);
			stmt.setString(3, user_name);
			stmt.setString(4, user_pass.startsWith("ENC:")?user_pass:"ENC:"+Encrypt.encrypt(user_pass));
			if(pass_expiry == null || pass_expiry.isEmpty()){
				stmt.setNull(5, java.sql.Types.VARCHAR);
			} else {
				stmt.setString(5, pass_expiry);
			}
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean setConGroupsForDb(List<String> groups, String dbName) {
		if (groups == null || dbName == null) {
			return false;
		}
		List<String> oldGroups = getConGroupsForDb(dbName);
		if (oldGroups == null) {
			return false;
		}
		boolean retCd = true;
		for (int x = 0; x < groups.size(); x++) {
			if (!oldGroups.contains(groups.get(x))) {
				if (!insertConGroupAccess(groups.get(x), dbName)) {
					retCd = false;
				}
			}
		}
		for (int x = 0; x < oldGroups.size(); x++) {
			if (!groups.contains(oldGroups.get(x))) {
				if (!deleteConGroupAccess(oldGroups.get(x), dbName)) {
					retCd = false;
				}
			}
		}
		return retCd;
	}

	public static boolean setDbsForConGroup(List<String> dbs, String grpName) {
		if (dbs == null || grpName == null) {
			return false;
		}
		List<String> oldDbs = getDbsForConGroup(grpName);
		if (oldDbs == null) {
			return false;
		}
		boolean retCd = true;
		for (int x = 0; x < dbs.size(); x++) {
			if (!oldDbs.contains(dbs.get(x))) {
				if (!insertConGroupAccess(grpName, dbs.get(x))) {
					retCd = false;
				}
			}
		}
		for (int x = 0; x < oldDbs.size(); x++) {
			if (!dbs.contains(oldDbs.get(x))) {
				if (!deleteConGroupAccess(grpName, oldDbs.get(x))) {
					retCd = false;
				}
			}
		}
		return retCd;
	}

	public static boolean setDefault(String defaultName, String defaultValue) {
		if (defaultName == null || defaultValue == null) {
			return false;
		}
		boolean exists = (getDefault(defaultName).length()>0);
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString(
					(exists)?"updateDefaultValue":"insertDefaultValue"
					));
			stmt.setString(1, defaultValue);
			stmt.setString(2, defaultName);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean updateConGroupName(String oldGroup, String newGroup) {
		if (oldGroup == null || newGroup == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL
					.getString("renameConGroupAccessForGroup"));
			stmt.setString(1, newGroup);
			stmt.setString(2, oldGroup);
			stmt.executeUpdate();
			stmt.close();
			stmt = conn.prepareStatement(DbSQL.getString("renameConGroup"));
			stmt.setString(1, newGroup);
			stmt.setString(2, oldGroup);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean expireDb(String db_name) {
		try {
			new PoolingDriver().closePool(db_name);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		List<String> inf = ConfigDbSQL.getDbInfo(db_name);
		
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("updateDb"));
			stmt.setString(1, inf.get(0));
			stmt.setString(2, inf.get(1));
			stmt.setString(3, inf.get(2).startsWith("ENC:")?inf.get(2):"ENC:"+Encrypt.encrypt(inf.get(2)));
			stmt.setString(4, "20000101");
			stmt.setString(5, db_name);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}
	
	public static boolean updateDb(String db_name, String con_str,
			String user_name, String user_pass, String pass_expiry) {
		
		if (db_name == null || con_str == null || user_name == null
				|| user_pass == null) {
			return false;
		}
		try {
			new PoolingDriver().closePool(db_name);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("updateDb"));
			stmt.setString(1, con_str);
			stmt.setString(2, user_name);
			stmt.setString(3, user_pass.startsWith("ENC:")?user_pass:"ENC:"+Encrypt.encrypt(user_pass));
			if(pass_expiry == null || pass_expiry.isEmpty()){
				stmt.setNull(4, java.sql.Types.VARCHAR);
			} else {
				stmt.setString(4, pass_expiry);
			}
			stmt.setString(5, db_name);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean updateDbName(String oldDbName, String newDbName) {
		if (oldDbName == null || newDbName == null) {
			return false;
		}
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean retCd = false;
		try {
			try {
				new PoolingDriver().closePool(oldDbName);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			try {
				new PoolingDriver().closePool(newDbName);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL
					.getString("renameConGroupAccessForDb"));
			stmt.setString(1, newDbName);
			stmt.setString(2, oldDbName);
			stmt.executeUpdate();
			stmt.close();
			stmt = conn.prepareStatement(DbSQL.getString("renameDb"));
			stmt.setString(1, newDbName);
			stmt.setString(2, oldDbName);
			if (stmt.executeUpdate() == 1) {
				conn.commit();
				retCd = true;
			}
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}

	public static boolean validateUserInGroup(String user, String group) {
		if (user == null || group == null) {
			return false;
		}
		boolean retCd = false;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getAccessList"));
			stmt.setString(1, user);
			stmt.setString(2, group);
			rs = stmt.executeQuery();
			if (rs.next()) {
				retCd = true;
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return retCd;
	}












	public static List<String> getUserList() {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<String> aset = new ArrayList<String>();
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getUserList"));
			rs = stmt.executeQuery();
			while (rs.next()) {
				aset.add(rs.getString(1));
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		return aset;
	}

	public static String getJSONUserList() {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		List<String> dbs = getUserList();
		for (int i = 0; i < dbs.size(); i++) {
			inArray = new JSONArray();
			inArray.put(dbs.get(i));
			outArray.put(inArray);
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}


	public static String getJSONRoleStatusForUser(String user) {
		JSONObject result = new JSONObject();
		JSONArray outArray = new JSONArray();
		JSONArray inArray;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = ((DataSource) ((Context) (new InitialContext())
					.lookup(JAVA_COMP_ENV)).lookup(CONFIG_DB))
					.getConnection();
			stmt = conn.prepareStatement(DbSQL.getString("getRoleStatusForUser"));
			stmt.setString(1, user);
			rs = stmt.executeQuery();
			while (rs.next()) {
				inArray = new JSONArray();
				inArray.put(rs.getString(1));
				inArray.put(rs.getString(2));
				outArray.put(inArray);
			}
			rs.close();
			rs = null;
			stmt.close();
			stmt = null;
			conn.close();
			conn = null;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					;
				}
				rs = null;
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					;
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					;
				}
				conn = null;
			}
		}
		try {
			result.put("aaData", outArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	public static boolean setRolesForUser(List<String> roles, String user) {
		/*quick dirty code...  should definitely rewrite this */
		if (user == null || roles == null) {
			return false;
		}
		deleteAllAccessForUser(user);
		for (int x = 0; x < roles.size(); x++) {
			insertAccessList(user, roles.get(x));
		}
		return true;
	}


}
