$(document).ready(function(){
   /*alert('got here');*/
   $('body').prepend('<button onclick="window.location.reload(true);">Reload</button>' +
      '&nbsp;&nbsp;&nbsp;&nbsp;Double click on sqlid to see further details.');
   var sqlcol = $("table tr th:contains('SQL Id')").index();
   /* single click code       $('td').on('click',function() {*/
   $('td').dblclick(function() {
        var col = $(this).parent().children().index($(this));
		if (col == sqlcol ){
        	var row = $(this).parent().parent().children().index($(this).parent());
	        /*alert('Row: ' + row + ', Column: ' + col );*/
            var xstr = $(this).html();
			var sqlid = xstr.substring(xstr.indexOf(">") + 2, xstr.indexOf("<",xstr.indexOf(">")) ).trim();
			var execid= xstr.substring(xstr.indexOf("id:") + 3, xstr.indexOf("<",xstr.indexOf("</span")) ).trim();
            /*alert( "!" + sqlid + "!");*/
            window.open('DisplaySQLMonitor.jsp?connm='+$('#connm').val()+'&sqlid='+sqlid+'&execid='+execid+'&HTMLOnly='+$('#HTMLOnly').val());
		}
  });
});
