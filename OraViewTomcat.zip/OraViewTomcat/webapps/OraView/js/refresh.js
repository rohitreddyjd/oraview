$(document).ready(function(){
   /*alert('got here');*/
   $('body').prepend('<button onclick="window.location.reload(true);">Reload</button>');
});
