(function($) {
	$.fn.dataTableExt.oApi.fnGetColumnData = function ( oSettings, iColumn, bUnique, bFiltered, bIgnoreEmpty ) {
		if ( typeof iColumn == "undefined" ) return new Array();
		if ( typeof bUnique == "undefined" ) bUnique = true;
		if ( typeof bFiltered == "undefined" ) bFiltered = true;
		if ( typeof bIgnoreEmpty == "undefined" ) bIgnoreEmpty = true;
		var aiRows;
		if (bFiltered == true) aiRows = oSettings.aiDisplay; 
		else aiRows = oSettings.aiDisplayMaster; // all row numbers
		var asResultData = new Array();
		for (var i=0,c=aiRows.length; i<c; i++) {
			iRow = aiRows[i];
			var aData = this.fnGetData(iRow);
			var sValue = aData[iColumn];
			/*jrt start*/
			if(!sValue){
				continue;
			}
			if(sValue.length > 20){
				var fVal = sValue.indexOf(">") + 1;
				if(fVal > 0){
					var lVal = sValue.indexOf("</a>");  /*was with - 1... not sure what changed*/
					if( lVal > 0 ){
						if( lVal > fVal){
							sValue = sValue.substring(fVal, lVal);
							if(sValue.indexOf(">") > 0){
								continue;
							}
						} else {
							continue;  //whack partial matches...
						}
					}	
				}
			}
			/*jrt end*/
			if (bIgnoreEmpty == true && sValue.length == 0) continue;
			else if (bUnique == true && jQuery.inArray(sValue, asResultData) > -1) continue;
			else asResultData.push(sValue);
			if(asResultData.length > 100) return new Array(); //john
		}
		asResultData.sort(                 
				   function (a,b){                     
					   	if ( isNaN(a)&&isNaN(b)) return a<b?-1:a==b?0:1;//both are string
					   	else if (isNaN(a)) return 1;//only a is a string
						else if (isNaN(b)) return -1;//only b is a string
					    else return a-b;//both are num
				   }); 
		if(asResultData.length < 2) return new Array();
		return asResultData;
	};}(jQuery));
	
	function fnCreateSelect( aData, defVal )
	{
		if ( typeof defVal == "undefined" ) defVal = "doNotMatchEver:-)";
		var cnt=0;
		var r='<select><option value=""></option>', i, iLen=aData.length;
		for ( i=0 ; i<iLen ; i++ )
		{
			if((defVal == aData[i]) ||  (defVal ==  ("^" + aData[i] +  "$"))){
				r += '<option selected="selected" value="'+aData[i]+'">'+aData[i]+'</option>';
			} else {
				r += '<option value="'+aData[i]+'">'+aData[i]+'</option>';
			}
			cnt++;
		}
		if(cnt < 2){
			return '';
		}
		return r+'</select>';
	}
	
	$.fn.dataTableExt.oApi.fnReloadAjax = function ( oSettings, sNewSource, fnCallback, bStandingRedraw ){ 
		if ( typeof sNewSource != 'undefined' && sNewSource != null ){ 
			oSettings.sAjaxSource = sNewSource; 
		} 
		this.oApi._fnProcessingDisplay( oSettings, true ); 
		var that = this; 
		var iStart = oSettings._iDisplayStart; 
		var aData = []; 
		this.oApi._fnServerParams( oSettings, aData ); 
		oSettings.fnServerData( oSettings.sAjaxSource, aData, function(json) { 
		that.oApi._fnClearTable( oSettings ); 
		var aData = (oSettings.sAjaxDataProp !== "") ? 
		that.oApi._fnGetObjectDataFn( oSettings.sAjaxDataProp )( json ) : json; 
		for ( var i=0 ; i<aData.length ; i++ )	{ 
			that.oApi._fnAddData( oSettings, aData[i] ); 
		} 
		oSettings.aiDisplay = oSettings.aiDisplayMaster.slice(); 
		that.fnDraw(); 
		if ( typeof bStandingRedraw != 'undefined' && bStandingRedraw === true ) { 
			oSettings._iDisplayStart = iStart; 
			that.fnDraw( false ); 
		} 
		that.oApi._fnProcessingDisplay( oSettings, false ); 
		if ( typeof fnCallback == 'function' && fnCallback != null ) { 
			fnCallback( oSettings ); 
		} 
	}, oSettings ); 
	}; 
	$.fn.dataTableExt.oApi.fnFilterClear  = function ( oSettings ) {     
		oSettings.oPreviousSearch.sSearch = "";
		if ( typeof oSettings.aanFeatures.f != 'undefined' ){
			var n = oSettings.aanFeatures.f;         
			for ( var i=0, iLen=n.length ; i<iLen ; i++ ){
				$('input', n[i]).val( '' );         
			}     
		}           
		 for ( var i=0, iLen=oSettings.aoPreSearchCols.length ; i<iLen ; i++ )     {
			 oSettings.aoPreSearchCols[i].sSearch = "";     
		 }           
		oSettings.oApi._fnReDraw( oSettings ); 
	}; 	
	
	jQuery.fn.dataTableExt.oApi.fnSetFilteringDelay = function ( oSettings, iDelay ) {     
       var _that = this, iDelay = (typeof iDelay == 'undefined') ? 250 : iDelay;           
       this.each( function ( i ) {         
	     $.fn.dataTableExt.iApiIndex = i;        
         var $this = this, oTimerId = null, sPreviousSearch = null,
         anControl = $( 'input', _that.fnSettings().aanFeatures.f );
		 anControl.unbind( 'keyup' ).bind( 'keyup', function() {             
		   var $$this = $this;               
	       if (sPreviousSearch === null || sPreviousSearch != anControl.val()) {
 	          window.clearTimeout(oTimerId);                 
		      sPreviousSearch = anControl.val();
		      oTimerId = window.setTimeout(function() {
	          $.fn.dataTableExt.iApiIndex = i;
	          _that.fnFilter( anControl.val() );
	       }, iDelay);
           }         
        });                   
        return this;     
       } );     
       return this; 
    }; 

    
    
    