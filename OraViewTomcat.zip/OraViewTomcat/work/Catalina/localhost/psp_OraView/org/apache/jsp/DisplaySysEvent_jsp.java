package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import sqlGraph.DbSQL;
import sqlGraph.Connect;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import sqlGraph.ConfigDbSQL;

public final class DisplaySysEvent_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");

	if(!sqlGraph.Usr.validate(
		    (request.getHeader("STANDARDID") == null) ? 
	    		request.getRemoteUser(): 
		    	request.getHeader("STANDARDID"),
		"DBA")){
	response.sendRedirect("NoAccess.html");
	}
	String conNm = (request.getParameter("connm") == null) ? ConfigDbSQL.getDefault("FirstDB") : request.getParameter("connm");
	String graph[] = request.getParameterValues("graph");
	if (graph == null) {
		graph = new String[0];
	}
	String days = request.getParameter("days");
	if (days == null || days.length() < 1) {
		days = "30";
	}

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<link rel=\"shortcut icon\" href=\"icons/favicon.ico\" />\r\n");
      out.write("<link rel=\"icon\" type=\"image/gif\" href=\"icons/favicon.ico\" />\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Display System Events for ");
      out.print(conNm);
      out.write("</title>\r\n");
      out.write("<meta http-equiv=\"Pragma\" content=\"no-cache\" />\r\n");
      out.write("<style type=\"text/css\" title=\"currentStyle\">\r\n");
      out.write("@import \"css/style.css\";\r\n");
      out.write("\r\n");
      out.write("@import \"css/demo_table.css\";\r\n");
      out.write("</style>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\"\r\n");
      out.write("\tsrc=\"js/jquery.dataTables.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\" \r\n");
      out.write("\tsrc=\"js/jquery.dataTables.add.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\"\r\n");
      out.write("\tsrc=\"js/TableTools.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("/* <![CDATA[ */\r\n");
      out.write("var graph= \"\";\r\n");
      out.write("var days=\"\";\r\n");
      out.write("var initChart=false;\r\n");
      out.write("var currentTime = new Date();\r\n");
      out.write("var dSetName=\"\";\r\n");
      out.write("var nm=\"\";\r\n");
      out.write("var oTable2;\r\n");
      out.write("\r\n");
      out.write("$(document).ready(function() {\r\n");
      out.write("\tvar oTable = $('#graph').dataTable({\r\n");
      out.write("\t\t\"bProcessing\" : true,\r\n");
      out.write("\t\t\"sAjaxSource\" : \"GetList?connm=");
      out.print(conNm);
      out.write("&tp=sysevt\",\r\n");
      out.write("\t\t\"bDeferRender\" : true,\r\n");
      out.write("\t\t\"sScrollY\" : \"240px\",\r\n");
      out.write("\t\t\"sScrollX\" : \"100%\", \r\n");
      out.write("\t\t\"bScrollCollapse\": true,\r\n");
      out.write("\t\t\"sDom\": 'lrt<\"bottom\"f>',\r\n");
      out.write("\t\t\"bPaginate\" : false,\r\n");
      out.write("\t\t\"bInfo\": false, \r\n");
      out.write("\t\tfnInitComplete: function () {\r\n");
      out.write("\t\t\tvar z = -1;\r\n");
      out.write("\t\t\t$(\"thead td\").each( function ( i ) {\r\n");
      out.write("\t\t\t\tvar fircol = 0; \r\n");
      out.write("\t\t\t\tif(this.id.match(/^graph_/) &&\r\n");
      out.write("\t\t\t\t\t\tthis.innerHTML.length > 0){\r\n");
      out.write("\t\t\t\t\tif ( z == -1 ){\r\n");
      out.write("\t\t\t\t\t\tz = i + fircol;\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\tvar sel = fnCreateSelect( oTable.fnGetColumnData(i - z) );\r\n");
      out.write("\t\t\t\t\tif (sel.length == 0){\r\n");
      out.write("\t\t\t\t\t\tsel = '<b></b>';\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\tthis.innerHTML = sel;\r\n");
      out.write("\t\t\t\t\t$('select', this).change( function () {\r\n");
      out.write("\t\t\t\t\t\toTable.fnFilter( $(this).val(), i - z );\r\n");
      out.write("\t\t\t\t\t} );\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t} );\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\t$('#graph tr').click( function() {\r\n");
      out.write("\t\t\t\tvar mctr = 5; /* this is the maximum number of options you want selected */\t\t\r\n");
      out.write("\t\t    \tif(oTable.$('tr.row_selected').length >= mctr\r\n");
      out.write("\t\t    \t\t\t&& !($(this).attr('class').match(/row_selected/))){\r\n");
      out.write("\t\t    \t\talert(\"You have selected too many items for a single graph only \" + \r\n");
      out.write("\t\t    \t\t\t\tmctr + \" will display.\");\r\n");
      out.write("\t\t    \t} else{\r\n");
      out.write("\t\t        \t$(this).toggleClass('row_selected');\r\n");
      out.write("\t\t    \t}\r\n");
      out.write("\t\t   \t} );\r\n");
      out.write("\t        ");
if (graph.length > 0) {
      out.write("\r\n");
      out.write("\t\t       var optlist = oTable.$('tr');\r\n");
      out.write("\t\t       var drawit = false;\r\n");
      out.write("\t\t       for(x = 0; x < optlist.length; x++)\r\n");
      out.write("\t\t       {\r\n");
      out.write("\t\t\t   ");
for (int i = 0; i < graph.length; i++) {
					if (graph[i].length() > 0) {
      out.write("\r\n");
      out.write("\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\tif ( optlist[x].innertHTML != null){\r\n");
      out.write("\t\t\t\t\t\talert(\"innerHTML = \" + optlist[x].innertHTML);\r\n");
      out.write("\t\t\t\t\t}\t\r\n");
      out.write("\t\t\t\t  if ( optlist[x].childNodes != null && optlist[x].childNodes.length > 0 ) {\r\n");
      out.write("\t\t\t\t    if ( optlist[x].childNodes[1].innerHTML.match(/^");
      out.print(graph[i]);
      out.write("$/)) {\r\n");
      out.write("\t\t\t\t    \t$(optlist[x]).toggleClass('row_selected');\r\n");
      out.write("\t\t\t\t    \tdrawit = true;\r\n");
      out.write("\t\t\t\t    }\r\n");
      out.write("\t\t\t\t  }\r\n");
      out.write("\t\t\t\t");
}
				}
      out.write("\r\n");
      out.write("\t\t\t\t }\r\n");
      out.write("\t\t    \tif(drawit){\r\n");
      out.write("\t\t\t\t  \t$(\"#getChart\").click();\r\n");
      out.write("\t\t    \t}  \t\r\n");
      out.write("\t\t\t");
}
      out.write("\r\n");
      out.write("\t\t\toTable.fnAdjustColumnSizing();\r\n");
      out.write("\t\t\toTable.fnSetFilteringDelay();\t\r\n");
      out.write("\t\t}\r\n");
      out.write("\t});\r\n");
      out.write("    $(\"#getChart\").click(function(){\r\n");
      out.write("    \tvar optlist = oTable.$('tr.row_selected');\r\n");
      out.write("    \tif(optlist.length < 1){\r\n");
      out.write("    \t\talert(\"Please make a selection first.\");\r\n");
      out.write("    \t} else {\r\n");
      out.write("\t        document.getElementById(\"pic1Div\").innerHTML=\"Submitted Request.<br>Please Wait.\";\r\n");
      out.write("\t        document.getElementById(\"pic2Div\").innerHTML=\"\";\r\n");
      out.write("\t        document.getElementById(\"pic3Div\").innerHTML=\"\";\r\n");
      out.write("\t        graph= \"\";\r\n");
      out.write("\t        for(i = 0; i < optlist.length; i++){\r\n");
      out.write("\t        \tgraph += \"&graph\" + \"=\" + encodeURIComponent(optlist[i].childNodes[1].innerHTML);\r\n");
      out.write("\t        }\r\n");
      out.write("\t        days=document.getElementById('days').value;\r\n");
      out.write("\t        nm=optlist[0].childNodes[1].innerHTML.replace(/ /g,\"_\");\r\n");
      out.write("\t        get_chart();\r\n");
      out.write("\t\t}\r\n");
      out.write("\r\n");
      out.write("\t});\r\n");
      out.write("\r\n");
      out.write("\t$(\"div\").each( function ( i ) {\r\n");
      out.write("\t\tif((this.id.match(/^bindex/))){\r\n");
      out.write("\t\t\t$(this).hide();\r\n");
      out.write("\t\t}\r\n");
      out.write("\t} );\r\n");
      out.write("    \r\n");
      out.write("\t$(\"#clearSelect\").click(function() {\r\n");
      out.write("\t\tvar optlist = oTable.$('tr.row_selected');\r\n");
      out.write("\t\tfor (i = 0; i < optlist.length; i++) {\r\n");
      out.write("\t\t\t$(optlist[i]).toggleClass('row_selected');\r\n");
      out.write("\t\t}\r\n");
      out.write("\t});\r\n");
      out.write("\t\r\n");
      out.write("\tfunction get_chart(){\r\n");
      out.write(" \t    currentTime = new Date();\r\n");
      out.write(" \t\tdSetName=\"SYSEVENT_\" + currentTime.getTime();\r\n");
      out.write("\t\tvar day = currentTime.getDate();\r\n");
      out.write(" \t    var month = currentTime.getMonth() + 1;\r\n");
      out.write("\t    var year = currentTime.getFullYear();\r\n");
      out.write("\t    var hours = currentTime.getHours();\r\n");
      out.write(" \t\tif (hours < 10)  hours = \"0\" + hours;\r\n");
      out.write(" \t\tvar minutes = currentTime.getMinutes();\r\n");
      out.write(" \t\tif (minutes < 10)  minutes = \"0\" + minutes;\r\n");
      out.write("\t\tif(initChart){\r\n");
      out.write("\t\t\toTable2.fnClearTable();\r\n");
      out.write("\t\t\toTable2.fnFilterClear();\r\n");
      out.write("\t\t\toTable2.fnReloadAjax(\"GetList?connm=");
      out.print(conNm);
      out.write("&tp=SYSEVTCHART\" + graph + \"&days=\" + days+\"&dSet=\" + dSetName, function(){\r\n");
      out.write("              document.getElementById(\"pic1Div\").innerHTML=\r\n");
      out.write("               \t   \"<h4>Quantity of Events</h4><br>\" + \r\n");
      out.write("        \t\t   \"<img class=\\\"imgclss\\\" id=\\\"\" + nm + \"_qty\" + \"\\\" src=\\\"GetGraph?sysevt=true&ht=300&qty=true&dSetName=\" +\r\n");
      out.write("        \t\t   dSetName + \"\\\" alt=\\\"QTY\\\">\";\r\n");
      out.write("       \t      document.getElementById(\"pic2Div\").innerHTML=\r\n");
      out.write("       \t    \t   \"<h4>Average Time of the Events</h4><br>\"+  \r\n");
      out.write("       \t\t       \"<img class=\\\"imgclss\\\" id=\\\"\" + nm + \"_avg\" + \"\\\" src=\\\"GetGraph?sysevt=true&ht=300&avgms=true&dSetName=\" +\r\n");
      out.write("       \t\t       dSetName + \"\\\" alt=\\\"Average Ms\\\">\";\r\n");
      out.write("       \t      document.getElementById(\"pic3Div\").innerHTML=\r\n");
      out.write("         \t    \t\"<h4>Total Time of the Events</h4><br>\"+  \r\n");
      out.write("       \t\t    \t\"<img class=\\\"imgclss\\\" id=\\\"\" + nm + \"_tot\" + \"\\\" src=\\\"GetGraph?sysevt=true&ht=300&totms=true&dSetName=\" +\r\n");
      out.write("       \t\t    \tdSetName + \"\\\" alt=\\\"Total Ms\\\">\";\r\n");
      out.write("  \t\t      $('#tm').val(month + \"-\" +  day + \"-\" + year + \"_\" + hours + \"-\" + minutes);\r\n");
      out.write("  \t\t      $(\".imgclss\").dblclick( function() {\r\n");
      out.write("\t\t\t    var fnm = \"");
      out.print(conNm);
      out.write("_\"\t+ this.id\t+ \"_\" + month + \"-\" + day+ \"-\" + year + \"_\" + hours \r\n");
      out.write("\t\t\t      + \"-\" + minutes + \".png\";\r\n");
      out.write("\t\t\t    window.location.href = this.src\t\t+ \"&save=\"\t+ fnm;\r\n");
      out.write("  \t\t      });\r\n");
      out.write("\t\t\t  var z = -1;\r\n");
      out.write("\t\t\t  $(\"thead td\").each( function ( i ) {\r\n");
      out.write("\t\t\t\tvar fircol = 0; //starts with 0, skipping first one \r\n");
      out.write("\t\t\t\tif(this.id.match(/^gra2_/) &&\r\n");
      out.write("\t\t\t\t\t\tthis.innerHTML.length > 0){\r\n");
      out.write("\t\t\t\t\tif ( z == -1 ){\r\n");
      out.write("\t\t\t\t\t\tz = i + fircol;\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\tvar sel = fnCreateSelect( oTable2.fnGetColumnData(i - z) );\r\n");
      out.write("\t\t\t\t\tif (sel.length == 0){\r\n");
      out.write("\t\t\t\t\t\tsel = '<b></b>';\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\tthis.innerHTML = sel;\r\n");
      out.write("\t\t\t\t\t$('select', this).change( function () {\r\n");
      out.write("\t\t\t\t\t\toTable2.fnFilter( $(this).val(), i - z );\r\n");
      out.write("\t\t\t\t\t} );\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t  } );\r\n");
      out.write("\t\t      oTable2.fnAdjustColumnSizing();\r\n");
      out.write("\t\t      oTable2.fnSetFilteringDelay();\r\n");
      out.write("\t\t\t} );\r\n");
      out.write("\t\t} else {\r\n");
      out.write("\t\t\tinitChart = true;\r\n");
      out.write("\t\t\t$(\"div\").each( function ( i ) {\r\n");
      out.write("\t\t\t\tif((this.id.match(/^bindex/))){\r\n");
      out.write("\t\t\t\t\t$(this).show();\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t} );\r\n");
      out.write("\t\t\toTable2 = $('#gra2').dataTable({\r\n");
      out.write("\t\t\t\t\"bProcessing\" : true,\r\n");
      out.write("\t\t\t\t\"bStateSave\" : false,\r\n");
      out.write("\t\t\t\t\"sAjaxSource\" : \"GetList?connm=");
      out.print(conNm);
      out.write("&tp=SYSEVTCHART\" + graph + \"&days=\" + days+\"&dSet=\" + dSetName,\r\n");
      out.write("\t\t\t\t\"bDeferRender\" : true,\r\n");
      out.write("\t\t\t\t\"sScrollY\" : \"240px\", \r\n");
      out.write("\t\t\t\t\"sScrollX\" : \"100%\", \r\n");
      out.write("\t\t\t\t\"bScrollCollapse\": true,\r\n");
      out.write("\t\t\t\t\"iDisplayLength\": 100,\r\n");
      out.write("\t\t\t\t\"sPaginationType\": \"full_numbers\",\r\n");
      out.write("\t\t\t\t\"sDom\": 'Trt<\"bottom\"fp>',\r\n");
      out.write("\t\t\t\t/*\r\n");
      out.write("\t\t\t\t\"sDom\": 'Tlrt<\"bottom\"f>',\r\n");
      out.write("\t\t\t\t\"bPaginate\" : false,*/\r\n");
      out.write("\t\t\t\t/*\"sDom\": 'CTlrt<\"bottom\"f>',*/\r\n");
      out.write("\t\t\t\t\"oTableTools\": {            \r\n");
      out.write("\t\t\t\t\t\"aButtons\": [ \"copy\", \r\n");
      out.write("\t\t\t\t\t             {\"sExtends\": \"csv\",\r\n");
      out.write("\t\t\t\t\t              \"fnClick\": function ( nButton, oConfig, oFlash ) {\r\n");
      out.write("\t\t\t\t\t                 oFlash.setFileName(\"");
      out.print(conNm);
      out.write("_sysevt_\" + nm + \"_\" + $('#tm').val() + \".csv\");\r\n");
      out.write("\t\t\t\t\t                 this.fnSetText( oFlash, this.fnGetTableData(oConfig) );    \r\n");
      out.write("\t\t\t\t\t                }\r\n");
      out.write("\t\t\t\t\t              }\r\n");
      out.write("\t\t\t\t\t             ],\r\n");
      out.write("\t\t\t\t\t\"sSwfPath\": \"./swf/copy_csv_xls.swf\"\r\n");
      out.write("\t\t\t\t},\r\n");
      out.write("\t\t       \"oLanguage\": { \"sProcessing\": \"Running Query Against Database\" },\r\n");
      out.write("\t\t\t\t\"bInfo\": false, \r\n");
      out.write("\t\t\t\t/*\"aaSorting\": [[ 1, \"asc\" ], [ 3, \"asc\" ]],*/ \r\n");
      out.write("\t\t\t\t\"aaSorting\": [[ 1, \"desc\" ], [ 0, \"asc\" ]], \r\n");
      out.write("\t\t\t\tfnInitComplete: function () {\r\n");
      out.write("\t              document.getElementById(\"pic1Div\").innerHTML=\r\n");
      out.write("                 \t\"<h4>Quantity of Events</h4><br>\" + \r\n");
      out.write("          \t\t    \"<img class=\\\"imgclss\\\" id=\\\"\" + nm + \"_qty\" + \"\\\" src=\\\"GetGraph?sysevt=true&ht=300&qty=true&dSetName=\" +\r\n");
      out.write("          \t\t    dSetName + \"\\\" alt=\\\"QTY\\\">\";\r\n");
      out.write("         \t      document.getElementById(\"pic2Div\").innerHTML=\r\n");
      out.write("         \t    \t\"<h4>Average Time of the Events</h4><br>\"+  \r\n");
      out.write("         \t\t    \"<img class=\\\"imgclss\\\" id=\\\"\" + nm + \"_avg\" + \"\\\" src=\\\"GetGraph?sysevt=true&ht=300&avgms=true&dSetName=\" +\r\n");
      out.write("         \t\t    dSetName + \"\\\" alt=\\\"Average Ms\\\">\";\r\n");
      out.write("         \t      document.getElementById(\"pic3Div\").innerHTML=\r\n");
      out.write("           \t    \t\"<h4>Total Time of the Events</h4><br>\"+  \r\n");
      out.write("         \t\t    \"<img class=\\\"imgclss\\\" id=\\\"\" + nm + \"_tot\" + \"\\\" src=\\\"GetGraph?sysevt=true&ht=300&totms=true&dSetName=\" +\r\n");
      out.write("         \t\t    dSetName + \"\\\" alt=\\\"Total Ms\\\">\";\r\n");
      out.write("   \t\t  \t\t  $('#tm').val(month + \"-\" +  day + \"-\" + year + \"_\" + hours + \"-\" + minutes);\r\n");
      out.write("   \t\t  \t\t  $(\".imgclss\").dblclick( function() {\r\n");
      out.write("   \t\t\t\t\t  var fnm = \"");
      out.print(conNm);
      out.write("_\"\t+ this.id\t+ \"_\" + month + \"-\" + day+ \"-\" + year + \"_\" + hours \r\n");
      out.write("   \t\t\t\t\t    + \"-\" + minutes + \".png\";\r\n");
      out.write("   \t\t\t\t\t  window.location.href = this.src\t\t+ \"&save=\"\t+ fnm;\r\n");
      out.write("   \t\t  \t\t  });\r\n");
      out.write("\t\t\t\t\t\r\n");
      out.write("\t\t\t\t  var z = -1;\r\n");
      out.write("\t\t\t\t  $(\"thead td\").each( function ( i ) {\r\n");
      out.write("\t\t\t\t\tvar fircol = 0; //starts with 0, skipping first one \r\n");
      out.write("\t\t\t\t\tif(this.id.match(/^gra2_/) &&\r\n");
      out.write("\t\t\t\t\t\t\tthis.innerHTML.length > 0){\r\n");
      out.write("\t\t\t\t\t\tif ( z == -1 ){\r\n");
      out.write("\t\t\t\t\t\t\tz = i + fircol;\r\n");
      out.write("\t\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\t\tvar sel = fnCreateSelect( oTable2.fnGetColumnData(i - z) );\r\n");
      out.write("\t\t\t\t\t\tif (sel.length == 0){\r\n");
      out.write("\t\t\t\t\t\t\tsel = '<b></b>';\r\n");
      out.write("\t\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\t\tthis.innerHTML = sel;\r\n");
      out.write("\t\t\t\t\t\t$('select', this).change( function () {\r\n");
      out.write("\t\t\t\t\t\t\toTable2.fnFilter( $(this).val(), i - z );\r\n");
      out.write("\t\t\t\t\t\t} );\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t  } );\r\n");
      out.write("\t\t\t      oTable2.fnAdjustColumnSizing();\r\n");
      out.write("\t\t\t      oTable2.fnSetFilteringDelay();\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t});\r\n");
      out.write("\t\t\t\r\n");
      out.write("\t\t\t\r\n");
      out.write("\t\t}\r\n");
      out.write("\t}\r\n");
      out.write("});\r\n");
      out.write("\r\n");
      out.write("/* ]]> */\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\t<h2>Display System Events for ");
      out.print(conNm);
      out.write("</h2><HR>\r\n");
      out.write("\t<FORM id=eventform>\r\n");
      out.write("\t\t<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" class=\"display\"\r\n");
      out.write("\t\t\tid=\"graph\">\r\n");
      out.write("\t\t\t<thead>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td id=\"graph_1\"><b></b></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"graph_2\"><b></b></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<th width=\"50%\">Group</th>\r\n");
      out.write("\t\t\t\t\t<th width=\"50%\">Event</th>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t</thead>\r\n");
      out.write("\t\t\t<tbody></tbody>\r\n");
      out.write("\t\t</table>\r\n");
      out.write("\t\t<br> <input type=\"hidden\" name=\"connm\" value=\"");
      out.print(conNm);
      out.write("\">\r\n");
      out.write("\t\t<input type=\"hidden\" name=\"tm\" id=\"tm\" value=\"jnk\"> <b>Days</b><input\r\n");
      out.write("\t\t\ttype=\"text\" size=\"4\" maxlength=\"4\" name=\"days\" id=\"days\"\r\n");
      out.write("\t\t\tvalue=\"");
      out.print(days);
      out.write("\"> <input name=\"getChart\" id=\"getChart\"\r\n");
      out.write("\t\t\ttype=\"button\" value=\"Get Chart\"> <input name=\"clearSelect\"\r\n");
      out.write("\t\t\tid=\"clearSelect\" type=\"button\" value=\"Clear Selection\">\r\n");
      out.write("\t</FORM>\r\n");
      out.write("\t<BR>\r\n");
      out.write("\t<DIV ID=\"bindex\">\r\n");
      out.write("\t\t<H4>Event Chart</H4>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<TABLE CELLPADDING=\"0\" CELLSPACING=\"0\" BORDER=\"0\" CLASS=\"display\" ID=\"gra2\">\r\n");
      out.write("\t\t\t<THEAD>\r\n");
      out.write("\t\t\t\t<TR>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"gra2_1\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"gra2_2\"></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"gra2_3\"></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"gra2_4\"></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"gra2_5\"></TD>\r\n");
      out.write("\t\t\t\t</TR>\r\n");
      out.write("\t\t\t\t<TR>\r\n");
      out.write("\t\t\t\t\t<TH>Name</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Date</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Total Waits</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Avg MS</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Total MS</TH>\r\n");
      out.write("\t\t\t\t</TR>\r\n");
      out.write("\t\t\t</THEAD>\r\n");
      out.write("\t\t\t<TBODY></TBODY>\r\n");
      out.write("\t\t</TABLE>\r\n");
      out.write("\t</DIV> <BR>\r\n");
      out.write("\t<div id=\"pic1Div\"></div>\r\n");
      out.write("\t<BR>\r\n");
      out.write("\t<div id=\"pic2Div\"></div>\r\n");
      out.write("\t<BR>\r\n");
      out.write("\t<div id=\"pic3Div\"></div>\r\n");
      out.write("\t<BR>\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
