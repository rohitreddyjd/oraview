package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import sqlGraph.DbSQL;
import sqlGraph.Connect;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import sqlGraph.ConfigDbSQL;

public final class DisplayMemory_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");

	if(!sqlGraph.Usr.validate(
		    (request.getHeader("STANDARDID") == null) ? 
	    		request.getRemoteUser(): 
		    	request.getHeader("STANDARDID"),
		"DBA")){
	response.sendRedirect("NoAccess.html");
	}
	String conNm = (request.getParameter("connm") == null) ? ConfigDbSQL.getDefault("FirstDB") : request.getParameter("connm");
	String days = request.getParameter("days");
	if (days == null || days.length() < 1) {
		days = "7";
	}

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<link rel=\"shortcut icon\" href=\"icons/favicon.ico\" />\r\n");
      out.write("<link rel=\"icon\" type=\"image/gif\" href=\"icons/favicon.ico\" />\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<TITLE>Database Memory in MG for ");
      out.print(conNm);
      out.write("</TITLE>\r\n");
      out.write("<meta http-equiv=\"Pragma\" content=\"no-cache\" />\r\n");
      out.write("<style type=\"text/css\" title=\"currentStyle\">\r\n");
      out.write("@import \"css/style.css\";\r\n");
      out.write("\r\n");
      out.write("@import \"css/demo_table.css\";\r\n");
      out.write("</style>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\"\r\n");
      out.write("\tsrc=\"js/jquery.dataTables.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\"\r\n");
      out.write("\tsrc=\"js/jquery.dataTables.add.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\"\r\n");
      out.write("\tsrc=\"js/TableTools.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("/* <![CDATA[ */\r\n");
      out.write("\r\n");
      out.write("var days=\"\";\r\n");
      out.write("var currentTime = new Date();\r\n");
      out.write("var dSetName=\"MEMORY_\" + currentTime.getTime();\r\n");
      out.write(";\r\n");
      out.write("var oTable;\r\n");
      out.write("\r\n");
      out.write("$(document).ready(function() {\r\n");
      out.write("\tdays = document.getElementById('days').value;\r\n");
      out.write("\tvar day = currentTime.getDate();\r\n");
      out.write("\tvar month = currentTime.getMonth() + 1;\r\n");
      out.write("    var year = currentTime.getFullYear();\r\n");
      out.write("    var hours = currentTime.getHours();\r\n");
      out.write("\tif (hours < 10)  hours = \"0\" + hours;\r\n");
      out.write("\tvar minutes = currentTime.getMinutes();\r\n");
      out.write("\tif (minutes < 10)  minutes = \"0\" + minutes;\r\n");
      out.write("\toTable = $('#gra1').dataTable({\r\n");
      out.write("\t\t\"bProcessing\" : true,\r\n");
      out.write("\t\t\"bStateSave\" : false,\r\n");
      out.write("\t\t\"sAjaxSource\" : \"GetList?connm=");
      out.print(conNm);
      out.write("&tp=MEMORYCHART&days=\" + days+\"&dSet=\" + dSetName,\r\n");
      out.write("\t\t\"bDeferRender\" : true,\r\n");
      out.write("\t\t\"sScrollY\" : \"240px\",\r\n");
      out.write("\t\t\"sScrollX\" : \"100%\", \r\n");
      out.write("\t\t\"bScrollCollapse\": true,\r\n");
      out.write("\t\t\"iDisplayLength\": 100,\r\n");
      out.write("\t\t\"sPaginationType\": \"full_numbers\",\r\n");
      out.write("\t\t\"sDom\": 'Trt<\"bottom\"fp>',\r\n");
      out.write("\t\t/*\"sDom\": 'CTlrt<\"bottom\"f>',*/\r\n");
      out.write("\t\t\"oTableTools\": {            \r\n");
      out.write("\t\t\t\"aButtons\": [ \"copy\", \r\n");
      out.write("\t\t\t             {\"sExtends\": \"csv\",\r\n");
      out.write("\t\t\t              \"fnClick\": function ( nButton, oConfig, oFlash ) {\r\n");
      out.write("\t\t\t                 oFlash.setFileName(\"");
      out.print(conNm);
      out.write("_MEMORY_\" + days + \"_DAYS_\" + $('#tm').val() + \".csv\");\r\n");
      out.write("\t\t\t                 this.fnSetText( oFlash, this.fnGetTableData(oConfig) );    \r\n");
      out.write("\t\t\t                }\r\n");
      out.write("\t\t\t              }\r\n");
      out.write("\t\t\t             ],\r\n");
      out.write("\t\t\t\"sSwfPath\": \"./swf/copy_csv_xls.swf\"\r\n");
      out.write("\t\t},\r\n");
      out.write("       \"oLanguage\": { \"sProcessing\": \"Running Query Against Database\" },\r\n");
      out.write("\t\t\"bInfo\": false, \r\n");
      out.write("\t\t/*\"aaSorting\": [[ 1, \"asc\" ], [ 3, \"asc\" ]],*/ \r\n");
      out.write("\t\t\"aaSorting\": [[ 1, \"desc\" ], [ 0, \"asc\" ]], \r\n");
      out.write("\t\tfnInitComplete: function () {\r\n");
      out.write("          document.getElementById(\"pic1Div\").innerHTML=\r\n");
      out.write("           \t\"<h4>SGA, PGA, and Total Memory</h4><br>\" + \r\n");
      out.write("   \t\t    \"<img class=\\\"imgclss\\\" id=\\\"SGA_PGA_Total_Memory\" + \"\\\" src=\\\"GetGraph?memory=true&ht=300&sga=true&pga=true&total=true&dSetName=\" +\r\n");
      out.write("   \t\t    dSetName + \"\\\" alt=\\\"SGA PGA Total Memory\\\">\";\r\n");
      out.write("   \t      document.getElementById(\"pic2Div\").innerHTML=\r\n");
      out.write("   \t    \t\"<h4>Buffer Pool and Shared Pool</h4><br>\"+  \r\n");
      out.write("   \t\t    \"<img class=\\\"imgclss\\\" id=\\\"Buffer_Shared_Memory\" + \"\\\" src=\\\"GetGraph?memory=true&ht=300&buffer=true&shared=true&dSetName=\" +\r\n");
      out.write("   \t\t    dSetName + \"\\\" alt=\\\"Buffer Pool and Shared Pool\\\">\";\r\n");
      out.write("   \t      document.getElementById(\"pic3Div\").innerHTML=\r\n");
      out.write("   \t    \t\"<h4>Large Pool and Streams Pool</h4><br>\"+  \r\n");
      out.write("   \t\t    \"<img class=\\\"imgclss\\\" id=\\\"Large_Streams_Memory\" + \"\\\" src=\\\"GetGraph?memory=true&ht=300&large=true&streams=true&dSetName=\" +\r\n");
      out.write("   \t\t    dSetName + \"\\\" alt=\\\"Large Pool and Streams Pool\\\">\";\r\n");
      out.write("   \t      document.getElementById(\"pic4Div\").innerHTML=\r\n");
      out.write("   \t    \t\"<h4>Fixed Pool, Log Buffer and JAVA Pool</h4><br>\"+  \r\n");
      out.write("   \t\t    \"<img class=\\\"imgclss\\\" id=\\\"Fixed_Log_Java_Memory\" + \"\\\" src=\\\"GetGraph?memory=true&ht=300&fixed=true&log=true&java=true&dSetName=\" +\r\n");
      out.write("   \t\t    dSetName + \"\\\" alt=\\\"Fixed Pool, Log Buffer and JAVA Pool\\\">\";\r\n");
      out.write("   \t\t  $('#tm').val(month + \"-\" +  day + \"-\" + year + \"_\" + hours + \"-\" + minutes);\r\n");
      out.write("  \t\t  $(\".imgclss\").dblclick( function() {\r\n");
      out.write("\t\t\t  var fnm = \"");
      out.print(conNm);
      out.write("_\"\t+ this.id\t+ \"_\" + month + \"-\" + day+ \"-\" + year + \"_\" + hours \r\n");
      out.write("\t\t\t    + \"-\" + minutes + \".png\";\r\n");
      out.write("\t\t\t  window.location.href = this.src\t+ \"&save=\"\t+ fnm;\r\n");
      out.write("  \t\t  });\r\n");
      out.write("\t\t\t\r\n");
      out.write("\t\t  var z = -1;\r\n");
      out.write("\t\t  $(\"thead td\").each( function ( i ) {\r\n");
      out.write("\t\t\tvar fircol = 0; //starts with 0, skipping first one \r\n");
      out.write("\t\t\tif(this.id.match(/^gra1_/) &&\r\n");
      out.write("\t\t\t\t\tthis.innerHTML.length > 0){\r\n");
      out.write("\t\t\t\tif ( z == -1 ){\r\n");
      out.write("\t\t\t\t\tz = i + fircol;\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t\tvar sel = fnCreateSelect( oTable.fnGetColumnData(i - z) );\r\n");
      out.write("\t\t\t\tif (sel.length == 0){\r\n");
      out.write("\t\t\t\t\tsel = '<b></b>';\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t\tthis.innerHTML = sel;\r\n");
      out.write("\t\t\t\t$('select', this).change( function () {\r\n");
      out.write("\t\t\t\t\toTable.fnFilter( $(this).val(), i - z );\r\n");
      out.write("\t\t\t\t} );\r\n");
      out.write("\t\t\t}\r\n");
      out.write("\t\t  } );\r\n");
      out.write("\t      oTable.fnAdjustColumnSizing();\r\n");
      out.write("\t      oTable.fnSetFilteringDelay();\r\n");
      out.write("\t\t}\r\n");
      out.write("\t});\r\n");
      out.write("\t\r\n");
      out.write("   \t$(\"#getChart\").click(function(){\r\n");
      out.write("  \t  reload_chart();\r\n");
      out.write("    });\r\n");
      out.write("\r\n");
      out.write("\tfunction reload_chart(){\r\n");
      out.write("\t    days=document.getElementById('days').value;\r\n");
      out.write("\t\t$(\"h1\").each( function ( i ) {\r\n");
      out.write("\t\t\t  this.innerHTML = \"Memory In MG for ");
      out.print(conNm);
      out.write(" going back \" + days + \" days\";\r\n");
      out.write("\t\t} );\r\n");
      out.write(" \t    currentTime = new Date();\r\n");
      out.write(" \t\tdSetName=\"MEMORY_\" + currentTime.getTime();\r\n");
      out.write("\t\tday = currentTime.getDate();\r\n");
      out.write(" \t    month = currentTime.getMonth() + 1;\r\n");
      out.write("\t    year = currentTime.getFullYear();\r\n");
      out.write("\t    hours = currentTime.getHours();\r\n");
      out.write(" \t\tif (hours < 10)  hours = \"0\" + hours;\r\n");
      out.write(" \t\tminutes = currentTime.getMinutes();\r\n");
      out.write(" \t\tif (minutes < 10)  minutes = \"0\" + minutes;\r\n");
      out.write("\t\toTable.fnClearTable();\r\n");
      out.write("\t\toTable.fnFilterClear();\r\n");
      out.write("\t\tdocument.getElementById(\"pic1Div\").innerHTML=\"\";\r\n");
      out.write("\t\tdocument.getElementById(\"pic2Div\").innerHTML=\"\";\r\n");
      out.write("\t\tdocument.getElementById(\"pic3Div\").innerHTML=\"\";\r\n");
      out.write("\t\tdocument.getElementById(\"pic4Div\").innerHTML=\"\";\r\n");
      out.write("\t\toTable.fnReloadAjax( \"GetList?connm=");
      out.print(conNm);
      out.write("&tp=MEMORYCHART&days=\" + days+\"&dSet=\" + dSetName, function(){\r\n");
      out.write("          document.getElementById(\"pic1Div\").innerHTML=\r\n");
      out.write("           \t\"<h4>SGA, PGA, and Total Memory</h4><br>\" + \r\n");
      out.write("   \t\t    \"<img class=\\\"imgclss\\\" id=\\\"SGA_PGA_Total_Memory\" + \"\\\" src=\\\"GetGraph?memory=true&ht=300&sga=true&pga=true&total=true&dSetName=\" +\r\n");
      out.write("   \t\t    dSetName + \"\\\" alt=\\\"SGA PGA Total Memory\\\">\";\r\n");
      out.write("   \t      document.getElementById(\"pic2Div\").innerHTML=\r\n");
      out.write("   \t    \t\"<h4>Buffer Pool and Shared Pool</h4><br>\"+  \r\n");
      out.write("   \t\t    \"<img class=\\\"imgclss\\\" id=\\\"Buffer_Shared_Memory\" + \"\\\" src=\\\"GetGraph?memory=true&ht=300&buffer=true&shared=true&dSetName=\" +\r\n");
      out.write("   \t\t    dSetName + \"\\\" alt=\\\"Buffer Pool and Shared Pool\\\">\";\r\n");
      out.write("   \t      document.getElementById(\"pic3Div\").innerHTML=\r\n");
      out.write("   \t    \t\"<h4>Large Pool and Streams Pool</h4><br>\"+  \r\n");
      out.write("   \t\t    \"<img class=\\\"imgclss\\\" id=\\\"Large_Streams_Memory\" + \"\\\" src=\\\"GetGraph?memory=true&ht=300&large=true&streams=true&dSetName=\" +\r\n");
      out.write("   \t\t    dSetName + \"\\\" alt=\\\"Large Pool and Streams Pool\\\">\";\r\n");
      out.write("   \t      document.getElementById(\"pic4Div\").innerHTML=\r\n");
      out.write("   \t    \t\"<h4>Fixed Pool, Log Buffer and JAVA Pool</h4><br>\"+  \r\n");
      out.write("   \t\t    \"<img class=\\\"imgclss\\\" id=\\\"Fixed_Log_Java_Memory\" + \"\\\" src=\\\"GetGraph?memory=true&ht=300&fixed=true&log=true&java=true&dSetName=\" +\r\n");
      out.write("   \t\t    dSetName + \"\\\" alt=\\\"Fixed Pool, Log Buffer and JAVA Pool\\\">\";\r\n");
      out.write("\t      $('#tm').val(month + \"-\" +  day + \"-\" + year + \"_\" + hours + \"-\" + minutes);\r\n");
      out.write("\t      $(\".imgclss\").dblclick( function() {\r\n");
      out.write("\t\t    var fnm = \"");
      out.print(conNm);
      out.write("_\"\t+ this.id + \"_\" + month + \"-\" + day+ \"-\" + year + \"_\" + hours \r\n");
      out.write("\t\t      + \"-\" + minutes + \".png\";\r\n");
      out.write("\t\t    window.location.href = this.src\t\t+ \"&save=\"\t+ fnm;\r\n");
      out.write("\t      });\r\n");
      out.write("\t\t  var z = -1;\r\n");
      out.write("\t\t  $(\"thead td\").each( function ( i ) {\r\n");
      out.write("\t\t\tvar fircol = 0; //starts with 0, skipping first one \r\n");
      out.write("\t\t\tif(this.id.match(/^gra1_/) &&\r\n");
      out.write("\t\t\t\t\tthis.innerHTML.length > 0){\r\n");
      out.write("\t\t\t\tif ( z == -1 ){\r\n");
      out.write("\t\t\t\t\tz = i + fircol;\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t\tvar sel = fnCreateSelect( oTable.fnGetColumnData(i - z) );\r\n");
      out.write("\t\t\t\tif (sel.length == 0){\r\n");
      out.write("\t\t\t\t\tsel = '<b></b>';\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t\tthis.innerHTML = sel;\r\n");
      out.write("\t\t\t\t$('select', this).change( function () {\r\n");
      out.write("\t\t\t\t\toTable.fnFilter( $(this).val(), i - z );\r\n");
      out.write("\t\t\t\t} );\r\n");
      out.write("\t\t\t}\r\n");
      out.write("\t\t  } );\r\n");
      out.write("\t      oTable.fnAdjustColumnSizing();\r\n");
      out.write("\t      oTable.fnSetFilteringDelay();\r\n");
      out.write("\t\t} );\r\n");
      out.write("\t};\r\n");
      out.write("});\r\n");
      out.write("\r\n");
      out.write("/* ]]> */\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\t<DIV ID=\"titl\"><H1>Memory in MG for ");
      out.print(conNm);
      out.write(" going back ");
      out.print(days);
      out.write(" days</H1></DIV>\r\n");
      out.write("\t<FORM id=eventform>\r\n");
      out.write("\t\t<input type=\"hidden\" name=\"connm\" value=\"");
      out.print(conNm);
      out.write("\">\r\n");
      out.write("\t\t<input type=\"hidden\" name=\"tm\" id=\"tm\" value=\"jnk\"> <b>Days</b><input\r\n");
      out.write("\t\t\ttype=\"text\" size=\"4\" maxlength=\"4\" name=\"days\" id=\"days\"\r\n");
      out.write("\t\t\tvalue=\"");
      out.print(days);
      out.write("\"> <input name=\"getChart\" id=\"getChart\"\r\n");
      out.write("\t\t\ttype=\"button\" value=\"Get Chart\"><BR>\r\n");
      out.write("\t<DIV ID=\"pic1Div\"></DIV><BR>\r\n");
      out.write("\t<DIV ID=\"pic2Div\"></DIV><BR>\r\n");
      out.write("\t<DIV ID=\"pic3Div\"></DIV><BR>\r\n");
      out.write("\t<DIV ID=\"pic4Div\"></DIV><BR>\r\n");
      out.write("\t\t<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" class=\"display\"\r\n");
      out.write("\t\t\tid=\"gra1\">\r\n");
      out.write("\t\t\t<thead>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_1\"><b></b></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_2\"></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_3\"></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_4\"></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_5\"></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_6\"></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_7\"></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_8\"></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_9\"></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_10\"></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_11\"></td>\r\n");
      out.write("\t\t\t\t\t<td id=\"gra1_12\"></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<th>Instance</th>\r\n");
      out.write("\t\t\t\t\t<th>Date</th>\r\n");
      out.write("\t\t\t\t\t<th>Fixed SGA</th>\r\n");
      out.write("\t\t\t\t\t<th>Log Buffer</th>\r\n");
      out.write("\t\t\t\t\t<th>Java Pool</th>\r\n");
      out.write("\t\t\t\t\t<th>Large Pool</th>\r\n");
      out.write("\t\t\t\t\t<th>Streams Pool</th>\r\n");
      out.write("\t\t\t\t\t<th>Buffer Cache</th>\r\n");
      out.write("\t\t\t\t\t<th>Shared Pool</th>\r\n");
      out.write("\t\t\t\t\t<th>SGA</th>\r\n");
      out.write("\t\t\t\t\t<th>PGA</th>\r\n");
      out.write("\t\t\t\t\t<th>Total Memory</th>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t</thead>\r\n");
      out.write("\t\t\t<tbody></tbody>\r\n");
      out.write("\t\t</table>\r\n");
      out.write("\t\t<br> \r\n");
      out.write("\t</FORM> <BR>\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
