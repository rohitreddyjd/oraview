package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import sqlGraph.DbSQL;
import sqlGraph.Connect;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import sqlGraph.ConfigDbSQL;

public final class DisplaySideBar_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");

	if(!sqlGraph.Usr.validate(
		    (request.getHeader("STANDARDID") == null) ? 
	    		request.getRemoteUser(): 
		    	request.getHeader("STANDARDID"),
		"DBA")){
	response.sendRedirect("NoAccess.html");
	}
	String conNm = (request.getParameter("connm") == null) ? ConfigDbSQL.getDefault("FirstDB") : request.getParameter("connm");
	String srchtp = (request.getParameter("search") == null) ? DbSQL
	.getString("default_getSQLID") : request
	.getParameter("search");
	String disptp = (request.getParameter("disptp") == null) ? DbSQL
	.getString("default_display") : request
	.getParameter("disptp");
	if(conNm == null){
		disptp = "updcon";
	}
	String mansql = (request.getParameter("mansql") == null) ? "" : request
	.getParameter("mansql");
	String mantxt = (request.getParameter("mantxt") == null) ? "" : request
	.getParameter("mantxt");
	boolean isFrame = (request.getParameter("frmless") == null||
			request.getParameter("frmless").equalsIgnoreCase("false"));
	if (!isFrame) disptp = "none";
	System.err.println(disptp);
	int hours = 0;
	try{
		hours = Integer.parseInt(request.getParameter("hours"));
	} catch (Exception e){
		hours = 0;
	}
	String lnk = null;

      out.write("\r\n");
      out.write("<HTML>\r\n");
      out.write("<HEAD>\r\n");
      out.write("<LINK REL=\"shortcut icon\" HREF=\"icons/favicon.ico\" />\r\n");
      out.write("<LINK REL=\"icon\" TYPE=\"image/gif\" HREF=\"icons/favicon.ico\" />\r\n");
      out.write("<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<TITLE>Menu</TITLE>\r\n");
      out.write("\r\n");
      out.write("<META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\" />\r\n");
      out.write("\r\n");
      out.write("<STYLE TYPE=\"text/css\" TITLE=\"currentStyle\">\r\n");
      out.write("@import \"css/style.css\";\r\n");
      out.write("\r\n");
      out.write("@import \"css/demo_table.css\";\r\n");
      out.write("</STYLE>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\" SRC=\"js/jquery.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\"\r\n");
      out.write("\tSRC=\"js/jquery.dataTables.min.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\"\r\n");
      out.write("\tSRC=\"js/jquery.dataTables.add.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\"\r\n");
      out.write("\tSRC=\"js/KeyTable.min.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\">\r\n");
      out.write("/* <![CDATA[ */\r\n");
      out.write("$(document).ready(function() {\r\n");
      out.write("\r\n");
      out.write("\tvar oTable = $('#graph').dataTable({\r\n");
      out.write("\t\t\"bProcessing\" : true,\r\n");
      out.write("\t\t\"sAjaxSource\" : \"GetList?connm=");
      out.print(conNm);
      out.write("&tp=topsql&sqltp=\"+$(\"#search\").val(),  \r\n");
      out.write("\t\t\"bDeferRender\" : true,\r\n");
      out.write("\t\t\"sScrollY\" : \"150px\",\r\n");
      out.write("\t\t\"sDom\": 'lrt',\r\n");
      out.write("\t\t\"bPaginate\" : false,\r\n");
      out.write("\t\t\"bInfo\": false, \r\n");
      out.write("\t\t\"bFilter\": false,\r\n");
      out.write("\t\t\"aoColumns\": [null, { \"sType\": \"numeric\" } ],  \r\n");
      out.write("\t\t\"aaSorting\": [[ 1, \"desc\" ]], \r\n");
      out.write("\t\tfnInitComplete: function () {\r\n");
      out.write("\t\t\t$('#graph tr').click( function() {\r\n");
      out.write("\t            var optlist = oTable.$('tr.row_selected');\r\n");
      out.write("\t            var drawit = true;\r\n");
      out.write("\t\t\t    for(i = 0; i < optlist.length; i++)\r\n");
      out.write("\t\t\t    {\r\n");
      out.write("\t\t\t      drawit = false;\r\n");
      out.write("\t\t\t      if(!($(this).attr('class').match(/row_selected/))){\r\n");
      out.write("\t\t\t        $(optlist[i]).toggleClass('row_selected');\r\n");
      out.write("\t\t\t        drawit = true;\r\n");
      out.write("\t\t          }\r\n");
      out.write("\t\t\t    }\r\n");
      out.write("\t\t\t\t$(this).toggleClass('row_selected');\r\n");
      out.write("\t\t\t    if(drawit) {\r\n");
      out.write("\t\t\t      select_sqlid();\r\n");
      out.write("\t        \t}\r\n");
      out.write("\t\t   \t} );\r\n");
      out.write("\t\t    oTable.fnAdjustColumnSizing(); \t\r\n");
      out.write("\t\t}\r\n");
      out.write("\t});\r\n");
      out.write("\t\r\n");
      out.write("\tvar keys = new KeyTable( {\r\n");
      out.write("\t\t\"table\": document.getElementById('graph'),\r\n");
      out.write("\t\t\"datatable\": oTable,\r\n");
      out.write("\t\t\"jtab\": true\r\n");
      out.write("\t} );\r\n");
      out.write("\t\r\n");
      out.write("\tkeys.event.action( null, null, function( nNode, x, y ) {\r\n");
      out.write("\t    var rw = $(nNode).closest('tr');       \r\n");
      out.write("\t    var optlist = oTable.$('tr.row_selected');\r\n");
      out.write("\t    var drawit = true;\r\n");
      out.write("\t    for(i = 0; i < optlist.length; i++)\r\n");
      out.write("\t    {\r\n");
      out.write("\t      drawit = false;\r\n");
      out.write("\t      if(!($(rw).attr('class').match(/row_selected/))){\r\n");
      out.write("\t        $(optlist[i]).toggleClass('row_selected');\r\n");
      out.write("\t        drawit = true;\r\n");
      out.write("\t      }\r\n");
      out.write("\t    }\r\n");
      out.write("\t\t$(rw).toggleClass('row_selected');\r\n");
      out.write("\t    if(drawit) {\r\n");
      out.write("\t      select_sqlid();\r\n");
      out.write("\t    }\r\n");
      out.write("\t} ); \r\n");
      out.write("\t\r\n");
      out.write("\t\r\n");
      out.write("\r\n");
      out.write("    function select_sqlid(){\r\n");
      out.write("    \tvar optlist = oTable.$('tr.row_selected');\r\n");
      out.write("    \tif(optlist.length < 1){\r\n");
      out.write("    \t\talert(\"Please make a selection first.\");\r\n");
      out.write("    \t} else {\r\n");
      out.write("    \t  $(\"#mansql\").val(optlist[0].childNodes[0].innerHTML);\r\n");
      out.write("          parent.Display.location.href='./DisplayGraphSQL.jsp?connm=");
      out.print(conNm);
      out.write("' + \r\n");
      out.write("            '&sqlonly=true&sqlid='+optlist[0].childNodes[0].innerHTML;\t\r\n");
      out.write("        }\r\n");
      out.write("    };\r\n");
      out.write("    \r\n");
      out.write("    function refresh_list(){\r\n");
      out.write("\t\toTable.fnFilterClear(); \r\n");
      out.write("\t\toTable.fnReloadAjax( \"GetList?connm=");
      out.print(conNm);
      out.write("&tp=topsql&sqltp=\"+$(\"#search\").val() , function(){\r\n");
      out.write("\t\t\t$('#graph tr').click( function() {\r\n");
      out.write("\t            var optlist = oTable.$('tr.row_selected');\r\n");
      out.write("\t            var drawit = true;\r\n");
      out.write("\t\t\t    for(i = 0; i < optlist.length; i++)\r\n");
      out.write("\t\t\t    {\r\n");
      out.write("\t\t\t      drawit = false;\r\n");
      out.write("\t\t\t      if(!($(this).attr('class').match(/row_selected/))){\r\n");
      out.write("\t\t\t        $(optlist[i]).toggleClass('row_selected');\r\n");
      out.write("\t\t\t        drawit = true;\r\n");
      out.write("\t\t          }\r\n");
      out.write("\t\t\t    }\r\n");
      out.write("\t\t\t\t$(this).toggleClass('row_selected');\r\n");
      out.write("\t\t\t    if(drawit) {\r\n");
      out.write("\t\t\t      select_sqlid();\r\n");
      out.write("\t        \t}\r\n");
      out.write("\t\t   \t} );\r\n");
      out.write("\t\t});\r\n");
      out.write("    };\r\n");
      out.write("\r\n");
      out.write("    $(\"#search\").change(function(){\r\n");
      out.write("          refresh_list();\r\n");
      out.write("\t});\r\n");
      out.write("    \r\n");
      out.write("} );\r\n");
      out.write("/* ]]> */\r\n");
      out.write("</SCRIPT>\r\n");
      out.write("</HEAD>\r\n");
      out.write("<BODY>\r\n");
      out.write("\t<H3>SQL Graph</H3>\r\n");
      out.write("\t");

		String 	mystr1 = "SQLGraph";
	String mystr2 = " ";
	String mystr3 = " ";
	if(!isFrame){ 
		mystr1 = "DisplaySideBar";
		mystr2 = "&frmless=true";
		mystr3 = "<input type=\"hidden\" name = \"frmless\" value=\"true\">";
	}
	
      out.write("\r\n");
      out.write("\t<FORM\r\n");
      out.write("\t\tACTION=\"./");
      out.print(mystr1);
      out.write(".jsp?connm=");
      out.print(conNm);
      out.write("&amp;search=");
      out.print(srchtp);
      out.print(mystr2);
      out.write("\"\r\n");
      out.write("\t\tTARGET=\"_top\">\r\n");
      out.write("\t\t<B>Database</B>");
      out.print(mystr3);
      out.write("\r\n");
      out.write("\t\t<SELECT NAME=\"connm\" id=\"connm\" STYLE=\"width: 200px\" ONCHANGE=\"this.form.submit();\">\r\n");
      out.write("\t\t\t");

				List<String> conlst = ConfigDbSQL.getDbs();
					for (int list_ptr = 0; list_ptr < conlst.size(); list_ptr++) {
			
      out.write("\r\n");
      out.write("\t\t\t<OPTION VALUE=\"");
      out.print(conlst.get(list_ptr));
      out.write("\"\r\n");
      out.write("\t\t\t\t");
      out.print(conlst.get(list_ptr).equalsIgnoreCase(conNm) ? "SELECTED"
						: "");
      out.write('>');
      out.print(conlst.get(list_ptr));
      out.write("</OPTION>\r\n");
      out.write("\t\t\t");

		}
	
      out.write("\r\n");
      out.write("\t\t</SELECT><BR>\r\n");
      out.write("\t\t");
if(isFrame){ 
      out.write("<INPUT TYPE=\"button\" VALUE=\"Update Connections\"\r\n");
      out.write("\t\t\tONCLICK=\"parent.Display.location.href='./UpdateConnections.jsp?connm=");
      out.print(conNm);
      out.write("' \">\r\n");
      out.write("\t\t");
} else { 
      out.write("<INPUT TYPE=\"button\" VALUE=\"Update Connections\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./UpdateConnections.jsp?connm=");
      out.print(conNm);
      out.write("')\">\r\n");
      out.write("\t\t");
}
	if (disptp.equalsIgnoreCase("updcon")){
	      lnk="parent.Display.location.href='./UpdateConnections.jsp?connm=" 
				  +conNm+"'";
	}
	if (disptp.equalsIgnoreCase("last4addm")){
		  lnk="parent.Display.location.href='./DisplayLst4ADDM.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("showsessions")){
		  lnk="parent.Display.location.href='./DisplaySessions.jsp?connm=" 
				  +conNm+"'";
	}
	if (disptp.equalsIgnoreCase("showalllocks")){
		  lnk="parent.Display.location.href='./DisplayAllLocks.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("showblocklocks")){
		  lnk="parent.Display.location.href='./DisplayBlockLocks.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("showpga")){
		  lnk="parent.Display.location.href='./DisplayPGA.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("showlongops")){
		  lnk="parent.Display.location.href='./DisplayLongOps.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("showdbgraph1")){
		  lnk="parent.Display.location.href='./DisplayGraphDb.jsp?connm=" 
				  +conNm+"&days=1'";
	}	
	if (disptp.equalsIgnoreCase("showmemory")){
		  lnk="parent.Display.location.href='./DisplayMemory.jsp?connm=" 
				  +conNm+"&days=1'";
	}	
	if (disptp.equalsIgnoreCase("showdbgraph7")){
		  lnk="parent.Display.location.href='./DisplayGraphDb.jsp?connm=" 
				  +conNm+"&days=7'";
	}	
	if (disptp.equalsIgnoreCase("planchange")){
		  lnk="parent.Display.location.href='./DisplayPlanChange.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("displaylog")){
		  lnk="parent.Display.location.href='./DisplayLog.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("profile")){
		  lnk="parent.Display.location.href='./DisplayProfile.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("monitor")){
		  lnk="parent.Display.location.href='./DisplaySQLMonitorList.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("tune")){
		  lnk="parent.Display.location.href='./DisplayTuning.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("dbparam")){
		  lnk="parent.Display.location.href='./DisplayDBParam.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("dbinfo")){
		  lnk="parent.Display.location.href='./DisplayDBInfo.jsp?connm=" 
				  +conNm+"'";
	}	
    if (disptp.equalsIgnoreCase("showaddm")){
	  lnk="parent.Display.location.href='./DisplayADDM.jsp?connm=" 
			  +conNm+"'";
	 }
    if (disptp.equalsIgnoreCase("showawr")){
	  lnk="parent.Display.location.href='./DisplayAWR.jsp?connm=" 
			  +conNm+"'";
	 }
	if (disptp.equalsIgnoreCase("syssum")){
		  lnk="parent.Display.location.href='./DisplaySysSum.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("sysevt")){
		  lnk="parent.Display.location.href='./DisplaySysEvent.jsp?connm=" 
				  +conNm+"'";
	}
	if (disptp.equalsIgnoreCase("topsysevt")){
		  lnk="parent.Display.location.href='./DisplayTopSysEvent.jsp?connm=" 
				  +conNm+"'";
	}	
	if (disptp.equalsIgnoreCase("rmanstat")){
		  lnk="parent.Display.location.href='./DisplayRMANStatus.jsp?connm=" 
				  +conNm+"'";
	}	

      out.write("\r\n");
      out.write("\t\t<HR>\r\n");
      out.write("\t\t");
if(isFrame){
      out.write("\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayAWR.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"Display\">AWR</A>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayAWR.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayADDM.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"Display\">ADDM</A>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayADDM.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplaySessions.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">Sessions</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplaySessions.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayAllLocks.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">All Locks</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayAllLocks.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayBlockLocks.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">Blocking Locks</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayBlockLocks.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayPGA.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"Display\">PGA</A>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayPGA.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayLongOps.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">Long Ops</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayLongOps.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayDBParam.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">DB Parameters</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayDBParam.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayDBInfo.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">DB Information</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayDBInfo.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayDBSize.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">DB Size</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayDBSize.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayGraphDb.jsp?connm=");
      out.print(conNm);
      out.write("&amp;days=1\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">DB Graphs</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayGraphDb.jsp?connm=");
      out.print(conNm);
      out.write("&amp;days=1\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayMemory.jsp?connm=");
      out.print(conNm);
      out.write("&amp;days=1\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">Memory</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayMemory.jsp?connm=");
      out.print(conNm);
      out.write("&amp;days=1\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplaySysSum.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">DB System Summary</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplaySysSum.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplaySysEvent.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">DB System Events</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplaySysEvent.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayTopSysEvent.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">DB Top System Events</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayTopSysEvent.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayRMANStatus.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">RMAN Status</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayRMANStatus.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayLog.jsp?connm=");
      out.print(conNm);
      out.write("\" \r\n");
      out.write("\t\t\t    TARGET=\"Display\">DB\tLog</A> <A \r\n");
      out.write("\t\t\t    HREF=\"./DisplayLog.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayPlanChange.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">SQL Plan Change</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayPlanChange.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayProfile.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">SQL Profile</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayProfile.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplaySQLMonitorList.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">SQL Monitor</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplaySQLMonitorList.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayTuning.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"Display\">SQL Tuning Advisor</A> <A\r\n");
      out.write("\t\t\t\tHREF=\"./DisplayTuning.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">Window</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t");
}else{
      out.write("\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayAWR.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">AWR</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayADDM.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">ADDM</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplaySessions.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">Sessions</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t");
      out.write("\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayAllLocks.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">All Locks</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayBlockLocks.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">Blocking Locks</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayPGA.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">PGA</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayLongOps.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">Long Ops</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayDBParam.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">DB Parameters</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayDBInfo.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">DB Information</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayDBSize.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">DB Size</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayGraphDb.jsp?connm=");
      out.print(conNm);
      out.write("&amp;days=1\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">DB Graphs</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayMemory.jsp?connm=");
      out.print(conNm);
      out.write("&amp;days=1\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">Memory</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplaySysSum.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">DB\r\n");
      out.write("\t\t\t\tSystem Summary</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplaySysEvent.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">DB System Events</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayTopSysEvent.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">DB Top System Events</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayRMANStatus.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">RMAN Status</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayLog.jsp?connm=");
      out.print(conNm);
      out.write("\" TARGET=\"_blank\">DB\r\n");
      out.write("\t\t\t\tLog</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayPlanChange.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">SQL Plan Change</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayProfile.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">SQL Profile</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplaySQLMonitorList.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">SQL Monitor</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t<NOBR>\r\n");
      out.write("\t\t\t<A HREF=\"./DisplayTuning.jsp?connm=");
      out.print(conNm);
      out.write("\"\r\n");
      out.write("\t\t\t\tTARGET=\"_blank\">SQL Tuning Advisor</A>\r\n");
      out.write("\t\t</NOBR>\r\n");
      out.write("\t\t");
}
      out.write("\r\n");
      out.write("\t\t<HR>\r\n");
      out.write("\t\t<B>Search </B> <SELECT NAME=\"search\" ID=\"search\" STYLE=\"width: 150px\" >\r\n");
      out.write("\t\t\t");

		List<String> srchlst = DbSQL.getMatchingString("getSQLID_");
		for (int list_ptr = 0; list_ptr < srchlst.size(); list_ptr++) {
	
      out.write("\r\n");
      out.write("\t\t\t<OPTION VALUE=\"");
      out.print(srchlst.get(list_ptr));
      out.write("\"\r\n");
      out.write("\t\t\t\t");
      out.print(srchlst.get(list_ptr).equalsIgnoreCase(srchtp) ? "SELECTED"
						: "");
      out.write('>');
      out.print(srchlst.get(list_ptr).substring(9));
      out.write("</OPTION>\r\n");
      out.write("\t\t\t");

		}
	
      out.write("\r\n");
      out.write("\t\t</SELECT><BR>\r\n");
      out.write("\t\t<DIV>\r\n");
      out.write("\t\t\t<TABLE CELLPADDING=\"0\" CELLSPACING=\"0\" BORDER=\"0\" CLASS=\"display\"\r\n");
      out.write("\t\t\t\tID=\"graph\">\r\n");
      out.write("\t\t\t\t<THEAD>\r\n");
      out.write("\t\t\t\t\t<TR>\r\n");
      out.write("\t\t\t\t\t\t<TH>SQL ID</TH>\r\n");
      out.write("\t\t\t\t\t\t<TH>Rank</TH>\r\n");
      out.write("\t\t\t\t\t</TR>\r\n");
      out.write("\t\t\t\t</THEAD>\r\n");
      out.write("\t\t\t\t<TBODY></TBODY>\r\n");
      out.write("\t\t\t</TABLE>\r\n");
      out.write("\t\t</DIV>\r\n");
      out.write("\t\t<BR> <B>SQL ID</B><INPUT TYPE=\"text\" SIZE=\"13\" MAXLENGTH=\"13\"\r\n");
      out.write("\t\t\tNAME=\"mansql\" ID=\"mansql\" VALUE=\"");
      out.print(mansql);
      out.write("\"><BR>\r\n");
      out.write("\t\t<B>Group Hrs</B><INPUT TYPE=\"text\" SIZE=\"2\" MAXLENGTH=\"2\"\r\n");
      out.write("\t\t\tNAME=\"hours\" ID=\"hours\" VALUE=\"");
      out.print(hours);
      out.write("\"><BR>\r\n");
      out.write("\t\t");
if(isFrame){
      out.write("\r\n");
      out.write("\t\t<INPUT TYPE=\"button\" VALUE=\"Detail\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./DisplayGraphSQL.jsp?connm=");
      out.print(conNm);
      out.write("&amp;sqlid='+mansql.value+'&amp;hours='+hours.value)\">\r\n");
      out.write("\r\n");
      out.write("\t\t<INPUT TYPE=\"button\" VALUE=\"CSV\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./GetSQLCSV?connm=");
      out.print(conNm);
      out.write("&amp;sqlid='+mansql.value+'&amp;hours='+hours.value) \">\r\n");
      out.write("\t\t<INPUT TYPE=\"button\" VALUE=\"Chart\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./DisplayGraphSQL.jsp?connm=");
      out.print(conNm);
      out.write("&amp;chartonly=true&amp;sqlid='+mansql.value+'&amp;hours='+hours.value) \">\r\n");
      out.write("\t\t");
}else{
      out.write("\r\n");
      out.write("\t\t<INPUT TYPE=\"button\" VALUE=\"Detail\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./DisplayGraphSQL.jsp?connm=");
      out.print(conNm);
      out.write("&amp;sqlid='+mansql.value+'&amp;hours='+hours.value) \">\r\n");
      out.write("\t\t<INPUT TYPE=\"button\" VALUE=\"SQL CSV\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./GetSQLCSV?connm=");
      out.print(conNm);
      out.write("&amp;sqlid='+mansql.value+'&amp;hours='+hours.value) \">\r\n");
      out.write("\t\t<INPUT TYPE=\"button\" VALUE=\"Chart\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./DisplayGraphSQL.jsp?connm=");
      out.print(conNm);
      out.write("&amp;chartonly=true&amp;sqlid='+mansql.value+'&amp;hours='+hours.value) \">\r\n");
      out.write("\t\t");
}
      out.write("\r\n");
      out.write("\t\t<HR>\r\n");
      out.write("\t\t<B>SQL TEXT</B><BR>\r\n");
      out.write("\t\t<TEXTAREA COLS=\"35\" ROWS=\"10\" NAME=\"mantxt\">");
      out.print(mantxt);
      out.write("</TEXTAREA>\r\n");
      out.write("\t\t<BR>\r\n");
      out.write("\t\t");
if(isFrame){
      out.write("\r\n");
      out.write("\t\t<INPUT TYPE=\"button\" VALUE=\"CSV\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./GetSQLCSV?connm=");
      out.print(conNm);
      out.write("&amp;sqltext='+encodeURIComponent(mantxt.value)+'&amp;hours='+hours.value) \">\r\n");
      out.write("\t\t<INPUT TYPE=\"button\" VALUE=\"Chart\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./DisplayGraphSQL.jsp?connm=");
      out.print(conNm);
      out.write("&amp;sqltext='+encodeURIComponent(mantxt.value)+'&amp;hours='+hours.value) \">\r\n");
      out.write("\t\t");
}else{
      out.write("\r\n");
      out.write("\t\t<INPUT TYPE=\"button\" VALUE=\"SQL CSV\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./GetSQLCSV?connm=");
      out.print(conNm);
      out.write("&amp;sqltext='+encodeURIComponent(mantxt.value)+'&amp;hours='+hours.value) \">\r\n");
      out.write("\t\t<INPUT TYPE=\"button\" VALUE=\"Chart\"\r\n");
      out.write("\t\t\tONCLICK=\"window.open('./DisplayGraphSQL.jsp?connm=");
      out.print(conNm);
      out.write("&amp;sqltext='+encodeURIComponent(mantxt.value)+'&amp;hours='+hours.value) \">\r\n");
      out.write("\t\t");
}
      out.write("\r\n");
      out.write("\t\t<HR>\r\n");
      out.write("\t</FORM>\r\n");

	String hst = request.getHeader("host");
	if(hst.indexOf("abbprod") > -1){ 
      out.write("\r\n");
      out.write("\t<a href=\"https://ssologin.bankone.net/siteminderagent/ssologout/Logout.html\"  TARGET=\"_top\">SSO Logout</a>\r\n");
  } else if(hst.indexOf("abbtest") > -1) { 
      out.write("\r\n");
      out.write("\t<a href=\"https://ssologin-qa.bankone.net/siteminderagent/ssologout/Logout.html\" TARGET=\"_top\">SSO Logout</a>\r\n");
  } else if(hst.indexOf("vsin10p5591") > -1) { 
      out.write("\r\n");
      out.write("\t<a href=\"https://smlogin-dev.bankone.net/siteminderagent/ssologout/Logout.html\" TARGET=\"_top\">SSO Logout</a>\r\n");
  }

      out.write("\r\n");
      out.write("\t<H6>Written by John R. Turner</H6>\r\n");
      out.write("\t<SCRIPT TYPE=\"text/javascript\">");
      out.print(lnk);
      out.write("</SCRIPT>\r\n");
      out.write("</BODY>\r\n");
      out.write("</HTML>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
