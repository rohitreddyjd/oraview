package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import sqlGraph.DbSQL;
import sqlGraph.Connect;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import sqlGraph.Encrypt;
import sqlGraph.ConfigDbSQL;

public final class UpdateConnections_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("\t");

	if(!sqlGraph.Usr.validate(
		    (request.getHeader("STANDARDID") == null) ? 
	    		request.getRemoteUser(): 
		    	request.getHeader("STANDARDID"),
			"DBA")){
		response.sendRedirect("NoAccess.html");
	}
	String conNm = (request.getParameter("connm") == null) ? 
			ConfigDbSQL.getDefault("FirstDB") : 
			request.getParameter("connm").toUpperCase();
	String oconnm = request.getParameter("oconnm");
	String constr = request.getParameter("constr");
	String username = request.getParameter("username");
	String password = request.getParameter("password");
	String passExp = request.getParameter("passexp");
	if(password != null){
		password = password.startsWith("ENC:")?Encrypt.decrypt(password.substring(4)):password;
	}
	//default String dusername = request.getParameter("dusername");
	//default String dpassword = request.getParameter("dpassword");
	String[] selgroups = request.getParameterValues("selgroups");
	List<String> groups = new ArrayList<String>();
	if(selgroups != null){
		for(int w = 0; w < selgroups.length; w++){
			groups.add(selgroups[w]);
		}
	}
	String cmd = request.getParameter("cmd");
	String status = new String("");
	if (cmd != null) {
		boolean tst = true;
		if (cmd.equalsIgnoreCase("update")) {
			if(!oconnm.matches(conNm)){
				tst = ConfigDbSQL.updateDbName(oconnm, conNm);
			}
			if(tst){
				tst = ConfigDbSQL.updateDb(conNm,constr, username, password, passExp)&&
						ConfigDbSQL.setConGroupsForDb(groups, conNm);
			}
			status += "Updated " + conNm + "<br>Saved " + tst;
		}
		if (cmd.equalsIgnoreCase("updateTest")) {
			if(!oconnm.matches(conNm)){
				tst = ConfigDbSQL.updateDbName(oconnm, conNm);
			}
			if(tst){
				tst = ConfigDbSQL.updateDb(conNm,constr, username, password, passExp)&&
						ConfigDbSQL.setConGroupsForDb(groups, conNm);
			}
			status += "Updated " + conNm + "<br>Saved " + tst + 
			          "<br>Tested " + DbSQL.testConnectStr(conNm);
		}
		if (cmd.equalsIgnoreCase("delete")) {
			tst = ConfigDbSQL.deleteDb(oconnm);
			status += "Deleted " + oconnm + "<br>Saved " + tst;
			conNm = ConfigDbSQL.getDefault("FirstDB");
		}
		if (cmd.equalsIgnoreCase("add")) {
			tst = ConfigDbSQL.insertDb(conNm, constr, username,
					password, passExp) &&
					ConfigDbSQL.setConGroupsForDb(groups, conNm);
			status += "Added " + conNm + "<br>Saved " + tst;
			String getDef = ConfigDbSQL.getDefault("FirstDB");
			if(tst && (getDef == null || getDef.length() == 0)){
				tst = ConfigDbSQL.setDefault("FirstDB",conNm);
				status += "Updated as Default Connection<br>Saved " + tst
				+ "<br>Tested " + DbSQL.testConnectStr(conNm);
			}
		}
		/*		
		if (cmd.equalsIgnoreCase("defaults")) {
			tst = ConfigDbSQL.setDefault("DefPass",dpassword) &&
				ConfigDbSQL.setDefault("DefUser",dusername);
			status += "Updated Default Username and Password<br>" + "Saved " + tst;
		}
		*/
		if (cmd.equalsIgnoreCase("defaultcon")) {
			tst = ConfigDbSQL.setDefault("FirstDB",conNm);
			status += "Updated Default Connection<br>Saved " + tst;
		}
	}

      out.write("\t\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<link rel=\"shortcut icon\" href=\"icons/favicon.ico\" />\r\n");
      out.write("<link rel=\"icon\" type=\"image/gif\" href=\"icons/favicon.ico\" />\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Update Database Connection Strings</title>\r\n");
      out.write("<meta http-equiv=\"Pragma\" content=\"no-cache\" />\r\n");
      out.write("<style type=\"text/css\" title=\"currentStyle\">\r\n");
      out.write("@import \"css/style.css\";\r\n");
      out.write("@import \"css/demo_table.css\";\r\n");
      out.write(".tsmsselect {\r\n");
      out.write("\twidth: 40%;\r\n");
      out.write("\tfloat: left;\r\n");
      out.write("}\r\n");
      out.write(".tsmsselect select {\r\n");
      out.write("\twidth: 80%;\r\n");
      out.write("}\r\n");
      out.write(".tsmsoptions {\r\n");
      out.write("\twidth: 20%;\r\n");
      out.write("\tfloat: left;\r\n");
      out.write("}\r\n");
      out.write(".tsmsoptions p {\r\n");
      out.write("\tmargin: 2px;\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("\tfont-size: larger;\r\n");
      out.write("\tcursor: pointer;\r\n");
      out.write("}\r\n");
      out.write(".tsmsoptions p:hover {\r\n");
      out.write("\tcolor: White;\r\n");
      out.write("\tbackground-color: Silver;\r\n");
      out.write("}\r\n");
      out.write("</style>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\"\r\n");
      out.write("\tsrc=\"js/jquery.dataTables.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\"\r\n");
      out.write("\tsrc=\"js/jquery.dataTables.add.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\"\r\n");
      out.write("\tsrc=\"js/jquery.twosidedmultiselect.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("\r\n");
      out.write("/* <![CDATA[ */\r\n");
      out.write("\r\n");
      out.write("var randomnumber = Math.floor(Math.random()*1000001);\r\n");
      out.write("             \r\n");
      out.write("             \r\n");
      out.write("$(document).ready(function() {\r\n");
      out.write("\t\r\n");
      out.write("\t$.getJSON(\"GetList?connm=");
      out.print(conNm);
      out.write("&tp=conGroupsForConnection&rnd=\" + randomnumber++, null, function(data) {\r\n");
      out.write("\t\tvar optionsValues = '<SELECT name=\"selgroups\" id=\"seldt\" class=\"multiselect\"  multiple=\"true\" size=\"6\">';\r\n");
      out.write("\t\tvar firstone = true;         \r\n");
      out.write("  \t\t$.each(data, function(index1, obj) {\r\n");
      out.write("\t   \t\t$.each(obj, function(index2, object) {\r\n");
      out.write("\t \t\t  \tif(object[1] == 'TRUE') {\r\n");
      out.write("\t   \t\t    \toptionsValues += '<option value=\"' + object[0] + \r\n");
      out.write("\t   \t\t    \t       '\" SELECTED>' + object[0] + '</option>';\r\n");
      out.write("\t   \t\t    \tfirstone=false;\r\n");
      out.write("\t  \t\t  \t} else {\r\n");
      out.write("\t\t        \toptionsValues += '<option value=\"' + object[0] + '\">' + object[0] + '</option>';\r\n");
      out.write("\t\t      \t}           \r\n");
      out.write("\t   \t\t});\r\n");
      out.write("\t\t});\r\n");
      out.write("        optionsValues += '</select>';         \r\n");
      out.write("\t    var options = $('#seldt');\r\n");
      out.write("\t    options.replaceWith(optionsValues);\r\n");
      out.write("\t    $(\".multiselect\").twosidedmultiselect();\r\n");
      out.write("     }).error(function(){\r\n");
      out.write("         alert(\"Page Not Found Error during AJAX call.\");\r\n");
      out.write("     });\r\n");
      out.write("\r\n");
      out.write("\t$(\"#updCon\").click(function(){\r\n");
      out.write("\t\t$(\"#selgroups\").each(function(){\r\n");
      out.write("            $(\"#selgroups option\").attr(\"selected\",\"selected\"); });\r\n");
      out.write("\t\t/*alert(\"selgroups=\" + $(\"#selgroups\").serialize());*/\r\n");
      out.write("\t\tparent.Display.location.href='./UpdateConnections.jsp?'+\r\n");
      out.write("\t\t'cmd=update&oconnm=");
      out.print(conNm);
      out.write("' + \r\n");
      out.write("\t\t'&connm='+$('#nconnm').val()+\r\n");
      out.write("\t\t'&constr='+$('#constr').val() + \r\n");
      out.write("\t\t'&username='+$('#username').val()+\r\n");
      out.write("\t\t'&password='+ $('#password').val()+\r\n");
      out.write("\t\t'&passexp='+ $('#passexp').val()+'&'+\r\n");
      out.write("\t\t$(\"#selgroups\").serialize();\r\n");
      out.write("\t});\r\n");
      out.write("\r\n");
      out.write("\t$(\"#updTstCon\").click(function(){\r\n");
      out.write("\t\t$(\"#selgroups\").each(function(){\r\n");
      out.write("            $(\"#selgroups option\").attr(\"selected\",\"selected\"); });\r\n");
      out.write("\t\t/*alert(\"selgroups=\" + $(\"#selgroups\").serialize());*/\r\n");
      out.write("\t\tparent.Display.location.href='./UpdateConnections.jsp?'+\r\n");
      out.write("\t\t'cmd=updateTest&oconnm=");
      out.print(conNm);
      out.write("' + \r\n");
      out.write("\t\t'&connm='+$('#nconnm').val()+\r\n");
      out.write("\t\t'&constr='+$('#constr').val() + \r\n");
      out.write("\t\t'&username='+$('#username').val()+\r\n");
      out.write("\t\t'&password='+ $('#password').val()+\r\n");
      out.write("\t\t'&passexp='+ $('#passexp').val()+'&'+\r\n");
      out.write("\t\t$(\"#selgroups\").serialize();\r\n");
      out.write("\t});\r\n");
      out.write("\r\n");
      out.write("\t$(\"#delCon\").click(function(){\r\n");
      out.write("\t     parent.Display.location.href='./UpdateConnections.jsp?'+\r\n");
      out.write("\t\t'cmd=delete&oconnm=");
      out.print(conNm);
      out.write("';\r\n");
      out.write("\t});\r\n");
      out.write("\r\n");
      out.write("\t$(\"#addCon\").click(function(){\r\n");
      out.write("\t\t$(\"#selgroups\").each(function(){\r\n");
      out.write("            $(\"#selgroups option\").attr(\"selected\",\"selected\"); });\r\n");
      out.write("\t\t/*alert(\"selgroups=\" + $(\"#selgroups\").serialize());*/\r\n");
      out.write("\t\t parent.Display.location.href='./UpdateConnections.jsp?'+\r\n");
      out.write("\t\t\t'cmd=add&connm='+$('#nconnm').val()+\r\n");
      out.write("\t\t\t'&constr='+$('#constr').val() + \r\n");
      out.write("\t\t\t'&username='+$('#username').val()+\r\n");
      out.write("\t\t\t'&password='+ $('#password').val()+\r\n");
      out.write("\t\t\t'&passexp='+ $('#passexp').val()+'&'+\r\n");
      out.write("\t\t\t$(\"#selgroups\").serialize();\r\n");
      out.write("\t\t\t");
      out.write("\r\n");
      out.write("\t});\r\n");
      out.write("\t\t \r\n");
      out.write("\t$(\"#setDef\").click(function(){\r\n");
      out.write("\t\tparent.Display.location.href='./UpdateConnections.jsp?'+\r\n");
      out.write("\t\t\t'cmd=defaultcon&connm=");
      out.print(conNm);
      out.write("';\r\n");
      out.write("\t});\r\n");
      out.write("\t\r\n");
      out.write("\t\r\n");
      out.write("\t$(\"#updGrp\").click(function(){\r\n");
      out.write("\t\tparent.Display.location.href='./UpdateGroups.jsp';\r\n");
      out.write("\t});\r\n");
      out.write("\r\n");
      out.write("\t$(\"#updUsr\").click(function(){\r\n");
      out.write("\t\tparent.Display.location.href='./UpdateUsers.jsp';\r\n");
      out.write("\t});\r\n");
      out.write("\t\r\n");
      out.write("});        \r\n");
      out.write("\r\n");
      out.write("/* ]]> */\r\n");
      out.write("</script>\r\n");
      out.write("\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\t<center>\r\n");
      out.write("\t\t<h4>Connection</h4>\r\n");
      out.write("\t</center>\r\n");
	
	if(status.length()>0){

      out.write('\r');
      out.write('\n');
      out.write('	');
      out.print(status);
      out.write("\r\n");
      out.write("\t<hr>\r\n");
      out.write("\t");
}
      out.write("\r\n");
      out.write("\t<form>\r\n");
      out.write("\t\t<SELECT name=connm onchange=\"this.form.submit();\">\r\n");
      out.write("\t\t\t");

		List<String> conlst = ConfigDbSQL.getDbs();
		//DbSQL.getMatchingString("connectionstring_");
		for (int list_ptr = 0; list_ptr < conlst.size(); list_ptr++) {
	
      out.write("\r\n");
      out.write("\t\t\t<OPTION value=\"");
      out.print(conlst.get(list_ptr));
      out.write("\"\r\n");
      out.write("\t\t\t\t");
      out.print(conlst.get(list_ptr).equalsIgnoreCase(conNm) ? "selected"
						: "");
      out.write('>');
      out.print(conlst.get(list_ptr));
      out.write("</OPTION>\r\n");
      out.write("\t\t\t");

		}
	
      out.write("\r\n");
      out.write("\t\t</SELECT>\r\n");
      out.write("\t\t<hr>\r\n");
      out.write("\t\t");

	List<String> cBn = ConfigDbSQL.getDbInfo(conNm);	
	if (cBn == null|| cBn.size() < 1) {
		cBn = new ArrayList<String>(); 
		cBn.add("");
		cBn.add("");
		cBn.add("");
		cBn.add("");
		cBn.add("");
	}

      out.write("\r\n");
      out.write("\t\tConnection Name<input type=\"text\" size=\"20\" maxlength=\"20\"\r\n");
      out.write("\t\t\tname=\"nconnm\" id=\"nconnm\"\r\n");
      out.write("\t\t\tvalue=\"");
      out.print(conNm);
      out.write("\"> <br>\r\n");
      out.write("\t\tConnection String\r\n");
      out.write("\t\t<textarea cols=70 rows=10 name=\"constr\" id=\"constr\">");
      out.print(cBn.get(0));
      out.write("</textarea>\r\n");
      out.write("\t\t<br> User Name<input type=\"text\" size=\"32\" maxlength=\"32\"\r\n");
      out.write("\t\t\tname=\"username\" id=\"username\"\r\n");
      out.write("\t\t\tvalue=\"");
      out.print(cBn.get(1));
      out.write("\">\r\n");
      out.write("\t\tPassword<input type=\"password\" size=\"32\" maxlength=\"32\"\r\n");
      out.write("\t\t\tname=\"password\" id=\"password\"\r\n");
      out.write("\t\t\tvalue=\"");
      out.print(cBn.get(2).startsWith("ENC:")?cBn.get(2):"ENC:"+Encrypt.encrypt(cBn.get(2)));
      out.write("\">\r\n");
      out.write("\t\t<br>Last Day Password Works(yyyymmdd)<input type=\"text\" size=\"8\" maxlength=\"8\"\r\n");
      out.write("\t\t\tname=\"passexp\" id=\"passexp\"\r\n");
      out.write("\t\t\tvalue=\"");
      out.print(cBn.get(4));
      out.write("\">\t\r\n");
      out.write("\t\t<br>\r\n");
      out.write("\t\t<br>Database Groups\r\n");
      out.write("\t\t<br>\t\r\n");
      out.write("\t\t<SELECT name=\"selgroups\" id=\"seldt\" class=\"multiselect\"  multiple size=\"6\">\t</SELECT>\r\n");
      out.write("\t\t<br>\r\n");
      out.write("\t\t<center><BR><BR><BR><BR><BR>\r\n");
      out.write("\t\t <input type=\"button\" name=\"updCon\" id=\"updCon\" value=\"Update Current Connection\" >\r\n");
      out.write("\t\t <input type=\"button\" name=\"updTstCon\" id=\"updTstCon\" value=\"Update Test Current Connection\" >\r\n");
      out.write("\t\t <input type=\"button\" name=\"delCon\" id=\"delCon\" value=\"Delete Current Connection\" ><br>\r\n");
      out.write("\t\t <input type=\"button\" name=\"addCon\" id=\"addCon\" value=\"Add as a new Connection\">\r\n");
      out.write("\t\t <input type=\"button\" name=\"setDef\" id=\"setDef\" value=\"Set Current Connection as Default\"><br>\r\n");
      out.write("\t\t <input type=\"button\" name=\"updGrp\" id=\"updGrp\" value=\"Update Connection Groups\">\r\n");
      out.write("\t\t <input type=\"button\" name=\"updUsr\" id=\"updUsr\" value=\"Update Users\">\r\n");
      out.write("\t\t</center>\r\n");
      out.write("\t</form>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
