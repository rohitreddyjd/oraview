package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import sqlGraph.ConfigDbSQL;

public final class DisplayAllLocks_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");

	if(!sqlGraph.Usr.validate(
	    (request.getHeader("STANDARDID") == null) ? 
    		request.getRemoteUser(): 
	    	request.getHeader("STANDARDID"),
	"DBA")){
response.sendRedirect("NoAccess.html");
}
String conNm = (request.getParameter("connm") == null) ? ConfigDbSQL.getDefault("FirstDB") : request.getParameter("connm");

      out.write("\r\n");
      out.write("<HTML>\r\n");
      out.write("<HEAD>\r\n");
      out.write("<LINK REL=\"shortcut icon\" HREF=\"icons/favicon.ico\" />\r\n");
      out.write("<LINK REL=\"icon\" TYPE=\"image/gif\" HREF=\"icons/favicon.ico\" />\r\n");
      out.write("<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<TITLE>Display All Locks for ");
      out.print(conNm);
      out.write("</TITLE>\r\n");
      out.write("<META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\" />\r\n");
      out.write("<STYLE TYPE=\"text/css\" TITLE=\"currentStyle\">\r\n");
      out.write("@import \"css/style.css\";\r\n");
      out.write("\r\n");
      out.write("@import \"css/demo_table.css\";\r\n");
      out.write("</STYLE>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\" SRC=\"js/jquery.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\"\r\n");
      out.write("\tSRC=\"js/jquery.dataTables.min.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\"\r\n");
      out.write("\tSRC=\"js/jquery.dataTables.add.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\"\r\n");
      out.write("\tSRC=\"js/TableTools.min.js\"></SCRIPT>\r\n");
      out.write("\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\">\r\n");
      out.write("/* <![CDATA[ */\r\n");
      out.write("\r\n");
      out.write("\tTableTools.BUTTONS.refresh_list = {\r\n");
      out.write("\t\t\"sAction\": \"text\",\r\n");
      out.write("\t\t\"sFieldBoundary\": \"\",\r\n");
      out.write("\t\t\"sFieldSeperator\": \"\\t\",\r\n");
      out.write("\t\t\"sNewLine\": \"<br>\",\r\n");
      out.write("\t\t\"sToolTip\": \"\",\r\n");
      out.write("\t\t\"sButtonClass\": \"DTTT_button_text\",\r\n");
      out.write("\t\t\"sButtonClassHover\": \"DTTT_button_text_hover\",\r\n");
      out.write("\t\t\"sButtonText\": \"Copy to element\",\r\n");
      out.write("\t\t\"mColumns\": \"all\",\r\n");
      out.write("\t\t\"bHeader\": true,\r\n");
      out.write("\t\t\"bFooter\": true,\r\n");
      out.write("\t\t\"sDiv\": \"\",\r\n");
      out.write("\t\t\"fnMouseover\": null,\r\n");
      out.write("\t\t\"fnMouseout\": null,\r\n");
      out.write("\t\t\"fnClick\": function( nButton, oConfig ) {\r\n");
      out.write("\t\t\t");
      out.write("\r\n");
      out.write("\t\t\trefresh_list();\r\n");
      out.write("\t\t},\r\n");
      out.write("\t\t\"fnSelect\": null,\r\n");
      out.write("\t\t\"fnComplete\": null,\r\n");
      out.write("\t\t\"fnInit\": null\r\n");
      out.write("\t};\r\n");
      out.write("\tTableTools.BUTTONS.clear_refresh_list = {\r\n");
      out.write("\t\t\t\"sAction\": \"text\",\r\n");
      out.write("\t\t\t\"sFieldBoundary\": \"\",\r\n");
      out.write("\t\t\t\"sFieldSeperator\": \"\\t\",\r\n");
      out.write("\t\t\t\"sNewLine\": \"<br>\",\r\n");
      out.write("\t\t\t\"sToolTip\": \"\",\r\n");
      out.write("\t\t\t\"sButtonClass\": \"DTTT_button_text\",\r\n");
      out.write("\t\t\t\"sButtonClassHover\": \"DTTT_button_text_hover\",\r\n");
      out.write("\t\t\t\"sButtonText\": \"Copy to element\",\r\n");
      out.write("\t\t\t\"mColumns\": \"all\",\r\n");
      out.write("\t\t\t\"bHeader\": true,\r\n");
      out.write("\t\t\t\"bFooter\": true,\r\n");
      out.write("\t\t\t\"sDiv\": \"\",\r\n");
      out.write("\t\t\t\"fnMouseover\": null,\r\n");
      out.write("\t\t\t\"fnMouseout\": null,\r\n");
      out.write("\t\t\t\"fnClick\": function( nButton, oConfig ) {\r\n");
      out.write("\t\t\t\t");
      out.write("\r\n");
      out.write("\t\t\t\trefresh_list(true);\r\n");
      out.write("\t\t\t},\r\n");
      out.write("\t\t\t\"fnSelect\": null,\r\n");
      out.write("\t\t\t\"fnComplete\": null,\r\n");
      out.write("\t\t\t\"fnInit\": null\r\n");
      out.write("\t\t};\r\n");
      out.write("\r\n");
      out.write("    function refresh_list(clearFilter){\r\n");
      out.write("    \tclearFilter = typeof clearFilter !== 'undefined' ? clearFilter : false;\r\n");
      out.write("    \tvar oTable = $('#lockchart').dataTable(); \r\n");
      out.write("\t\toTable.fnClearTable();\r\n");
      out.write("\t\tif(clearFilter){\r\n");
      out.write("\t\t\toTable.fnFilterClear();\r\n");
      out.write("\t\t}\r\n");
      out.write("    \tvar oSettings = oTable.fnSettings();\r\n");
      out.write("\t\tvar saveCols  = new Array();\r\n");
      out.write("\t\tif ( typeof oSettings.aanFeatures.f != 'undefined' ){\r\n");
      out.write("\t\t\t//var n =oSettings.aanFeatures.f;\r\n");
      out.write("\t\t\t for ( var i=0, iLen=oSettings.aoPreSearchCols.length ; i<iLen ; i++ )     {\r\n");
      out.write("\t\t\t\t saveCols[i] = oSettings.aoPreSearchCols[i].sSearch;\r\n");
      out.write("\t\t\t\t //alert(oSettings.aoPreSearchCols[i].sSearch);     \r\n");
      out.write("\t\t\t }           \r\n");
      out.write("\r\n");
      out.write("\t\t}           \r\n");
      out.write("\t\toTable.fnReloadAjax(\"GetList?connm=");
      out.print(conNm);
      out.write("&tp=alllocks\", function(){\r\n");
      out.write("\t\t\tvar z = -1;\r\n");
      out.write("\t\t\t$(\"thead td\").each( function ( i ) {\r\n");
      out.write("\t\t\t\tvar fircol = 0; //starts with 0, skipping first one \r\n");
      out.write("\t\t\t\tif(this.id.match(/^lockchart_/) &&\r\n");
      out.write("\t\t\t\t\t\tthis.innerHTML.length > 0){\r\n");
      out.write("\t\t\t\t\tif ( z == -1 ){\r\n");
      out.write("\t\t\t\t\t\tz = i + fircol;\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\t//var sel = fnCreateSelect( oTable.fnGetColumnData(i - z) );\r\n");
      out.write("\t\t\t\t\tvar sel = fnCreateSelect( oTable.fnGetColumnData(i - z, true, false), saveCols[i-z] );\r\n");
      out.write("\t\t\t\t\tif (sel.length == 0){\r\n");
      out.write("\t\t\t\t\t\tsel = '<b></b>';\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\tthis.innerHTML = sel;\r\n");
      out.write("\t\t\t\t\t$('select', this).change( function () {\r\n");
      out.write("\t\t\t\t\t\toTable.fnFilter( $(this).val(), i - z );\r\n");
      out.write("\t\t\t\t\t} );\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t} );\r\n");
      out.write("\t\t} ); \r\n");
      out.write("\t\t$(\"h2\").each( function ( i ) {\r\n");
      out.write("\t\t  var currentTime = new Date();\r\n");
      out.write(" \t\t  var day = currentTime.getDate();\r\n");
      out.write("\t\t  var month = currentTime.getMonth() + 1;\r\n");
      out.write("\t\t  var year = currentTime.getFullYear();\r\n");
      out.write("\t\t  var hours = currentTime.getHours();\r\n");
      out.write("  \t\t  if (hours < 10)  hours = \"0\" + hours;\r\n");
      out.write("  \t\t  var minutes = currentTime.getMinutes();\r\n");
      out.write("  \t\t  if (minutes < 10)  minutes = \"0\" + minutes;\r\n");
      out.write("  \t\t  $('#tm').val(month + \"-\" +  day + \"-\" + year + \"_\" + hours + \"-\" + minutes);\r\n");
      out.write("\t\t  this.innerHTML = \"Display All Locks for ");
      out.print(conNm);
      out.write(" at \" + \r\n");
      out.write("\t\t    month + \"/\" +  day + \"/\" + year + \" \" + hours + \":\" + minutes;\r\n");
      out.write("\t\t} );\r\n");
      out.write("\t\t};\r\n");
      out.write("           \r\n");
      out.write("$(document).ready(function() {\r\n");
      out.write("\tvar oTable = '';\r\n");
      out.write("\toTable = $('#lockchart').dataTable({\r\n");
      out.write("\t\t\"bProcessing\" : true,\r\n");
      out.write("\t\t\"bStateSave\" : false,\r\n");
      out.write("\t\t\"sAjaxSource\" : \"GetList?connm=");
      out.print(conNm);
      out.write("&tp=alllocks\",\r\n");
      out.write("\t\t\"bDeferRender\" : true,\r\n");
      out.write("\t\t\"sScrollY\" : \"400px\", \r\n");
      out.write("\t\t\"sScrollX\" : \"100%\", \r\n");
      out.write("\t\t\"bScrollCollapse\": true,\r\n");
      out.write("\r\n");
      out.write("\t\t\"sDom\": 'Tlrt<\"bottom\"f>',\r\n");
      out.write("\t\t/*\"sDom\": 'CTlrt<\"bottom\"f>',*/\r\n");
      out.write("\t\t\"oTableTools\": {            \r\n");
      out.write("\t\t\t\"aButtons\": [ \"copy\", \r\n");
      out.write("\t\t\t             {\"sExtends\": \"csv\",\r\n");
      out.write("\t\t\t              \"fnClick\": function ( nButton, oConfig, oFlash ) {\r\n");
      out.write("\t\t\t                 oFlash.setFileName(\"");
      out.print(conNm);
      out.write("_all_locks_\" + $('#tm').val() + \".csv\");\r\n");
      out.write("\t\t\t                 this.fnSetText( oFlash, this.fnGetTableData(oConfig) );    \r\n");
      out.write("\t\t\t                }\r\n");
      out.write("\t\t\t              },\r\n");
      out.write("\t\t\t             {\"sExtends\":    \"refresh_list\", \"sButtonText\": \"Refresh List\"},\r\n");
      out.write("\t\t\t             {\"sExtends\":    \"clear_refresh_list\", \"sButtonText\": \"Clear/Refresh List\"}\r\n");
      out.write("\t\t\t             ],\r\n");
      out.write("\t\t\t\"sSwfPath\": \"./swf/copy_csv_xls.swf\"\r\n");
      out.write("\t\t},\r\n");
      out.write("\t\t/*\"oColVis\": {\r\n");
      out.write("\t\t\t\"aiExclude\": [ 0, 1, 2 ],\r\n");
      out.write("\t\t\t\"buttonText\": \"Columns\"\r\n");
      out.write("\t\t},*/\r\n");
      out.write("       \"oLanguage\": { \"sProcessing\": \"Running Query Against Database\" },\r\n");
      out.write("        /* 0 based */\r\n");
      out.write("\t\t\"aoColumnDefs\": [    \r\n");
      out.write("                {\"fnRender\": function ( o, val ) {\r\n");
      out.write("\t              \t\treturn '<a href=\"./DisplaySession.jsp?connm=");
      out.print(conNm);
      out.write("&instid=' + o.aData[0] + '&sid=' + o.aData[1] + '\" target=\"_blank\">' + o.aData[1] + '</a>'; },   \r\n");
      out.write("                 \"aTargets\": [ 1 ] }     \r\n");
      out.write("        ],\r\n");
      out.write("\t\t\"bPaginate\" : false,\r\n");
      out.write("\t\t\"bInfo\": false, \r\n");
      out.write("\t\t/*\"aaSorting\": [[ 1, \"asc\" ], [ 3, \"asc\" ]],*/ \r\n");
      out.write("\t\t\"aaSorting\": [ ], \r\n");
      out.write("\t\tfnInitComplete: function () {\r\n");
      out.write("\t\t\tvar z = -1;\r\n");
      out.write("\t\t\t$(\"thead td\").each( function ( i ) {\r\n");
      out.write("\t\t\t\t\r\n");
      out.write("\t\t\t\tvar fircol = 0; //starts with 0, skipping first one \r\n");
      out.write("\t\t\t\tif(this.id.match(/^lockchart_/) &&\r\n");
      out.write("\t\t\t\t\t\tthis.innerHTML.length > 0){\r\n");
      out.write("\t\t\t\t\tif ( z == -1 ){\r\n");
      out.write("\t\t\t\t\t\tz = i + fircol;\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\tvar sel = fnCreateSelect( oTable.fnGetColumnData(i - z) );\r\n");
      out.write("\t\t\t\t\tif (sel.length == 0){\r\n");
      out.write("\t\t\t\t\t\tsel = '<b></b>';\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\tthis.innerHTML = sel;\r\n");
      out.write("\t\t\t\t\t$('select', this).change( function () {\r\n");
      out.write("\t\t\t\t\t\toTable.fnFilter( $(this).val(), i - z );\r\n");
      out.write("\t\t\t\t\t} );\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t} );\r\n");
      out.write("\t\t    oTable.fnAdjustColumnSizing();\r\n");
      out.write("\t\t    oTable.fnSetFilteringDelay();\r\n");
      out.write("    \t\t$(\"h2\").each( function ( i ) {\r\n");
      out.write("\t\t\t  var currentTime = new Date();\r\n");
      out.write("\t \t\t  var day = currentTime.getDate();\r\n");
      out.write("\t\t\t  var month = currentTime.getMonth() + 1;\r\n");
      out.write("\t\t\t  var year = currentTime.getFullYear();\r\n");
      out.write("\t\t\t  var hours = currentTime.getHours();\r\n");
      out.write("\t  \t\t  if (hours < 10)  hours = \"0\" + hours;\r\n");
      out.write("\t  \t\t  var minutes = currentTime.getMinutes();\r\n");
      out.write("\t  \t\t  if (minutes < 10)  minutes = \"0\" + minutes;\r\n");
      out.write("\t  \t\t  $('#tm').val(month + \"-\" +  day + \"-\" + year + \"_\" + hours + \"-\" + minutes);\r\n");
      out.write("\t\t\t  this.innerHTML = \"Display All Locks for ");
      out.print(conNm);
      out.write(" at \" + \r\n");
      out.write("\t\t\t    month + \"/\" +  day + \"/\" + year + \" \" +  \r\n");
      out.write("\t\t\t   hours + \":\" + minutes;\r\n");
      out.write("\t\t\t} );\r\n");
      out.write("\t\t}\r\n");
      out.write("\t});\r\n");
      out.write("\r\n");
      out.write("});\r\n");
      out.write("\r\n");
      out.write("/* ]]> */\r\n");
      out.write("</SCRIPT>\r\n");
      out.write("</HEAD>\r\n");
      out.write("<BODY>\r\n");
      out.write("\t<H2>\r\n");
      out.write("\t\tDisplay All Locks for\r\n");
      out.write("\t\t");
      out.print(conNm);
      out.write("</H2><HR>\r\n");
      out.write("\t<FORM ID=\"eventform\" ACTION=\"\">\r\n");
      out.write("\t\t<TABLE CELLPADDING=\"0\" CELLSPACING=\"0\" BORDER=\"0\" CLASS=\"display\"\r\n");
      out.write("\t\t\tID=\"lockchart\">\r\n");
      out.write("\t\t\t<THEAD>\r\n");
      out.write("\t\t\t\t<TR>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_1\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_2\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_3\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_4\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_5\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_6\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_7\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_8\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_9\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_10\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_11\"></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_12\"><B></B></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_13\"></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_14\"></TD>\r\n");
      out.write("\t\t\t\t\t<TD ID=\"lockchart_15\"><B></B></TD>\r\n");
      out.write("\t\t\t\t</TR>\r\n");
      out.write("\t\t\t\t<TR>\r\n");
      out.write("\t\t\t\t\t<TH>Instance</TH>\r\n");
      out.write("\t\t\t\t\t<TH>SID</TH>\r\n");
      out.write("\t\t\t\t\t<TH>User</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Process</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Type</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Description SID</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Mode Held</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Mode Requested</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Object</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Id1 Tag</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Id1</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Id2 Tag</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Id2</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Scnds</TH>\r\n");
      out.write("\t\t\t\t\t<TH>Block</TH>\r\n");
      out.write("\t\t\t\t</TR>\r\n");
      out.write("\t\t\t</THEAD>\r\n");
      out.write("\t\t\t<TBODY></TBODY>\r\n");
      out.write("\t\t</TABLE>\r\n");
      out.write("\t\t<BR> <INPUT TYPE=\"hidden\" NAME=\"conNm\" VALUE=\"");
      out.print(conNm);
      out.write("\">\r\n");
      out.write("\t\t<INPUT TYPE=\"hidden\" NAME=\"tm\" ID=\"tm\" VALUE=\"jnk\">\r\n");
      out.write("\t</FORM>\r\n");
      out.write("\t<HR>\r\n");
      out.write("\t<DIV ID=\"pic1Div\"></DIV>\r\n");
      out.write("\t<BR>\r\n");
      out.write("</BODY>\r\n");
      out.write("</HTML>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
