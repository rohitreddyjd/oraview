package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import sqlGraph.DbSQL;
import sqlGraph.Connect;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import org.jfree.data.xy.XYDataset;

public final class DisplayGraphDb_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");

	if(!sqlGraph.Usr.validate(
		    (request.getHeader("STANDARDID") == null) ? 
	    		request.getRemoteUser(): 
		    	request.getHeader("STANDARDID"),
		"DBA")){
	response.sendRedirect("NoAccess.html");
	}
	String conNm = request.getParameter("connm");
	String days = request.getParameter("days");
	if(days==null || days.length() < 1){
		days = "7";
	}
	String outStr = null;
	String dSetName = "dbgraph".concat((new Long(System.currentTimeMillis())).toString());
	if (conNm == null || conNm.length() < 1) {
		outStr = "No connm passed!";
	} else {
		Connection con = null;
		try {
			con = Connect.getConnection(conNm);
		} catch (SQLException e1) {
			outStr = e1.getMessage();
		}
		if (outStr == null) {
			long tm = System.currentTimeMillis();
			String dSet = DbSQL.getJSONDBStat(con, Integer.parseInt(days));
			System.out.println("Database Retreival Time for DisplayGraphDb:"
					.concat(new Long(System.currentTimeMillis() - tm)
							.toString()));
			session.setAttribute(dSetName, dSet);
			//session.setMaxInactiveInterval(120);
		}
		try {
			if(con != null) {
				con.close();
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<link rel=\"shortcut icon\" href=\"icons/favicon.ico\" />\r\n");
      out.write("<link rel=\"icon\" type=\"image/gif\" href=\"icons/favicon.ico\" />\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Database Graphs for ");
      out.print(conNm);
      out.write("</title>\r\n");
      out.write("<meta http-equiv=\"Pragma\" content=\"no-cache\" />\r\n");
      out.write("<link type=\"text/css\" rel=\"stylesheet\" href=\"css/style.css\">\r\n");
      out.write("<script type=\"text/javascript\" language=\"javascript\" src=\"js/jquery.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("/* <![CDATA[ */\r\n");
      out.write("onload = function () {\r\n");
      out.write("  var currentTime = new Date();\r\n");
      out.write("  var day = currentTime.getDate();\r\n");
      out.write("  var month = currentTime.getMonth() + 1;\r\n");
      out.write("  var year = currentTime.getFullYear();\r\n");
      out.write("  var hours = currentTime.getHours();\r\n");
      out.write("  if (hours < 10)  hours = \"0\" + hours;\r\n");
      out.write("  var minutes = currentTime.getMinutes();\r\n");
      out.write("  if (minutes < 10)  minutes = \"0\" + minutes;\r\n");
      out.write("  $(\".imgclss\").dblclick( function() {\r\n");
      out.write("\t  var fnm = \"");
      out.print(conNm);
      out.write("_\" + this.id + \"_\" + month + \"-\" + day + \r\n");
      out.write("\t    \"-\" + year + \"_\" + hours + \"-\" + minutes + \".png\";\r\n");
      out.write("\t  window.location.href=this.src + \"&save=\"+fnm;\r\n");
      out.write("  } );\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("/* ]]> */\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\t\t<h1>\r\n");
      out.write("\t\t\tDB Graphs for\r\n");
      out.write("\t\t\t");
      out.print(conNm);
      out.write("\r\n");
      out.write("\t\t\tgoing back\r\n");
      out.write("\t\t\t");
      out.print(days);
      out.write("\r\n");
      out.write("\t\t\tdays\r\n");
      out.write("\t\t</h1>\r\n");
      out.write("\t\t<HR>\r\n");
      out.write("\t\t");

	if (outStr == null) {

      out.write("\r\n");
      out.write("\t\t<form>\r\n");
      out.write("\t\t\t<input type=\"hidden\" name=\"connm\" value=\"");
      out.print(conNm);
      out.write("\"> <b>Days</b><input\r\n");
      out.write("\t\t\t\ttype=\"text\" size=\"4\" maxlength=\"4\" name=\"days\" id=\"days\"\r\n");
      out.write("\t\t\t\tvalue=\"");
      out.print(days);
      out.write("\"><input type=\"submit\" value=\"Refresh\">\r\n");
      out.write("\t\t</form>\r\n");
      out.write("\t\t<br><h4>Login Count</h4><BR><img class=\"imgclss\" id=\"lgncnt\"\r\n");
      out.write("\t\t\tsrc=\"GetGraph?dbstats=true&lgcnt=true&dSetName=");
      out.print(dSetName);
      out.write("\"\r\n");
      out.write("\t\t\talt=\"Login Count\"><br><h4>Logins Per Second</h4><BR><img class=\"imgclss\" id=\"lgnsec\"\r\n");
      out.write("\t\t\tsrc=\"GetGraph?dbstats=true&lgsec=true&dSetName=");
      out.print(dSetName);
      out.write("\"\r\n");
      out.write("\t\t\talt=\"Logins Per Second\"><br><h4>Executions Per Second</h4><BR> <img class=\"imgclss\"\r\n");
      out.write("\t\t\tid=\"exec\"\r\n");
      out.write("\t\t\tsrc=\"GetGraph?dbstats=true&exec=true&dSetName=");
      out.print(dSetName);
      out.write("\"\r\n");
      out.write("\t\t\talt=\"Executions\"><br><h4>Load</h4><BR><img class=\"imgclss\" id=\"load\"\r\n");
      out.write("\t\t\tsrc=\"GetGraph?dbstats=true&load=true&dSetName=");
      out.print(dSetName);
      out.write("\"\r\n");
      out.write("\t\t\talt=\"Load\"><br><h4>Commits/Rollbacks</h4><BR><img class=\"imgclss\" id=\"commit\"\r\n");
      out.write("\t\t\tsrc=\"GetGraph?dbstats=true&commit=true&rollback=true&dSetName=");
      out.print(dSetName);
      out.write("\"\r\n");
      out.write("\t\t\talt=\"Commit\"><br><h4>Database Time</h4><BR><img class=\"imgclss\" id=\"dbtime\"\r\n");
      out.write("\t\t\tsrc=\"GetGraph?dbstats=true&dbtime=true&dSetName=");
      out.print(dSetName);
      out.write("\"\r\n");
      out.write("\t\t\talt=\"DB Time\"><br><h4>Cache</h4><BR><img class=\"imgclss\" id=\"cache\"\r\n");
      out.write("\t\t\tsrc=\"GetGraph?dbstats=true&cache=true&dSetName=");
      out.print(dSetName);
      out.write("\"\r\n");
      out.write("\t\t\talt=\"Cache\"><br><h4>Logical Reads</h4><BR><img class=\"imgclss\" id=\"lread\"\r\n");
      out.write("\t\t\tsrc=\"GetGraph?dbstats=true&lread=true&dSetName=");
      out.print(dSetName);
      out.write("\"\r\n");
      out.write("\t\t\talt=\"Logical Reads\"><br><h4>Physical Reads</h4><BR><img class=\"imgclss\" id=\"pread\"\r\n");
      out.write("\t\t\tsrc=\"GetGraph?dbstats=true&pread=true&dSetName=");
      out.print(dSetName);
      out.write("\"\r\n");
      out.write("\t\t\talt=\"Physical Reads\"><br><h4>Blocks</h4><BR><img class=\"imgclss\" id=\"blocks\"\r\n");
      out.write("\t\t\tsrc=\"GetGraph?dbstats=true&blocks=true&dSetName=");
      out.print(dSetName);
      out.write("\"\r\n");
      out.write("\t\t\talt=\"Blocks\"><br>\r\n");
      out.write("\t\t");

	} else {

      out.write("\r\n");
      out.write("\t\t");
      out.print(outStr);
      out.write("\r\n");
      out.write("\t\t");

	}

      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
