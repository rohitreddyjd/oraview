package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import sqlGraph.DbSQL;
import sqlGraph.ConfigDbSQL;

public final class DisplayDBInfo_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");

	if(!sqlGraph.Usr.validate(
		    (request.getHeader("STANDARDID") == null) ? 
	    		request.getRemoteUser(): 
		    	request.getHeader("STANDARDID"),
		"DBA")){ 
	response.sendRedirect("NoAccess.html");
	}
	String owner = request.getParameter("owner");
	String table = request.getParameter("table"); 
	String conNm = (request.getParameter("connm") == null) ? ConfigDbSQL.getDefault("FirstDB") : request.getParameter("connm");

      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<link rel=\"shortcut icon\" href=\"icons/favicon.ico\" />\r\n");
      out.write("<link rel=\"icon\" type=\"image/gif\" href=\"icons/favicon.ico\" />\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Database Information for ");
      out.print(conNm);
      out.write("</title>\r\n");
      out.write("<meta http-equiv=\"Pragma\" content=\"no-cache\" />\r\n");
      out.write("<STYLE TYPE=\"text/css\" TITLE=\"currentStyle\">\r\n");
      out.write("@import \"css/style.css\";\r\n");
      out.write("@import \"css/demo_table.css\";\r\n");
      out.write("</STYLE>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\" SRC=\"js/jquery.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\"\r\n");
      out.write("\tSRC=\"js/jquery.dataTables.min.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\"\r\n");
      out.write("\tSRC=\"js/jquery.dataTables.add.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\" LANGUAGE=\"javascript\"\r\n");
      out.write("\tSRC=\"js/TableTools.min.js\"></SCRIPT>\r\n");
      out.write("<SCRIPT TYPE=\"text/javascript\">\r\n");
      out.write("/* <![CDATA[ */\r\n");
      out.write("\r\n");
      out.write("$(document).ready(function() {\r\n");
      out.write("\tvar oTable1 = $('#dbInfo').dataTable({\r\n");
      out.write("\t\t\"bProcessing\" : true,\r\n");
      out.write("\t\t\"sAjaxSource\" : \"GetList?connm=");
      out.print(conNm);
      out.write("&tp=database\",\r\n");
      out.write("\t\t\"bDeferRender\" : true,\r\n");
      out.write("\t\t\"sDom\": 'lrt',\r\n");
      out.write("\t\t\"bPaginate\" : false,\r\n");
      out.write("\t\t\"sScrollY\" : \"600px\",\r\n");
      out.write("\t\t\"sScrollX\" : \"100%\", \r\n");
      out.write("\t\t\"bScrollCollapse\": true,\r\n");
      out.write("\t\t\"aaSorting\": [],\r\n");
      out.write("\t\t\"bInfo\": false, \r\n");
      out.write("\t\t\"bSort\": false,\r\n");
      out.write("\t    \"aoColumnDefs\": [    \r\n");
      out.write("\t\t                    {\"fnRender\": function ( o, val ) {\r\n");
      out.write("\t\t    \t              \t\treturn '<em>' + o.aData[0] + '</em>'; },   \r\n");
      out.write("\t\t                     \"aTargets\": [ 0 ] },\r\n");
      out.write("\t\t                      {\"fnRender\": function ( o, val ) {\r\n");
      out.write("\t\t    \t              \t\treturn '<em>' + o.aData[2] + '</em>'; },   \r\n");
      out.write("\t\t                     \"aTargets\": [ 2 ] }     \r\n");
      out.write("\t    ],\r\n");
      out.write("\t\tfnInitComplete: function () {\r\n");
      out.write("\t\t    oTable1.fnAdjustColumnSizing(); \t\r\n");
      out.write("\t\t}\r\n");
      out.write("\t});\r\n");
      out.write("\t\r\n");
      out.write("\tvar oTable2 = $('#instInfo').dataTable({\r\n");
      out.write("\t\t\"bProcessing\" : true,\r\n");
      out.write("\t\t\"sAjaxSource\" : \"GetList?connm=");
      out.print(conNm);
      out.write("&tp=instance\",\r\n");
      out.write("\t\t\"bDeferRender\" : true,\r\n");
      out.write("\t\t\"sDom\": 'lrt',\r\n");
      out.write("\t\t\"bPaginate\" : false,\r\n");
      out.write("\t\t\"sScrollY\" : \"240px\",\r\n");
      out.write("\t\t\"sScrollX\" : \"100%\", \r\n");
      out.write("\t\t\"bScrollCollapse\": true,\r\n");
      out.write("\t\t\"bInfo\": false, \r\n");
      out.write("\t\tfnInitComplete: function () {\r\n");
      out.write("\t\t\toTable2.fnAdjustColumnSizing();\r\n");
      out.write("\t\t}\r\n");
      out.write("\t});\r\n");
      out.write("\r\n");
      out.write("});\r\n");
      out.write("\t\r\n");
      out.write("/* ]]> */\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\t<center><h2>Database Information for ");
      out.print(conNm);
      out.write("</h2></center><hr>\r\n");
      out.write("\t<h3>Database Information</h3><br>\r\n");
      out.write("\t\t<TABLE CELLPADDING=\"0\" CELLSPACING=\"0\" BORDER=\"0\" CLASS=\"display\" ID=\"dbInfo\" WIDTH=\"100%\">\r\n");
      out.write("\t\t<THEAD>\r\n");
      out.write("\t\t\t<TR>\r\n");
      out.write("\t\t\t\t<TH></TH>\r\n");
      out.write("\t\t\t\t<TH></TH>\r\n");
      out.write("\t\t\t\t<TH></TH>\r\n");
      out.write("\t\t\t\t<TH></TH>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t\t</THEAD>\r\n");
      out.write("\t\t<TBODY></TBODY>\r\n");
      out.write("\t</table><br>\r\n");
      out.write("\t<h3>Instance Information</h3><br>\r\n");
      out.write("\t<TABLE CELLPADDING=\"0\" CELLSPACING=\"0\" BORDER=\"0\" CLASS=\"display\" ID=\"instInfo\" WIDTH=\"100%\">\r\n");
      out.write("\t\t<THEAD>\r\n");
      out.write("\t\t\t<TR>\r\n");
      out.write("\t\t\t\t<TD ID=\"instInfo_1\"></TD>\r\n");
      out.write("\t\t\t\t<TD ID=\"instInfo_2\"></TD>\r\n");
      out.write("\t\t\t\t<TD ID=\"instInfo_3\"></TD>\r\n");
      out.write("\t\t\t\t<TD ID=\"instInfo_4\"></TD>\r\n");
      out.write("\t\t\t\t<TD ID=\"instInfo_5\"></TD>\r\n");
      out.write("\t\t\t\t<TD ID=\"instInfo_6\"></TD>\r\n");
      out.write("\t\t\t\t<TD ID=\"instInfo_7\"></TD>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t\t\t<TR>\r\n");
      out.write("\t\t\t\t<th>Instance#</th>\r\n");
      out.write("\t\t\t\t<th>Name</th>\r\n");
      out.write("\t\t\t\t<th>Host</th>\r\n");
      out.write("\t\t\t\t<th>Version</th>\r\n");
      out.write("\t\t\t\t<th>Startup</th>\r\n");
      out.write("\t\t\t\t<th>Status</th>\r\n");
      out.write("\t\t\t\t<th>Role</th>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t\t</THEAD>\r\n");
      out.write("\t\t<TBODY></TBODY>\r\n");
      out.write("\t</TABLE>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
